﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AnimationExtenderControlBase
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing.Design;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [ToolboxItem(false)]
  [ParseChildren(true)]
  [PersistChildren(false)]
  [DefaultProperty("Animations")]
  public class AnimationExtenderControlBase : ExtenderControlBase
  {
    private string _animations;

    [ExtenderControlProperty]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [TypeConverter(typeof (MultilineStringConverter))]
    [Editor(typeof (MultilineStringEditor), typeof (UITypeEditor))]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    public string Animations
    {
      get => this._animations ?? string.Empty;
      set
      {
        if (value != null)
          value = AnimationExtenderControlBase.TrimForDesigner(value);
        if (!(this._animations != value))
          return;
        this._animations = value;
        Animation.Parse(this._animations, (ExtenderControl) this);
      }
    }

    private static string TrimForDesigner(string value)
    {
      if (string.IsNullOrEmpty(value))
        return value;
      int num1 = 0;
      while (num1 < value.Length && char.IsWhiteSpace(value[num1]))
        ++num1;
      int num2 = value.LastIndexOf('\n', num1);
      if (num2 >= 0)
        value = value.Substring(num2 + 1);
      return value.TrimEnd();
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeAnimations() => this.DesignMode && !string.IsNullOrEmpty(this._animations);

    protected Animation GetAnimation(ref Animation animation, string name)
    {
      if (animation == null)
        animation = Animation.Deserialize(this.GetPropertyValue<string>(name, ""));
      return animation;
    }

    protected void SetAnimation(ref Animation animation, string name, Animation value)
    {
      animation = value;
      this.SetPropertyValue<string>(name, animation != null ? animation.ToString() : string.Empty);
    }

    protected void ResolveControlIDs(Animation animation)
    {
      if (animation == null)
        return;
      string id;
      if (animation.Properties.TryGetValue("AnimationTarget", out id) && !string.IsNullOrEmpty(id))
      {
        Control control1 = (Control) null;
        Control control2 = this.NamingContainer;
        while (control2 != null && (control1 = control2.FindControl(id)) == null)
          control2 = control2.Parent;
        if (control1 != null)
          animation.Properties["AnimationTarget"] = control1.ClientID;
      }
      foreach (Animation child in (IEnumerable<Animation>) animation.Children)
        this.ResolveControlIDs(child);
    }
  }
}
