﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AccordionDesigner
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Text;
using System.Web.UI;
using System.Web.UI.Design;

namespace AjaxControlToolkit
{
  public class AccordionDesigner : ControlDesigner
  {
    private Accordion _accordion;

    public override void Initialize(IComponent component)
    {
      this._accordion = component as Accordion;
      if (this._accordion == null)
        throw new ArgumentException("Component must be an Accordion control", nameof (component));
      base.Initialize(component);
    }

    public override string GetDesignTimeHtml()
    {
      ControlCollection controls = this._accordion.Controls;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(base.GetDesignTimeHtml());
      stringBuilder.Remove(stringBuilder.Length - 6, 6);
      foreach (AccordionPane pane in this._accordion.Panes)
      {
        stringBuilder.Append("<span>");
        string str1 = !string.IsNullOrEmpty(pane.HeaderCssClass) ? pane.HeaderCssClass : this._accordion.HeaderCssClass;
        stringBuilder.AppendFormat("<div class=\"{0}\">", (object) str1);
        if (pane.Header is TemplateBuilder header)
          stringBuilder.Append(header.Text);
        stringBuilder.Append("</div>");
        string str2 = !string.IsNullOrEmpty(pane.ContentCssClass) ? pane.ContentCssClass : this._accordion.ContentCssClass;
        stringBuilder.AppendFormat("<div class=\"{0}\">", (object) str2);
        if (pane.Content is TemplateBuilder content)
          stringBuilder.Append(content.Text);
        stringBuilder.Append("</div>");
        stringBuilder.Append("</span>");
      }
      stringBuilder.Append("</div>");
      return stringBuilder.ToString();
    }
  }
}
