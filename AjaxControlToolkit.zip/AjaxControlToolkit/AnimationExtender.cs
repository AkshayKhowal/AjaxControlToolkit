﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AnimationExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [ToolboxBitmap(typeof (AnimationExtender), "Animation.Animation.ico")]
  [Designer("AjaxControlToolkit.AnimationExtenderDesigner, AjaxControlToolkit")]
  [RequiredScript(typeof (AnimationScripts))]
  [ClientScriptResource("AjaxControlToolkit.Animation.AnimationBehavior", "AjaxControlToolkit.Animation.AnimationBehavior.js")]
  [TargetControlType(typeof (Control))]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  public class AnimationExtender : AnimationExtenderControlBase
  {
    private Animation _onLoad;
    private Animation _onClick;
    private Animation _onMouseOver;
    private Animation _onMouseOut;
    private Animation _onHoverOver;
    private Animation _onHoverOut;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ExtenderControlProperty]
    [DefaultValue(null)]
    [Browsable(false)]
    public Animation OnLoad
    {
      get => this.GetAnimation(ref this._onLoad, nameof (OnLoad));
      set => this.SetAnimation(ref this._onLoad, nameof (OnLoad), value);
    }

    [ExtenderControlProperty]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [DefaultValue(null)]
    [Browsable(false)]
    public Animation OnClick
    {
      get => this.GetAnimation(ref this._onClick, nameof (OnClick));
      set => this.SetAnimation(ref this._onClick, nameof (OnClick), value);
    }

    [DefaultValue(null)]
    [ExtenderControlProperty]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public Animation OnMouseOver
    {
      get => this.GetAnimation(ref this._onMouseOver, nameof (OnMouseOver));
      set => this.SetAnimation(ref this._onMouseOver, nameof (OnMouseOver), value);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ExtenderControlProperty]
    [DefaultValue(null)]
    [Browsable(false)]
    public Animation OnMouseOut
    {
      get => this.GetAnimation(ref this._onMouseOut, nameof (OnMouseOut));
      set => this.SetAnimation(ref this._onMouseOut, nameof (OnMouseOut), value);
    }

    [DefaultValue(null)]
    [ExtenderControlProperty]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public Animation OnHoverOver
    {
      get => this.GetAnimation(ref this._onHoverOver, nameof (OnHoverOver));
      set => this.SetAnimation(ref this._onHoverOver, nameof (OnHoverOver), value);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [DefaultValue(null)]
    [Browsable(false)]
    [ExtenderControlProperty]
    public Animation OnHoverOut
    {
      get => this.GetAnimation(ref this._onHoverOut, nameof (OnHoverOut));
      set => this.SetAnimation(ref this._onHoverOut, nameof (OnHoverOut), value);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      this.ResolveControlIDs(this._onLoad);
      this.ResolveControlIDs(this._onClick);
      this.ResolveControlIDs(this._onMouseOver);
      this.ResolveControlIDs(this._onMouseOut);
      this.ResolveControlIDs(this._onHoverOver);
      this.ResolveControlIDs(this._onHoverOut);
    }
  }
}
