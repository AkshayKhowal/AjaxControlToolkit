﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Animation
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Xml;

namespace AjaxControlToolkit
{
  [PersistChildren(false)]
  [DefaultProperty("Name")]
  [ParseChildren(true)]
  public class Animation
  {
    private static JavaScriptSerializer _serializer = new JavaScriptSerializer();
    private string _name;
    private List<Animation> _children;
    private Dictionary<string, string> _properties;

    static Animation() => Animation._serializer.RegisterConverters((IEnumerable<JavaScriptConverter>) new JavaScriptConverter[1]
    {
      (JavaScriptConverter) new AnimationJavaScriptConverter()
    });

    public Animation()
    {
      this._children = new List<Animation>();
      this._properties = new Dictionary<string, string>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase);
    }

    [Browsable(false)]
    public string Name
    {
      get => this._name;
      set => this._name = value;
    }

    [Browsable(false)]
    public IList<Animation> Children => (IList<Animation>) this._children;

    [Browsable(false)]
    public Dictionary<string, string> Properties => this._properties;

    public override string ToString() => Animation.Serialize(this);

    public static string Serialize(Animation animation) => Animation._serializer.Serialize((object) animation);

    public static Animation Deserialize(string json) => string.IsNullOrEmpty(json) ? (Animation) null : Animation._serializer.Deserialize<Animation>(json);

    public static Animation Deserialize(XmlNode node)
    {
      if (node == null)
        throw new ArgumentNullException(nameof (node));
      Animation animation = new Animation();
      animation.Name = node.Name;
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) node.Attributes)
        animation.Properties.Add(attribute.Name, attribute.Value);
      if (node.HasChildNodes)
      {
        foreach (XmlNode childNode in node.ChildNodes)
          animation.Children.Add(Animation.Deserialize(childNode));
      }
      return animation;
    }

    public static void Parse(string value, ExtenderControl extenderControl)
    {
      if (extenderControl == null)
        throw new ArgumentNullException(nameof (extenderControl));
      if (value == null || string.IsNullOrEmpty(value.Trim()))
        return;
      value = "<Animations>" + value + "</Animations>";
      XmlDocument xmlDocument = new XmlDocument();
      using (XmlTextReader reader = new XmlTextReader((TextReader) new StringReader(value)))
      {
        try
        {
          xmlDocument.Load((XmlReader) reader);
        }
        catch (XmlException ex)
        {
          string message = string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Invalid Animation definition for TargetControlID=\"{0}\": {1}", (object) extenderControl.TargetControlID, (object) ex.Message);
          throw new HttpParseException(message, (Exception) new ArgumentException(message, (Exception) ex), HttpContext.Current.Request.Path, value, ex.LineNumber);
        }
      }
      foreach (XmlNode childNode in xmlDocument.DocumentElement.ChildNodes)
      {
        PropertyDescriptor property = TypeDescriptor.GetProperties((object) extenderControl)[childNode.Name];
        if (property == null || property.IsReadOnly)
        {
          string message = string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Animation on TargetControlID=\"{0}\" uses property {1}.{2} that does not exist or cannot be set", (object) extenderControl.TargetControlID, (object) extenderControl.GetType().FullName, (object) childNode.Name);
          throw new HttpParseException(message, (Exception) new ArgumentException(message), HttpContext.Current.Request.Path, value, Animation.GetLineNumber(value, childNode.Name));
        }
        if (childNode.ChildNodes.Count != 1)
        {
          string message = string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Animation {0} for TargetControlID=\"{1}\" can only have one child node.", (object) childNode.Name, (object) extenderControl.TargetControlID);
          throw new HttpParseException(message, (Exception) new ArgumentException(message), HttpContext.Current.Request.Path, value, Animation.GetLineNumber(value, childNode.Name));
        }
        Animation animation = Animation.Deserialize(childNode.ChildNodes[0]);
        property.SetValue((object) extenderControl, (object) animation);
      }
    }

    private static int GetLineNumber(string source, string tag)
    {
      using (XmlTextReader xmlTextReader = new XmlTextReader((TextReader) new StringReader(source)))
      {
        if (xmlTextReader.Read())
        {
          while (xmlTextReader.Read())
          {
            if (string.Compare(xmlTextReader.Name, tag, StringComparison.OrdinalIgnoreCase) == 0)
              return xmlTextReader.LineNumber;
            if (xmlTextReader.NodeType == XmlNodeType.Element && !xmlTextReader.IsEmptyElement)
              xmlTextReader.Skip();
          }
        }
      }
      return 1;
    }
  }
}
