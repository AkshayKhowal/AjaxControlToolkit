﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AccordionPaneCollection
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Web.UI;

namespace AjaxControlToolkit
{
  public sealed class AccordionPaneCollection : 
    IList,
    ICollection,
    IEnumerable<AccordionPane>,
    IEnumerable
  {
    private Accordion _parent;
    private int _version;

    internal AccordionPaneCollection(Accordion parent) => this._parent = parent != null ? parent : throw new ArgumentNullException(nameof (parent), "Parent Accordion cannot be null.");

    public int Count
    {
      get
      {
        int count = 0;
        foreach (Control control in this._parent.Controls)
        {
          if (control is AccordionPane)
            ++count;
        }
        return count;
      }
    }

    public bool IsReadOnly => false;

    public AccordionPane this[int index] => this._parent.Controls[this.ToRawIndex(index)] as AccordionPane;

    public AccordionPane this[string id]
    {
      get
      {
        for (int index = 0; index < this._parent.Controls.Count; ++index)
        {
          if (this._parent.Controls[index] is AccordionPane control && control.ID == id)
            return control;
        }
        return (AccordionPane) null;
      }
    }

    private int ToRawIndex(int paneIndex)
    {
      if (paneIndex < 0)
        return -1;
      int num = -1;
      for (int index = 0; index < this._parent.Controls.Count; ++index)
      {
        if (this._parent.Controls[index] is AccordionPane && ++num == paneIndex)
          return index;
      }
      throw new ArgumentException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "No AccordionPane at position {0}", (object) paneIndex));
    }

    private int FromRawIndex(int index)
    {
      if (index < 0)
        return -1;
      int num = -1;
      for (int index1 = 0; index1 < this._parent.Controls.Count; ++index1)
      {
        if (this._parent.Controls[index1] is AccordionPane)
          ++num;
        if (index == index1)
          return num;
      }
      throw new ArgumentException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "No AccordionPane at position {0}", (object) index));
    }

    public void Add(AccordionPane item)
    {
      this._parent.Controls.Add((Control) item);
      ++this._version;
    }

    public void Clear()
    {
      this._parent.ClearPanes();
      ++this._version;
    }

    public bool Contains(AccordionPane item) => this._parent.Controls.Contains((Control) item);

    public void CopyTo(Array array, int index)
    {
      if (!(array is AccordionPane[] array1))
        throw new ArgumentException("Expected an array of AccordionPanes.");
      this.CopyTo(array1, index);
    }

    public void CopyTo(AccordionPane[] array, int index)
    {
      if (array == null)
        throw new ArgumentNullException(nameof (array), "Cannot copy into a null array.");
      int num = 0;
      for (int index1 = 0; index1 < this._parent.Controls.Count; ++index1)
      {
        if (this._parent.Controls[index1] is AccordionPane control)
        {
          if (num + index == array.Length)
            throw new ArgumentException("Array is not large enough for the AccordionPanes");
          array[num++ + index] = control;
        }
      }
    }

    public int IndexOf(AccordionPane item) => this.FromRawIndex(this._parent.Controls.IndexOf((Control) item));

    public void Insert(int index, AccordionPane item)
    {
      this._parent.Controls.AddAt(this.ToRawIndex(index), (Control) item);
      ++this._version;
    }

    public void Remove(AccordionPane item)
    {
      this._parent.Controls.Remove((Control) item);
      ++this._version;
    }

    public void RemoveAt(int index)
    {
      this._parent.Controls.RemoveAt(this.ToRawIndex(index));
      ++this._version;
    }

    int IList.Add(object value)
    {
      this.Add(value as AccordionPane);
      return 0;
    }

    bool IList.Contains(object value) => this.Contains(value as AccordionPane);

    int IList.IndexOf(object value) => this.IndexOf(value as AccordionPane);

    void IList.Insert(int index, object value) => this.Insert(index, value as AccordionPane);

    bool IList.IsFixedSize => false;

    void IList.Remove(object value) => this.Remove(value as AccordionPane);

    object IList.this[int index]
    {
      get => (object) this[index];
      set
      {
      }
    }

    bool ICollection.IsSynchronized => false;

    object ICollection.SyncRoot => throw new NotImplementedException();

    IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) new AccordionPaneCollection.AccordionPaneEnumerator(this);

    public IEnumerator<AccordionPane> GetEnumerator() => (IEnumerator<AccordionPane>) new AccordionPaneCollection.AccordionPaneEnumerator(this);

    private class AccordionPaneEnumerator : IEnumerator<AccordionPane>, IDisposable, IEnumerator
    {
      private AccordionPaneCollection _collection;
      private IEnumerator _parentEnumerator;
      private int _version;

      public AccordionPaneEnumerator(AccordionPaneCollection parent)
      {
        this._collection = parent;
        this._parentEnumerator = parent._parent.Controls.GetEnumerator();
        this._version = parent._version;
      }

      private void CheckVersion()
      {
        if (this._version != this._collection._version)
          throw new InvalidOperationException("Enumeration can't continue because the collection has been modified.");
      }

      public void Dispose()
      {
        this._parentEnumerator = (IEnumerator) null;
        this._collection = (AccordionPaneCollection) null;
        GC.SuppressFinalize((object) this);
      }

      public AccordionPane Current
      {
        get
        {
          this.CheckVersion();
          return this._parentEnumerator.Current as AccordionPane;
        }
      }

      object IEnumerator.Current => (object) this.Current;

      public bool MoveNext()
      {
        this.CheckVersion();
        bool flag = this._parentEnumerator.MoveNext();
        if (flag && !(this._parentEnumerator.Current is AccordionPane))
          flag = this.MoveNext();
        return flag;
      }

      public void Reset()
      {
        this.CheckVersion();
        this._parentEnumerator.Reset();
      }
    }
  }
}
