﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AutoCompleteExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  [ToolboxBitmap(typeof (AutoCompleteExtender), "AutoComplete.AutoComplete.ico")]
  [RequiredScript(typeof (TimerScript))]
  [Designer("AjaxControlToolkit.AutoCompleteDesigner, AjaxControlToolkit")]
  [ClientScriptResource("AjaxControlToolkit.AutoCompleteBehavior", "AjaxControlToolkit.AutoComplete.AutoCompleteBehavior.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (PopupExtender))]
  [TargetControlType(typeof (TextBox))]
  [RequiredScript(typeof (AnimationExtender))]
  public class AutoCompleteExtender : AnimationExtenderControlBase
  {
    private Animation _onShow;
    private Animation _onHide;

    [ExtenderControlProperty]
    [ClientPropertyName("minimumPrefixLength")]
    [DefaultValue(3)]
    public virtual int MinimumPrefixLength
    {
      get => this.GetPropertyValue<int>(nameof (MinimumPrefixLength), 3);
      set => this.SetPropertyValue<int>(nameof (MinimumPrefixLength), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(1000)]
    [ClientPropertyName("completionInterval")]
    public virtual int CompletionInterval
    {
      get => this.GetPropertyValue<int>(nameof (CompletionInterval), 1000);
      set => this.SetPropertyValue<int>(nameof (CompletionInterval), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(10)]
    [ClientPropertyName("completionSetCount")]
    public virtual int CompletionSetCount
    {
      get => this.GetPropertyValue<int>(nameof (CompletionSetCount), 10);
      set => this.SetPropertyValue<int>(nameof (CompletionSetCount), value);
    }

    [ClientPropertyName("completionListElementID")]
    [Obsolete("Instead of passing in CompletionListElementID, use the default flyout and style that using the CssClass properties.")]
    [IDReferenceProperty(typeof (WebControl))]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public virtual string CompletionListElementID
    {
      get => this.GetPropertyValue<string>(nameof (CompletionListElementID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (CompletionListElementID), value);
    }

    [ClientPropertyName("serviceMethod")]
    [DefaultValue("")]
    [RequiredProperty]
    [ExtenderControlProperty]
    public virtual string ServiceMethod
    {
      get => this.GetPropertyValue<string>(nameof (ServiceMethod), string.Empty);
      set => this.SetPropertyValue<string>(nameof (ServiceMethod), value);
    }

    [ClientPropertyName("servicePath")]
    [TypeConverter(typeof (ServicePathConverter))]
    [UrlProperty]
    [ExtenderControlProperty]
    public virtual string ServicePath
    {
      get => this.GetPropertyValue<string>(nameof (ServicePath), string.Empty);
      set => this.SetPropertyValue<string>(nameof (ServicePath), value);
    }

    [DefaultValue(null)]
    [ClientPropertyName("contextKey")]
    [ExtenderControlProperty]
    public string ContextKey
    {
      get => this.GetPropertyValue<string>(nameof (ContextKey), (string) null);
      set
      {
        this.SetPropertyValue<string>(nameof (ContextKey), value);
        this.UseContextKey = true;
      }
    }

    [ClientPropertyName("useContextKey")]
    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool UseContextKey
    {
      get => this.GetPropertyValue<bool>(nameof (UseContextKey), false);
      set => this.SetPropertyValue<bool>(nameof (UseContextKey), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("completionListCssClass")]
    [DefaultValue("")]
    public string CompletionListCssClass
    {
      get => this.GetPropertyValue<string>(nameof (CompletionListCssClass), "");
      set => this.SetPropertyValue<string>(nameof (CompletionListCssClass), value);
    }

    [ClientPropertyName("completionListItemCssClass")]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string CompletionListItemCssClass
    {
      get => this.GetPropertyValue<string>(nameof (CompletionListItemCssClass), "");
      set => this.SetPropertyValue<string>(nameof (CompletionListItemCssClass), value);
    }

    [DefaultValue("")]
    [ClientPropertyName("highlightedItemCssClass")]
    [ExtenderControlProperty]
    public string CompletionListHighlightedItemCssClass
    {
      get => this.GetPropertyValue<string>(nameof (CompletionListHighlightedItemCssClass), "");
      set => this.SetPropertyValue<string>(nameof (CompletionListHighlightedItemCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(true)]
    [ClientPropertyName("enableCaching")]
    public virtual bool EnableCaching
    {
      get => this.GetPropertyValue<bool>(nameof (EnableCaching), true);
      set => this.SetPropertyValue<bool>(nameof (EnableCaching), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("delimiterCharacters")]
    public virtual string DelimiterCharacters
    {
      get => this.GetPropertyValue<string>(nameof (DelimiterCharacters), string.Empty);
      set => this.SetPropertyValue<string>(nameof (DelimiterCharacters), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("firstRowSelected")]
    [DefaultValue(false)]
    public virtual bool FirstRowSelected
    {
      get => this.GetPropertyValue<bool>(nameof (FirstRowSelected), false);
      set => this.SetPropertyValue<bool>(nameof (FirstRowSelected), value);
    }

    [DefaultValue(false)]
    [ClientPropertyName("showOnlyCurrentWordInCompletionListItem")]
    [ExtenderControlProperty]
    public bool ShowOnlyCurrentWordInCompletionListItem
    {
      get => this.GetPropertyValue<bool>(nameof (ShowOnlyCurrentWordInCompletionListItem), false);
      set => this.SetPropertyValue<bool>(nameof (ShowOnlyCurrentWordInCompletionListItem), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(null)]
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ClientPropertyName("onShow")]
    public Animation OnShow
    {
      get => this.GetAnimation(ref this._onShow, nameof (OnShow));
      set => this.SetAnimation(ref this._onShow, nameof (OnShow), value);
    }

    [DefaultValue(null)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ExtenderControlProperty]
    [ClientPropertyName("onHide")]
    [Browsable(false)]
    public Animation OnHide
    {
      get => this.GetAnimation(ref this._onHide, nameof (OnHide));
      set => this.SetAnimation(ref this._onHide, nameof (OnHide), value);
    }

    [ExtenderControlEvent]
    [ClientPropertyName("populating")]
    [DefaultValue("")]
    public string OnClientPopulating
    {
      get => this.GetPropertyValue<string>(nameof (OnClientPopulating), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientPopulating), value);
    }

    [ClientPropertyName("populated")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    public string OnClientPopulated
    {
      get => this.GetPropertyValue<string>(nameof (OnClientPopulated), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientPopulated), value);
    }

    [ClientPropertyName("showing")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public string OnClientShowing
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShowing), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShowing), value);
    }

    [ClientPropertyName("shown")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    public string OnClientShown
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShown), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShown), value);
    }

    [ClientPropertyName("hiding")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    public string OnClientHiding
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHiding), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHiding), value);
    }

    [ClientPropertyName("hidden")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public string OnClientHidden
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHidden), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHidden), value);
    }

    [ClientPropertyName("itemSelected")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public string OnClientItemSelected
    {
      get => this.GetPropertyValue<string>(nameof (OnClientItemSelected), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientItemSelected), value);
    }

    [DefaultValue("")]
    [ExtenderControlEvent]
    [ClientPropertyName("itemOver")]
    public string OnClientItemOver
    {
      get => this.GetPropertyValue<string>(nameof (OnClientItemOver), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientItemOver), value);
    }

    [ClientPropertyName("itemOut")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public string OnClientItemOut
    {
      get => this.GetPropertyValue<string>(nameof (OnClientItemOut), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientItemOut), value);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      this.ResolveControlIDs(this._onShow);
      this.ResolveControlIDs(this._onHide);
    }

    public static string CreateAutoCompleteItem(string text, string value) => new JavaScriptSerializer().Serialize((object) new Pair((object) text, (object) value));
  }
}
