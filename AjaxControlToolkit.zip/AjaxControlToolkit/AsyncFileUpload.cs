﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AsyncFileUpload
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [Designer("AjaxControlToolkit.AsyncFileUploadDesigner, AjaxControlToolkit")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ClientScriptResource("AjaxControlToolkit.AsyncFileUpload", "AjaxControlToolkit.AsyncFileUpload.AsyncFileUpload.js")]
  public class AsyncFileUpload : ScriptControlBase
  {
    private AsyncFileUpload.PersistedStoreTypeEnum persistStorageType;
    private string lastError = string.Empty;
    private bool failedValidation;
    private AsyncFileUpload.UploaderStyleEnum controlStyle;
    private string hiddenFieldID = string.Empty;
    private string innerTBID = string.Empty;
    private HtmlInputFile inputFile;

    public AsyncFileUpload()
      : base(true, HtmlTextWriterTag.Span)
    {
    }

    [Bindable(true)]
    [Category("Server Events")]
    public event EventHandler<AsyncFileUploadEventArgs> UploadedComplete;

    [Category("Server Events")]
    [Bindable(true)]
    public event EventHandler<AsyncFileUploadEventArgs> UploadedFileError;

    [DefaultValue("")]
    [Category("Behavior")]
    [ExtenderControlEvent]
    [ClientPropertyName("uploadStarted")]
    public string OnClientUploadStarted
    {
      get => (string) (this.ViewState[nameof (OnClientUploadStarted)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientUploadStarted)] = (object) value;
    }

    [DefaultValue("")]
    [Category("Behavior")]
    [ExtenderControlEvent]
    [ClientPropertyName("uploadComplete")]
    public string OnClientUploadComplete
    {
      get => (string) (this.ViewState[nameof (OnClientUploadComplete)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientUploadComplete)] = (object) value;
    }

    [Category("Behavior")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    [ClientPropertyName("uploadError")]
    public string OnClientUploadError
    {
      get => (string) (this.ViewState[nameof (OnClientUploadError)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientUploadError)] = (object) value;
    }

    private bool IsDesignMode => HttpContext.Current == null;

    [Browsable(false)]
    public byte[] FileBytes
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        HttpPostedFile fileFromSession = AfuPersistedStoreManager.Instance.GetFileFromSession(this.ClientID);
        if (fileFromSession != null)
        {
          try
          {
            return this.GetBytesFromStream(fileFromSession.InputStream);
          }
          catch
          {
          }
        }
        return (byte[]) null;
      }
    }

    [Category("Behavior")]
    [DefaultValue("")]
    [Description("ID of Throbber")]
    public string ThrobberID
    {
      get => (string) (this.ViewState[nameof (ThrobberID)] ?? (object) string.Empty);
      set => this.ViewState[nameof (ThrobberID)] = (object) value;
    }

    [DefaultValue(typeof (Color), "Lime")]
    [Category("Appearance")]
    [TypeConverter(typeof (WebColorConverter))]
    [Description("Control's background color on upload complete.")]
    public Color CompleteBackColor
    {
      get => (Color) (this.ViewState[nameof (CompleteBackColor)] ?? (object) Color.Lime);
      set => this.ViewState[nameof (CompleteBackColor)] = (object) value;
    }

    [DefaultValue(typeof (Color), "White")]
    [Description("Control's background color when uploading is in progress.")]
    [Category("Appearance")]
    [TypeConverter(typeof (WebColorConverter))]
    public Color UploadingBackColor
    {
      get => (Color) (this.ViewState[nameof (UploadingBackColor)] ?? (object) Color.White);
      set => this.ViewState[nameof (UploadingBackColor)] = (object) value;
    }

    [DefaultValue(typeof (Color), "Red")]
    [Description("Control's background color on upload error.")]
    [Category("Appearance")]
    [TypeConverter(typeof (WebColorConverter))]
    public Color ErrorBackColor
    {
      get => (Color) (this.ViewState[nameof (ErrorBackColor)] ?? (object) Color.Red);
      set => this.ViewState[nameof (ErrorBackColor)] = (object) value;
    }

    [DefaultValue(typeof (Unit), "")]
    [Category("Layout")]
    public override Unit Width
    {
      get => base.Width;
      set => base.Width = value;
    }

    [Browsable(false)]
    public bool FailedValidation
    {
      get => this.failedValidation;
      set => this.failedValidation = value;
    }

    [DefaultValue(AsyncFileUpload.PersistedStoreTypeEnum.Session)]
    [Category("Behavior")]
    [Bindable(true)]
    public AsyncFileUpload.PersistedStoreTypeEnum PersistedStoreType
    {
      get => this.persistStorageType;
      set => this.persistStorageType = value;
    }

    [Bindable(true)]
    [DefaultValue(AsyncFileUpload.UploaderStyleEnum.Traditional)]
    [Category("Appearance")]
    [Browsable(true)]
    public AsyncFileUpload.UploaderStyleEnum UploaderStyle
    {
      get => this.controlStyle;
      set => this.controlStyle = value;
    }

    [Browsable(false)]
    public HttpPostedFile PostedFile
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        return AfuPersistedStoreManager.Instance.GetFileFromSession(this.ClientID);
      }
    }

    [Browsable(false)]
    public bool HasFile
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        return AfuPersistedStoreManager.Instance.FileExists(this.ClientID);
      }
    }

    [Browsable(false)]
    public string FileName
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        return Path.GetFileName(AfuPersistedStoreManager.Instance.GetFileName(this.ClientID));
      }
    }

    [Browsable(false)]
    public string ContentType
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        return AfuPersistedStoreManager.Instance.GetContentType(this.ClientID);
      }
    }

    [Browsable(false)]
    public Stream FileContent
    {
      get
      {
        this.PopulatObjectPriorToRender(this.ClientID);
        HttpPostedFile fileFromSession = AfuPersistedStoreManager.Instance.GetFileFromSession(this.ClientID);
        return fileFromSession.InputStream != null ? fileFromSession.InputStream : (Stream) null;
      }
    }

    [Browsable(false)]
    public bool IsUploading => this.Page.Request.QueryString[AsyncFileUpload.Constants.FileUploadIDKey] != null;

    public void SaveAs(string filename)
    {
      this.PopulatObjectPriorToRender(this.ClientID);
      AfuPersistedStoreManager.Instance.GetFileFromSession(this.ClientID).SaveAs(filename);
    }

    private void PopulatObjectPriorToRender(string controlId)
    {
      if (AfuPersistedStoreManager.Instance.FileExists(controlId) || this.Page == null || this.Page.Request.Files.Count == 0)
        return;
      this.RecievedFile(controlId);
    }

    protected virtual void OnUploadedFileError(AsyncFileUploadEventArgs e)
    {
      if (this.UploadedFileError == null)
        return;
      this.UploadedFileError((object) this, e);
    }

    protected virtual void OnUploadedComplete(AsyncFileUploadEventArgs e)
    {
      if (this.UploadedComplete == null)
        return;
      this.UploadedComplete((object) this, e);
    }

    private void RecievedFile(string sendingControlID)
    {
      this.lastError = string.Empty;
      if (this.Page.Request.Files.Count <= 0)
        return;
      HttpPostedFile fileUpload = (HttpPostedFile) null;
      if (sendingControlID == null || sendingControlID == string.Empty)
      {
        fileUpload = this.Page.Request.Files[0];
      }
      else
      {
        foreach (string file in (NameObjectCollectionBase) this.Page.Request.Files)
        {
          if (file.Replace("$", "_").StartsWith(sendingControlID))
          {
            fileUpload = this.Page.Request.Files[file];
            break;
          }
        }
      }
      if (fileUpload == null)
      {
        this.lastError = AsyncFileUpload.Constants.Errors.FileNull;
        this.OnUploadedFileError(new AsyncFileUploadEventArgs(AsyncFileUploadState.Failed, AsyncFileUpload.Constants.Errors.FileNull, string.Empty, string.Empty));
      }
      else if (fileUpload.FileName == string.Empty)
      {
        this.lastError = AsyncFileUpload.Constants.Errors.NoFileName;
        this.OnUploadedFileError(new AsyncFileUploadEventArgs(AsyncFileUploadState.Unknown, AsyncFileUpload.Constants.Errors.NoFileName, fileUpload.FileName, fileUpload.ContentLength.ToString()));
      }
      else if (fileUpload.InputStream == null)
      {
        this.lastError = AsyncFileUpload.Constants.Errors.NoFileName;
        this.OnUploadedFileError(new AsyncFileUploadEventArgs(AsyncFileUploadState.Failed, AsyncFileUpload.Constants.Errors.NoFileName, fileUpload.FileName, fileUpload.ContentLength.ToString()));
      }
      else if (fileUpload.ContentLength < 1)
      {
        this.lastError = AsyncFileUpload.Constants.Errors.EmptyContentLength;
        this.OnUploadedFileError(new AsyncFileUploadEventArgs(AsyncFileUploadState.Unknown, AsyncFileUpload.Constants.Errors.EmptyContentLength, fileUpload.FileName, fileUpload.ContentLength.ToString()));
      }
      else
      {
        AsyncFileUploadEventArgs e = new AsyncFileUploadEventArgs(AsyncFileUploadState.Success, string.Empty, fileUpload.FileName, fileUpload.ContentLength.ToString());
        GC.SuppressFinalize((object) fileUpload);
        AfuPersistedStoreManager.Instance.AddFileToSession(this.ClientID, fileUpload.FileName, fileUpload);
        this.OnUploadedComplete(e);
      }
    }

    public byte[] GetBytesFromStream(Stream stream)
    {
      byte[] buffer = new byte[32768];
      using (MemoryStream memoryStream = new MemoryStream())
      {
        stream.Seek(0L, SeekOrigin.Begin);
        while (true)
        {
          int count = stream.Read(buffer, 0, buffer.Length);
          if (count > 0)
            memoryStream.Write(buffer, 0, count);
          else
            break;
        }
        return memoryStream.ToArray();
      }
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      AfuPersistedStoreManager.Instance.PersistedStorageType = (AfuPersistedStoreManager.PersistedStoreTypeEnum) this.PersistedStoreType;
      string str = this.Page.Request.QueryString[AsyncFileUpload.Constants.FileUploadIDKey];
      if ((str == null || !str.StartsWith(this.ClientID)) && str != null)
        return;
      this.RecievedFile(this.ClientID);
      if (str == null || !str.StartsWith(this.ClientID))
        return;
      if (this.lastError == string.Empty)
      {
        byte[] fileBytes = this.FileBytes;
        if (fileBytes == null)
          return;
        this.Controls.Add((Control) new LiteralControl(fileBytes.Length.ToString() + "------" + this.ContentType));
      }
      else
        this.Controls.Add((Control) new LiteralControl("error------" + this.lastError));
    }

    internal void CreateChilds()
    {
      this.Controls.Clear();
      this.CreateChildControls();
    }

    protected override void CreateChildControls()
    {
      AfuPersistedStoreManager.Instance.ExtendedFileUploadGUID = AsyncFileUpload.Constants.fileUploadGUID;
      string str = (string) null;
      if (!this.IsDesignMode)
        str = this.Page.Request.QueryString[AsyncFileUpload.Constants.FileUploadIDKey];
      if (!this.IsDesignMode && str != null && !(str == string.Empty))
        return;
      this.hiddenFieldID = this.GenerateHtmlInputHiddenControl();
      string lastFileName = string.Empty;
      if (AfuPersistedStoreManager.Instance.FileExists(this.ClientID))
        lastFileName = AfuPersistedStoreManager.Instance.GetFileName(this.ClientID);
      this.GenerateHtmlInputFileControl(lastFileName);
    }

    protected string GenerateHtmlInputHiddenControl()
    {
      HiddenField child = new HiddenField();
      this.Controls.Add((Control) child);
      return child.ClientID;
    }

    protected string GenerateHtmlInputFileControl(string lastFileName)
    {
      HtmlGenericControl child1 = new HtmlGenericControl("div");
      this.Controls.Add((Control) child1);
      child1.Attributes.Add("name", child1.ClientID);
      if (this.UploaderStyle == AsyncFileUpload.UploaderStyleEnum.Modern)
      {
        string empty = string.Empty;
        string str1 = "background:url(" + this.Page.ClientScript.GetWebResourceUrl(typeof (AsyncFileUpload), "AjaxControlToolkit.AsyncFileUpload.images.fileupload.png") + ") no-repeat 100% 1px; height:24px; margin:0px;";
        string str2 = this.Width.IsEmpty ? str1 + "width:355px;" : str1 + "width:" + this.Width.ToString() + ";";
        child1.Attributes.Add("style", str2);
      }
      if (this.UploaderStyle != AsyncFileUpload.UploaderStyleEnum.Modern || !this.IsDesignMode)
      {
        this.inputFile = new HtmlInputFile();
        child1.Controls.Add((Control) this.inputFile);
        this.inputFile.Attributes.Add("id", this.inputFile.ClientID);
        this.inputFile.Attributes.Add("onkeydown", "return false;");
        this.inputFile.Attributes.Add("onkeypress", "return false;");
        this.inputFile.Attributes.Add("onmousedown", "return false;");
        if (this.UploaderStyle != AsyncFileUpload.UploaderStyleEnum.Modern)
        {
          if (this.BackColor != Color.Empty)
            this.inputFile.Style[HtmlTextWriterStyle.BackgroundColor] = ColorTranslator.ToHtml(this.BackColor);
          if (!this.Width.IsEmpty)
            this.inputFile.Style[HtmlTextWriterStyle.Width] = this.Width.ToString();
          else
            this.inputFile.Style[HtmlTextWriterStyle.Width] = "355px";
        }
      }
      if (this.UploaderStyle == AsyncFileUpload.UploaderStyleEnum.Modern)
      {
        string str3 = "opacity:0.0; -moz-opacity: 0.0; filter: alpha(opacity=00); font-size:14px;";
        if (!this.Width.IsEmpty)
          str3 = str3 + "width:" + this.Width.ToString() + ";";
        if (this.inputFile != null)
          this.inputFile.Attributes.Add("style", str3);
        TextBox child2 = new TextBox();
        string str4;
        if (!this.IsDesignMode)
        {
          HtmlGenericControl child3 = new HtmlGenericControl("div");
          child1.Controls.Add((Control) child3);
          child3.Attributes.Add("name", child1.ClientID);
          string str5 = "margin-top:-23px;";
          child3.Attributes.Add("style", str5);
          child3.Attributes.Add("type", "text");
          child3.Controls.Add((Control) child2);
          str4 = "height:17px; font-size:12px; font-family:Tahoma;";
        }
        else
        {
          child1.Controls.Add((Control) child2);
          str4 = "height:23px; font-size:12px; font-family:Tahoma;";
        }
        string str6 = this.Width.IsEmpty || this.Width.ToString().IndexOf("px") <= 0 ? str4 + "width:248px;" : str4 + "width:" + (int.Parse(this.Width.ToString().Substring(0, this.Width.ToString().IndexOf("px"))) - 107).ToString() + "px;";
        if (lastFileName != string.Empty || this.failedValidation)
        {
          if (this.FileBytes != null && this.FileBytes.Length > 0 && !this.failedValidation)
          {
            str6 += "background-color:#00FF00;";
          }
          else
          {
            this.failedValidation = false;
            str6 += "background-color:#FF0000;";
          }
          child2.Text = lastFileName;
        }
        else if (this.BackColor != Color.Empty)
          str6 = str6 + "background-color:" + ColorTranslator.ToHtml(this.BackColor) + ";";
        child2.ReadOnly = true;
        child2.Attributes.Add("style", str6);
        this.innerTBID = child2.ClientID;
      }
      else if (this.IsDesignMode)
      {
        this.Controls.Clear();
        this.Controls.Add((Control) this.inputFile);
      }
      return child1.ClientID;
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      if (this.IsDesignMode)
        return;
      if (this.hiddenFieldID != string.Empty)
        descriptor.AddElementProperty("hiddenField", this.hiddenFieldID);
      if (this.innerTBID != string.Empty)
        descriptor.AddElementProperty("innerTB", this.innerTBID);
      if (this.inputFile != null)
        descriptor.AddElementProperty("inputFile", this.inputFile.ClientID);
      descriptor.AddProperty("postBackUrl", (object) Path.GetFileName(this.Page.Request.FilePath));
      descriptor.AddProperty("formName", (object) Path.GetFileName(this.Page.Form.Name));
      if (this.CompleteBackColor != Color.Empty)
        descriptor.AddProperty("completeBackColor", (object) ColorTranslator.ToHtml(this.CompleteBackColor));
      if (this.ErrorBackColor != Color.Empty)
        descriptor.AddProperty("errorBackColor", (object) ColorTranslator.ToHtml(this.ErrorBackColor));
      if (this.UploadingBackColor != Color.Empty)
        descriptor.AddProperty("uploadingBackColor", (object) ColorTranslator.ToHtml(this.UploadingBackColor));
      if (!(this.ThrobberID != string.Empty))
        return;
      Control control = this.FindControl(this.ThrobberID);
      if (control == null)
        return;
      descriptor.AddElementProperty("throbber", control.ClientID);
    }

    protected override Style CreateControlStyle() => (Style) new AsyncFileUpload.AsyncFileUploadStyle(this.ViewState);

    public static class Constants
    {
      public static readonly string FileUploadIDKey = "AsyncFileUploadID";
      public static readonly string InternalErrorInvalidIFrame = "The ExtendedFileUpload control has encountered an error with the uploader in this page. Please refresh the page and try again.";
      public static readonly string fileUploadGUID = "b3b89160-3224-476e-9076-70b500c816cf";

      public static class Errors
      {
        public static readonly string NoFiles = "No files are attached to the upload.";
        public static readonly string FileNull = "The file attached is invalid.";
        public static readonly string NoFileName = "The file attached has an invalid filename.";
        public static readonly string InputStreamNull = "The file attached could not be read.";
        public static readonly string EmptyContentLength = "The file attached is empty.";
      }

      public static class StatusMessages
      {
        public static readonly string UploadSuccessful = "The file uploaded successfully.";
      }
    }

    public enum UploaderStyleEnum
    {
      Traditional,
      Modern,
    }

    public enum PersistedStoreTypeEnum
    {
      Session,
    }

    private sealed class AsyncFileUploadStyle : Style
    {
      public AsyncFileUploadStyle(StateBag state)
        : base(state)
      {
      }

      protected override void FillStyleAttributes(
        CssStyleCollection attributes,
        IUrlResolutionService urlResolver)
      {
        base.FillStyleAttributes(attributes, urlResolver);
        attributes.Remove(HtmlTextWriterStyle.BackgroundColor);
        attributes.Remove(HtmlTextWriterStyle.Width);
      }
    }
  }
}
