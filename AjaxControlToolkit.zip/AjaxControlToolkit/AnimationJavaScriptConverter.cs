﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AnimationJavaScriptConverter
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web.Script.Serialization;

namespace AjaxControlToolkit
{
  internal class AnimationJavaScriptConverter : JavaScriptConverter
  {
    public override IEnumerable<Type> SupportedTypes => (IEnumerable<Type>) new ReadOnlyCollection<Type>((IList<Type>) new List<Type>((IEnumerable<Type>) new Type[1]
    {
      typeof (Animation)
    }));

    public override IDictionary<string, object> Serialize(
      object obj,
      JavaScriptSerializer serializer)
    {
      return obj is Animation animation ? AnimationJavaScriptConverter.Serialize(animation) : (IDictionary<string, object>) new Dictionary<string, object>();
    }

    private static IDictionary<string, object> Serialize(Animation animation)
    {
      if (animation == null)
        throw new ArgumentNullException(nameof (animation));
      Dictionary<string, object> dictionary = new Dictionary<string, object>();
      dictionary["AnimationName"] = (object) animation.Name;
      foreach (KeyValuePair<string, string> property in animation.Properties)
        dictionary[property.Key] = (object) property.Value;
      List<IDictionary<string, object>> dictionaryList = new List<IDictionary<string, object>>();
      foreach (Animation child in (IEnumerable<Animation>) animation.Children)
        dictionaryList.Add(AnimationJavaScriptConverter.Serialize(child));
      dictionary["AnimationChildren"] = (object) dictionaryList.ToArray();
      return (IDictionary<string, object>) dictionary;
    }

    public override object Deserialize(
      IDictionary<string, object> dictionary,
      Type t,
      JavaScriptSerializer serializer)
    {
      if (dictionary == null)
        throw new ArgumentNullException(nameof (dictionary));
      return t == typeof (Animation) || t.IsSubclassOf(typeof (Animation)) ? (object) AnimationJavaScriptConverter.Deserialize(dictionary) : (object) null;
    }

    private static Animation Deserialize(IDictionary<string, object> obj)
    {
      if (obj == null)
        throw new ArgumentNullException(nameof (obj));
      Animation animation = new Animation();
      animation.Name = obj.ContainsKey("AnimationName") ? obj["AnimationName"] as string : throw new InvalidOperationException("Cannot deserialize an Animation without an AnimationName property");
      foreach (KeyValuePair<string, object> keyValuePair in (IEnumerable<KeyValuePair<string, object>>) obj)
      {
        if (string.Compare(keyValuePair.Key, "AnimationName", StringComparison.OrdinalIgnoreCase) != 0 && string.Compare(keyValuePair.Key, "AnimationChildren", StringComparison.OrdinalIgnoreCase) != 0)
          animation.Properties.Add(keyValuePair.Key, keyValuePair.Value != null ? keyValuePair.Value.ToString() : (string) null);
      }
      if (obj.ContainsKey("AnimationChildren") && obj["AnimationChildren"] is ArrayList arrayList)
      {
        foreach (object obj1 in arrayList)
        {
          IDictionary<string, object> dictionary = obj1 as IDictionary<string, object>;
          if (obj1 != null)
            animation.Children.Add(AnimationJavaScriptConverter.Deserialize(dictionary));
        }
      }
      return animation;
    }
  }
}
