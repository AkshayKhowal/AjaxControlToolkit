﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AccordionExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Globalization;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [Designer("AjaxControlToolkit.AccordionExtenderDesigner, AjaxControlToolkit")]
  [TargetControlType(typeof (Accordion))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (AnimationScripts))]
  [ClientScriptResource("AjaxControlToolkit.AccordionBehavior", "AjaxControlToolkit.Accordion.AccordionBehavior.js")]
  [ToolboxItem(false)]
  public class AccordionExtender : ExtenderControlBase
  {
    public AccordionExtender() => this.EnableClientState = true;

    [DefaultValue(AutoSize.None)]
    [ExtenderControlProperty]
    public AutoSize AutoSize
    {
      get => this.GetPropertyValue<AutoSize>(nameof (AutoSize), AutoSize.None);
      set => this.SetPropertyValue<AutoSize>(nameof (AutoSize), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(250)]
    public int TransitionDuration
    {
      get => this.GetPropertyValue<int>(nameof (TransitionDuration), 250);
      set => this.SetPropertyValue<int>(nameof (TransitionDuration), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool FadeTransitions
    {
      get => this.GetPropertyValue<bool>(nameof (FadeTransitions), false);
      set => this.SetPropertyValue<bool>(nameof (FadeTransitions), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(30)]
    public int FramesPerSecond
    {
      get => this.GetPropertyValue<int>(nameof (FramesPerSecond), 30);
      set => this.SetPropertyValue<int>(nameof (FramesPerSecond), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int SelectedIndex
    {
      get
      {
        int result;
        return string.IsNullOrEmpty(this.ClientState) || !int.TryParse(this.ClientState, NumberStyles.Integer, (IFormatProvider) CultureInfo.InvariantCulture, out result) ? 0 : result;
      }
      set => this.ClientState = value.ToString((IFormatProvider) CultureInfo.InvariantCulture);
    }

    [DefaultValue(true)]
    [ClientPropertyName("requireOpenedPane")]
    [ExtenderControlProperty]
    public bool RequireOpenedPane
    {
      get => this.GetPropertyValue<bool>(nameof (RequireOpenedPane), true);
      set => this.SetPropertyValue<bool>(nameof (RequireOpenedPane), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("suppressHeaderPostbacks")]
    [DefaultValue(false)]
    public bool SuppressHeaderPostbacks
    {
      get => this.GetPropertyValue<bool>(nameof (SuppressHeaderPostbacks), false);
      set => this.SetPropertyValue<bool>(nameof (SuppressHeaderPostbacks), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string HeaderCssClass
    {
      get => this.GetPropertyValue<string>(nameof (HeaderCssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (HeaderCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string HeaderSelectedCssClass
    {
      get => this.GetPropertyValue<string>(nameof (HeaderSelectedCssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (HeaderSelectedCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string ContentCssClass
    {
      get => this.GetPropertyValue<string>(nameof (ContentCssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (ContentCssClass), value);
    }
  }
}
