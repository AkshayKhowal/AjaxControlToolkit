﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AccordionContentPanel
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  public class AccordionContentPanel : Panel, IDataItemContainer, INamingContainer
  {
    private bool _collapsed;
    private object _dataItem;
    private int _dataIndex;
    private AccordionItemType _type;

    internal AccordionContentPanel()
    {
    }

    internal AccordionContentPanel(object dataItem, int dataIndex, AccordionItemType type)
      : this()
    {
      this.SetDataItemProperties(dataItem, dataIndex, type);
    }

    public bool Collapsed
    {
      get => this._collapsed;
      set
      {
        this._collapsed = value;
        this.Style[HtmlTextWriterStyle.Display] = this._collapsed ? "none" : "block";
      }
    }

    public AccordionItemType ItemType => this._type;

    public object DataItem => this._dataItem;

    public int DataItemIndex => this._dataIndex;

    public int DisplayIndex => this._dataIndex;

    protected override bool OnBubbleEvent(object source, EventArgs args)
    {
      if (!(args is CommandEventArgs commandEventArgs))
        return false;
      this.RaiseBubbleEvent((object) this, (EventArgs) new AccordionCommandEventArgs(this, commandEventArgs.CommandName, commandEventArgs.CommandArgument));
      return true;
    }

    internal void SetDataItemProperties(object dataItem, int dataIndex, AccordionItemType type)
    {
      this._dataItem = dataItem;
      this._dataIndex = dataIndex;
      this._type = type;
    }
  }
}
