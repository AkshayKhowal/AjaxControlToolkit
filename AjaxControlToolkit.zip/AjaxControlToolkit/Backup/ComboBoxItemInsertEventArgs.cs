﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ComboBoxItemInsertEventArgs
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  public class ComboBoxItemInsertEventArgs : CancelEventArgs
  {
    private ListItem _listItem;
    private ComboBoxItemInsertLocation _insertLocation;

    internal ComboBoxItemInsertEventArgs(string text, ComboBoxItemInsertLocation location)
    {
      this._listItem = new ListItem(text);
      this._insertLocation = location;
    }

    public ListItem Item
    {
      set => this._listItem = value;
      get => this._listItem;
    }

    public ComboBoxItemInsertLocation InsertLocation
    {
      set => this._insertLocation = value;
      get => this._insertLocation;
    }
  }
}
