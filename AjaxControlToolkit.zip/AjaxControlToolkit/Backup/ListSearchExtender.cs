﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ListSearchExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ClientScriptResource("AjaxControlToolkit.ListSearchBehavior", "AjaxControlToolkit.ListSearch.ListSearchBehavior.js")]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  [ToolboxBitmap(typeof (ListSearchExtender), "ListSearch.ListSearch.ico")]
  [Designer(typeof (ListSearchDesigner))]
  [RequiredScript(typeof (PopupControlExtender), 1)]
  [RequiredScript(typeof (AnimationExtender), 2)]
  [Description("Lets users search incrementally within ListBoxes")]
  [TargetControlType(typeof (ListControl))]
  [RequiredScript(typeof (CommonToolkitScripts), 0)]
  public class ListSearchExtender : AnimationExtenderControlBase
  {
    private Animation _onShow;
    private Animation _onHide;

    public ListSearchExtender() => this.EnableClientState = true;

    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      this.ClientState = string.Compare(this.Page.Form.DefaultFocus, this.TargetControlID, StringComparison.OrdinalIgnoreCase) == 0 ? "Focused" : (string) null;
    }

    [Description("The prompt text displayed when user clicks the list")]
    [ClientPropertyName("promptText")]
    [DefaultValue("Type to search")]
    [ExtenderControlProperty]
    public string PromptText
    {
      get => this.GetPropertyValue<string>("promptText", "Type to search");
      set => this.SetPropertyValue<string>("promptText", value);
    }

    [Description("CSS class applied to prompt when user clicks list")]
    [ClientPropertyName("promptCssClass")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string PromptCssClass
    {
      get => this.GetPropertyValue<string>("promptCssClass", "");
      set => this.SetPropertyValue<string>("promptCssClass", value);
    }

    [ClientPropertyName("promptPosition")]
    [Description("Indicates where you want the prompt message displayed when the user clicks on the list.")]
    [ExtenderControlProperty]
    [DefaultValue(ListSearchPromptPosition.Top)]
    public ListSearchPromptPosition PromptPosition
    {
      get => this.GetPropertyValue<ListSearchPromptPosition>("promptPosition", ListSearchPromptPosition.Top);
      set => this.SetPropertyValue<ListSearchPromptPosition>("promptPosition", value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("onShow")]
    [Browsable(false)]
    [DefaultValue(null)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Animation OnShow
    {
      get => this.GetAnimation(ref this._onShow, nameof (OnShow));
      set => this.SetAnimation(ref this._onShow, nameof (OnShow), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(null)]
    [ClientPropertyName("onHide")]
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Animation OnHide
    {
      get => this.GetAnimation(ref this._onHide, nameof (OnHide));
      set => this.SetAnimation(ref this._onHide, nameof (OnHide), value);
    }

    [ClientPropertyName("queryTimeout")]
    [DefaultValue(0)]
    [ExtenderControlProperty]
    public int QueryTimeout
    {
      get => this.GetPropertyValue<int>(nameof (QueryTimeout), 0);
      set => this.SetPropertyValue<int>(nameof (QueryTimeout), value);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      this.ResolveControlIDs(this._onShow);
      this.ResolveControlIDs(this._onHide);
    }

    [Description("Indicates search criteria to be used to find items.")]
    [DefaultValue(ListSearchQueryPattern.StartsWith)]
    [ExtenderControlProperty]
    [ClientPropertyName("queryPattern")]
    public ListSearchQueryPattern QueryPattern
    {
      get => this.GetPropertyValue<ListSearchQueryPattern>(nameof (QueryPattern), ListSearchQueryPattern.StartsWith);
      set => this.SetPropertyValue<ListSearchQueryPattern>(nameof (QueryPattern), value);
    }

    [ClientPropertyName("isSorted")]
    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool IsSorted
    {
      get => this.GetPropertyValue<bool>(nameof (IsSorted), false);
      set => this.SetPropertyValue<bool>(nameof (IsSorted), value);
    }
  }
}
