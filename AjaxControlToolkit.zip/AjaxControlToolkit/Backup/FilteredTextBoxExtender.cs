﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.FilteredTextBoxExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [DefaultProperty("ValidChars")]
  [ToolboxBitmap(typeof (FilteredTextBoxExtender), "FilteredTextBox.FilteredTextBox.ico")]
  [Designer("AjaxControlToolkit.FilteredTextBoxDesigner, AjaxControlToolkit")]
  [ClientScriptResource("AjaxControlToolkit.FilteredTextBoxBehavior", "AjaxControlToolkit.FilteredTextBox.FilteredTextBoxBehavior.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [TargetControlType(typeof (TextBox))]
  public class FilteredTextBoxExtender : ExtenderControlBase
  {
    [ExtenderControlProperty]
    [DefaultValue(FilterTypes.Custom)]
    public FilterTypes FilterType
    {
      get => this.GetPropertyValue<FilterTypes>(nameof (FilterType), FilterTypes.Custom);
      set => this.SetPropertyValue<FilterTypes>(nameof (FilterType), value);
    }

    [DefaultValue(FilterModes.ValidChars)]
    [ExtenderControlProperty]
    public FilterModes FilterMode
    {
      get => this.GetPropertyValue<FilterModes>(nameof (FilterMode), FilterModes.ValidChars);
      set => this.SetPropertyValue<FilterModes>(nameof (FilterMode), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string ValidChars
    {
      get => this.GetPropertyValue<string>(nameof (ValidChars), "");
      set => this.SetPropertyValue<string>(nameof (ValidChars), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string InvalidChars
    {
      get => this.GetPropertyValue<string>(nameof (InvalidChars), "");
      set => this.SetPropertyValue<string>(nameof (InvalidChars), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(250)]
    public int FilterInterval
    {
      get => this.GetPropertyValue<int>(nameof (FilterInterval), 250);
      set => this.SetPropertyValue<int>(nameof (FilterInterval), value);
    }

    protected override bool CheckIfValid(bool throwException)
    {
      if (this.FilterType != FilterTypes.Custom || (this.FilterMode != FilterModes.ValidChars || !string.IsNullOrEmpty(this.ValidChars)) && (this.FilterMode != FilterModes.InvalidChars || !string.IsNullOrEmpty(this.InvalidChars)))
        return base.CheckIfValid(throwException);
      if (throwException)
        throw new InvalidOperationException("If FilterTypes.Custom is specified, please provide a value for ValidChars or InvalidChars");
      return false;
    }
  }
}
