﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.EditorDesigner
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using AjaxControlToolkit.HTMLEditor;
using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web.UI;
using System.Web.UI.Design;

namespace AjaxControlToolkit
{
  public class EditorDesigner : DesignerWithMapPath
  {
    private Editor Editor => (Editor) this.Component;

    public override string GetDesignTimeHtml(DesignerRegionCollection regions)
    {
      StringBuilder sb = new StringBuilder(1024);
      HtmlTextWriter writer = new HtmlTextWriter((TextWriter) new StringWriter(sb, (IFormatProvider) CultureInfo.InvariantCulture));
      writer.AddAttribute(HtmlTextWriterAttribute.Rel, "stylesheet");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, this.Editor.Page.ClientScript.GetWebResourceUrl(typeof (Editor), "AjaxControlToolkit.HTMLEditor.Editor.css"));
      writer.RenderBeginTag(HtmlTextWriterTag.Link);
      writer.RenderEndTag();
      this.Editor.CreateChilds((DesignerWithMapPath) this);
      this.Editor.RenderControl(writer);
      return sb.ToString();
    }
  }
}
