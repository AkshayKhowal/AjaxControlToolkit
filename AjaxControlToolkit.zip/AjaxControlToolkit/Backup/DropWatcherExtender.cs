﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DropWatcherExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [TargetControlType(typeof (BulletedList))]
  [ToolboxItem(false)]
  [ClientScriptResource("AjaxControlToolkit.DragDropWatcher", typeof (DropWatcherExtender), "ReorderList.DropWatcherBehavior.js")]
  [RequiredScript(typeof (DragDropScripts))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  public class DropWatcherExtender : ExtenderControlBase
  {
    private string DataTypeName => "HTML_" + this.Parent.ID;

    [Browsable(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("acceptedDataTypes")]
    public string AcceptedDataTypes
    {
      get => this.DataTypeName;
      set => ExtenderControlBase.SuppressUnusedParameterWarning((object) value);
    }

    [ClientPropertyName("argReplaceString")]
    [ExtenderControlProperty]
    public string ArgReplaceString
    {
      get => this.GetPropertyValue<string>(nameof (ArgReplaceString), "");
      set => this.SetPropertyValue<string>(nameof (ArgReplaceString), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("argSuccessString")]
    public string ArgSuccessString
    {
      get => this.GetPropertyValue<string>(nameof (ArgSuccessString), "");
      set => this.SetPropertyValue<string>(nameof (ArgSuccessString), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("argErrorString")]
    public string ArgErrorString
    {
      get => this.GetPropertyValue<string>(nameof (ArgErrorString), "");
      set => this.SetPropertyValue<string>(nameof (ArgErrorString), value);
    }

    [ClientPropertyName("argContextString")]
    [ExtenderControlProperty]
    public string ArgContextString
    {
      get => this.GetPropertyValue<string>(nameof (ArgContextString), "");
      set => this.SetPropertyValue<string>(nameof (ArgContextString), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("callbackCssStyle")]
    public string CallbackCssStyle
    {
      get => this.GetPropertyValue<string>(nameof (CallbackCssStyle), "");
      set => this.SetPropertyValue<string>(nameof (CallbackCssStyle), value);
    }

    [Browsable(false)]
    [ClientPropertyName("dragDataType")]
    [ExtenderControlProperty]
    public string DataType
    {
      get => this.DataTypeName;
      set => ExtenderControlBase.SuppressUnusedParameterWarning((object) value);
    }

    [ClientPropertyName("dragMode")]
    [ExtenderControlProperty]
    [Browsable(false)]
    public int DragMode
    {
      get => 1;
      set => ExtenderControlBase.SuppressUnusedParameterWarning((object) value);
    }

    [ClientPropertyName("dropCueTemplate")]
    [ElementReference]
    [IDReferenceProperty(typeof (Control))]
    [ExtenderControlProperty]
    public string DropLayoutElement
    {
      get => this.GetPropertyValue<string>(nameof (DropLayoutElement), "");
      set => this.SetPropertyValue<string>(nameof (DropLayoutElement), value);
    }

    [ClientPropertyName("postbackCode")]
    [ExtenderControlProperty]
    public string PostBackCode
    {
      get => this.GetPropertyValue<string>("PostbackCode", "");
      set => this.SetPropertyValue<string>("PostbackCode", value);
    }
  }
}
