﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ExtenderControlMethodAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
  public sealed class ExtenderControlMethodAttribute : Attribute
  {
    private static ExtenderControlMethodAttribute Yes = new ExtenderControlMethodAttribute(true);
    private static ExtenderControlMethodAttribute No = new ExtenderControlMethodAttribute(false);
    private static ExtenderControlMethodAttribute Default = ExtenderControlMethodAttribute.No;
    private bool _isScriptMethod;

    public ExtenderControlMethodAttribute()
      : this(true)
    {
    }

    public ExtenderControlMethodAttribute(bool isScriptMethod) => this._isScriptMethod = isScriptMethod;

    public bool IsScriptMethod => this._isScriptMethod;

    public override bool Equals(object obj)
    {
      if (object.ReferenceEquals(obj, (object) this))
        return true;
      return obj is ExtenderControlMethodAttribute controlMethodAttribute && controlMethodAttribute._isScriptMethod == this._isScriptMethod;
    }

    public override int GetHashCode() => this._isScriptMethod.GetHashCode();

    public override bool IsDefaultAttribute() => this.Equals((object) ExtenderControlMethodAttribute.Default);
  }
}
