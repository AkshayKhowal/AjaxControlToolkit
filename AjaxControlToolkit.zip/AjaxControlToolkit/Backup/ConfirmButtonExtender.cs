﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ConfirmButtonExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ToolboxBitmap(typeof (ConfirmButtonExtender), "ConfirmButton.ConfirmButton.ico")]
  [TargetControlType(typeof (IButtonControl))]
  [Designer("AjaxControlToolkit.ConfirmButtonDesigner, AjaxControlToolkit")]
  [ClientScriptResource("AjaxControlToolkit.ConfirmButtonBehavior", "AjaxControlToolkit.ConfirmButton.confirmButtonBehavior.js")]
  public class ConfirmButtonExtender : ExtenderControlBase
  {
    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      ScriptManager.RegisterOnSubmitStatement((Control) this, typeof (ConfirmButtonExtender), "ConfirmButtonExtenderOnSubmit", "null;");
      this.RegisterDisplayModalPopup();
    }

    public void RegisterDisplayModalPopup()
    {
      if (string.IsNullOrEmpty(this.DisplayModalPopupID))
        return;
      if (!(this.FindControlHelper(this.DisplayModalPopupID) is ModalPopupExtender controlHelper))
        throw new ArgumentException("Unable to find specified ModalPopupExtender.");
      if (controlHelper.TargetControlID != this.TargetControlID)
        throw new ArgumentException("ConfirmButton and the ModalPopupExtender specified by its DisplayModalPopupID must specify the same TargetControlID.");
      if (string.IsNullOrEmpty(controlHelper.OkControlID) && string.IsNullOrEmpty(controlHelper.CancelControlID))
        throw new ArgumentException("Specified ModalPopupExtender must set at least OkControlID and/or CancelControlID.");
      if (!string.IsNullOrEmpty(controlHelper.OnOkScript) || !string.IsNullOrEmpty(controlHelper.OnCancelScript))
        throw new ArgumentException("Specified ModalPopupExtender may not set OnOkScript or OnCancelScript.");
      Button child = new Button();
      child.ID = this.ID + "_CBE_MPE_Placeholder";
      child.Style[HtmlTextWriterStyle.Display] = "none";
      this.Controls.Add((Control) child);
      controlHelper.TargetControlID = child.ID;
      this.PostBackScript = this.Page.ClientScript.GetPostBackEventReference(this.TargetControl, "");
    }

    [ExtenderControlProperty]
    [RequiredProperty]
    public string ConfirmText
    {
      get => this.GetPropertyValue<string>(nameof (ConfirmText), "");
      set => this.SetPropertyValue<string>(nameof (ConfirmText), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string OnClientCancel
    {
      get => this.GetPropertyValue<string>(nameof (OnClientCancel), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientCancel), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool ConfirmOnFormSubmit
    {
      get => this.GetPropertyValue<bool>(nameof (ConfirmOnFormSubmit), false);
      set => this.SetPropertyValue<bool>(nameof (ConfirmOnFormSubmit), value);
    }

    [ClientPropertyName("displayModalPopupID")]
    [DefaultValue("")]
    [IDReferenceProperty(typeof (ModalPopupExtender))]
    [ExtenderControlProperty]
    public string DisplayModalPopupID
    {
      get => this.GetPropertyValue<string>(nameof (DisplayModalPopupID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (DisplayModalPopupID), value);
    }

    [ClientPropertyName("postBackScript")]
    [DefaultValue("")]
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [ExtenderControlProperty]
    public string PostBackScript
    {
      get => this.GetPropertyValue<string>(nameof (PostBackScript), string.Empty);
      set => this.SetPropertyValue<string>(nameof (PostBackScript), value);
    }
  }
}
