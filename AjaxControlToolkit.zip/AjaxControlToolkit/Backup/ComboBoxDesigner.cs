﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ComboBoxDesigner
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel.Design;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.UI.Design.WebControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  public class ComboBoxDesigner : ListControlDesigner
  {
    public override string GetDesignTimeHtml()
    {
      ListControl viewControl = (ListControl) this.ViewControl;
      System.Web.UI.WebControls.ListItem[] items = new System.Web.UI.WebControls.ListItem[viewControl.Items.Count];
      viewControl.Items.CopyTo((Array) items, 0);
      string designTimeHtml = base.GetDesignTimeHtml();
      viewControl.Items.Clear();
      viewControl.Items.AddRange(items);
      return "<style>" + new Regex("(<%=)\\s*(WebResource\\(\")(?<resourceName>.+)\\s*(\"\\)%>)").Replace(new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("AjaxControlToolkit.ComboBox.ComboBox.css")).ReadToEnd(), new MatchEvaluator(this.PerformWebResourceSubstitution)) + "</style>" + designTimeHtml;
    }

    protected virtual string PerformWebResourceSubstitution(Match match) => match.ToString().Replace(match.Value, this.ViewControl.Page.ClientScript.GetWebResourceUrl(this.GetType(), match.Groups["resourceName"].Value));

    public override bool AllowResize => false;

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        DesignerActionListCollection actionLists = new DesignerActionListCollection();
        actionLists.AddRange(base.ActionLists);
        actionLists.Add((DesignerActionList) new ComboBoxDesignerActionList(this.Component));
        return actionLists;
      }
    }
  }
}
