﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HoverMenuExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (HoverExtender))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ToolboxBitmap(typeof (HoverMenuExtender), "HoverMenu.HoverMenu.ico")]
  [ClientScriptResource("AjaxControlToolkit.HoverMenuBehavior", "AjaxControlToolkit.HoverMenu.HoverMenuBehavior.js")]
  [Designer("AjaxControlToolkit.HoverMenuDesigner, AjaxControlToolkit")]
  [RequiredScript(typeof (PopupExtender))]
  [RequiredScript(typeof (AnimationExtender))]
  [TargetControlType(typeof (Control))]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  public class HoverMenuExtender : DynamicPopulateExtenderControlBase
  {
    private Animation _onShow;
    private Animation _onHide;

    [RequiredProperty]
    [ElementReference]
    [ClientPropertyName("popupElement")]
    [IDReferenceProperty(typeof (WebControl))]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string PopupControlID
    {
      get => this.GetPropertyValue<string>(nameof (PopupControlID), "");
      set => this.SetPropertyValue<string>(nameof (PopupControlID), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string HoverCssClass
    {
      get => this.GetPropertyValue<string>(nameof (HoverCssClass), "");
      set => this.SetPropertyValue<string>(nameof (HoverCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int OffsetX
    {
      get => this.GetPropertyValue<int>(nameof (OffsetX), 0);
      set => this.SetPropertyValue<int>(nameof (OffsetX), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int OffsetY
    {
      get => this.GetPropertyValue<int>(nameof (OffsetY), 0);
      set => this.SetPropertyValue<int>(nameof (OffsetY), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int PopDelay
    {
      get => this.GetPropertyValue<int>(nameof (PopDelay), 0);
      set => this.SetPropertyValue<int>(nameof (PopDelay), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int HoverDelay
    {
      get => this.GetPropertyValue<int>(nameof (HoverDelay), 0);
      set => this.SetPropertyValue<int>(nameof (HoverDelay), value);
    }

    [DefaultValue(HoverMenuPopupPosition.Center)]
    [ExtenderControlProperty]
    public HoverMenuPopupPosition PopupPosition
    {
      get => this.GetPropertyValue<HoverMenuPopupPosition>("Position", HoverMenuPopupPosition.Center);
      set => this.SetPropertyValue<HoverMenuPopupPosition>("Position", value);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [DefaultValue(null)]
    [ExtenderControlProperty]
    [ClientPropertyName("onShow")]
    [Browsable(false)]
    public Animation OnShow
    {
      get => this.GetAnimation(ref this._onShow, nameof (OnShow));
      set => this.SetAnimation(ref this._onShow, nameof (OnShow), value);
    }

    [Browsable(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("onHide")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [DefaultValue(null)]
    public Animation OnHide
    {
      get => this.GetAnimation(ref this._onHide, nameof (OnHide));
      set => this.SetAnimation(ref this._onHide, nameof (OnHide), value);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      this.ResolveControlIDs(this._onShow);
      this.ResolveControlIDs(this._onHide);
    }
  }
}
