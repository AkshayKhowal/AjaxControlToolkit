﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MaskedEditValidator
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ToolboxBitmap(typeof (MaskedEditValidator), "MaskedEdit.MaskedEdit.ico")]
  public class MaskedEditValidator : BaseValidator
  {
    private bool _IsValidEmpty = true;
    private string _MessageTip = "";
    private string _MessageInvalid = "";
    private string _MessageEmpty = "";
    private string _MessageMax = "";
    private string _MessageMin = "";
    private string _TextInvalid = "";
    private string _TextEmpty = "";
    private string _TextMax = "";
    private string _TextMin = "";
    private string _InitialValue = "";
    private string _ValidationExpression = "";
    private string _ClientValidationFunction = "";
    private string _MaximumValue = "";
    private string _MinimumValue = "";
    private string _ControlExtender = "";
    private CultureInfo _Culture;

    public event EventHandler<ServerValidateEventArgs> MaskedEditServerValidator;

    protected CultureInfo ControlCulture
    {
      get
      {
        if (this._Culture == null)
          this._Culture = CultureInfo.CurrentCulture;
        return this._Culture;
      }
      set => this._Culture = value;
    }

    public new string ErrorMessage
    {
      get
      {
        if (string.IsNullOrEmpty(base.ErrorMessage))
          base.ErrorMessage = this.ID;
        return base.ErrorMessage;
      }
      set => base.ErrorMessage = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue(true)]
    public bool IsValidEmpty
    {
      get => this._IsValidEmpty;
      set => this._IsValidEmpty = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string TooltipMessage
    {
      get => this._MessageTip == null ? string.Empty : this._MessageTip;
      set => this._MessageTip = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string EmptyValueMessage
    {
      get => this._MessageEmpty == null ? string.Empty : this._MessageEmpty;
      set => this._MessageEmpty = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string EmptyValueBlurredText
    {
      get => this._TextEmpty == null ? string.Empty : this._TextEmpty;
      set => this._TextEmpty = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string InvalidValueMessage
    {
      get => this._MessageInvalid == null ? string.Empty : this._MessageInvalid;
      set => this._MessageInvalid = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string InvalidValueBlurredMessage
    {
      get => this._TextInvalid == null ? string.Empty : this._TextInvalid;
      set => this._TextInvalid = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string MaximumValue
    {
      get => this._MaximumValue == null ? string.Empty : this._MaximumValue;
      set => this._MaximumValue = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string MaximumValueMessage
    {
      get => this._MessageMax == null ? string.Empty : this._MessageMax;
      set => this._MessageMax = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string MaximumValueBlurredMessage
    {
      get => this._TextMax == null ? string.Empty : this._TextMax;
      set => this._TextMax = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string ClientValidationFunction
    {
      get => this._ClientValidationFunction == null ? string.Empty : this._ClientValidationFunction;
      set => this._ClientValidationFunction = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string InitialValue
    {
      get => this._InitialValue == null ? string.Empty : this._InitialValue;
      set => this._InitialValue = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string ValidationExpression
    {
      get => this._ValidationExpression == null ? string.Empty : this._ValidationExpression;
      set => this._ValidationExpression = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string MinimumValue
    {
      get => this._MinimumValue == null ? string.Empty : this._MinimumValue;
      set => this._MinimumValue = value;
    }

    [DefaultValue("")]
    [Category("MaskedEdit")]
    public string MinimumValueMessage
    {
      get => this._MessageMin == null ? string.Empty : this._MessageMin;
      set => this._MessageMin = value;
    }

    [Category("MaskedEdit")]
    [DefaultValue("")]
    public string MinimumValueBlurredText
    {
      get => this._TextMin == null ? string.Empty : this._TextMin;
      set => this._TextMin = value;
    }

    [TypeConverter(typeof (MaskedEditTypeConvert))]
    [DefaultValue("")]
    [RequiredProperty]
    [Category("MaskedEdit")]
    public string ControlExtender
    {
      get => this._ControlExtender == null ? string.Empty : this._ControlExtender;
      set => this._ControlExtender = value;
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      if (!this.EnableClientScript)
        return;
      ScriptManager.RegisterClientScriptResource((Control) this, typeof (MaskedEditValidator), "AjaxControlToolkit.MaskedEdit.MaskedEditValidator.js");
      MaskedEditExtender control1 = (MaskedEditExtender) this.FindControl(this.ControlExtender);
      TextBox control2 = (TextBox) control1.FindControl(this.ControlToValidate);
      int num1;
      int num2;
      if (control1.ClearMaskOnLostFocus)
      {
        num1 = 0;
        num2 = MaskedEditCommon.GetValidMask(control1.Mask).Length + 1;
      }
      else
      {
        num1 = MaskedEditCommon.GetFirstMaskPosition(control1.Mask);
        num2 = MaskedEditCommon.GetLastMaskPosition(control1.Mask) + 1;
      }
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "IsMaskedEdit", true.ToString().ToLower(CultureInfo.InvariantCulture), true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "ValidEmpty", this.IsValidEmpty.ToString().ToLower(CultureInfo.InvariantCulture), true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MaximumValue", this.MaximumValue, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MinimumValue", this.MinimumValue, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "InitialValue", this.InitialValue, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "ValidationExpression", this.ValidationExpression, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "ClientValidationFunction", this.ClientValidationFunction, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "TargetValidator", control2.ClientID, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "EmptyValueMessage", this.EmptyValueMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "EmptyValueText", this.EmptyValueBlurredText, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MaximumValueMessage", this.MaximumValueMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MaximumValueText", this.MaximumValueBlurredMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MinimumValueMessage", this.MinimumValueMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "MinimumValueText", this.MinimumValueBlurredText, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "InvalidValueMessage", this.InvalidValueMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "InvalidValueText", this.InvalidValueBlurredMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "InvalidValueCssClass", control1.OnInvalidCssClass, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "CssBlurNegative", control1.OnBlurCssNegative, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "CssFocus", control1.OnFocusCssClass, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "CssFocusNegative", control1.OnFocusCssNegative, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "TooltipMessage", this.TooltipMessage, true);
      ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "FirstMaskPosition", num1.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
      this.ControlCulture = string.IsNullOrEmpty(control1.CultureName) || !control1.OverridePageCulture ? CultureInfo.CurrentCulture : CultureInfo.GetCultureInfo(control1.CultureName);
      switch (control1.MaskType)
      {
        case MaskedEditType.None:
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "evaluationfunction", "MaskedEditValidatorNone", true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "LastMaskPosition", num2.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          break;
        case MaskedEditType.Date:
          string dateSeparator1 = this.ControlCulture.DateTimeFormat.DateSeparator;
          string[] strArray1 = this.ControlCulture.DateTimeFormat.ShortDatePattern.Split(char.Parse(this.ControlCulture.DateTimeFormat.DateSeparator));
          string str1 = strArray1[0].Substring(0, 1).ToUpper(this.ControlCulture) + strArray1[1].Substring(0, 1).ToUpper(this.ControlCulture) + strArray1[2].Substring(0, 1).ToUpper(this.ControlCulture);
          string attributeValue1 = control1.UserDateFormat == MaskedEditUserDateFormat.None ? str1 : control1.UserDateFormat.ToString();
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "DateSeparator", dateSeparator1, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "DateFormat", attributeValue1, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "Century", control1.Century.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "evaluationfunction", "MaskedEditValidatorDate", true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "LastMaskPosition", num2.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          break;
        case MaskedEditType.Number:
          string currencySymbol = this.ControlCulture.NumberFormat.CurrencySymbol;
          string decimalSeparator = this.ControlCulture.NumberFormat.CurrencyDecimalSeparator;
          string currencyGroupSeparator = this.ControlCulture.NumberFormat.CurrencyGroupSeparator;
          if (control1.DisplayMoney != MaskedEditShowSymbol.None)
            num2 += control1.CultureCurrencySymbolPlaceholder.Length + 1;
          if (control1.AcceptNegative != MaskedEditShowSymbol.None)
          {
            if (control1.DisplayMoney != MaskedEditShowSymbol.None)
              ++num2;
            else
              num2 += 2;
          }
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "Money", currencySymbol, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "Decimal", decimalSeparator, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "Thousands", currencyGroupSeparator, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "evaluationfunction", "MaskedEditValidatorNumber", true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "LastMaskPosition", num2.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          break;
        case MaskedEditType.Time:
          string timeSeparator1 = this.ControlCulture.DateTimeFormat.TimeSeparator;
          string str2 = !string.IsNullOrEmpty(this.ControlCulture.DateTimeFormat.AMDesignator + this.ControlCulture.DateTimeFormat.PMDesignator) ? this.ControlCulture.DateTimeFormat.AMDesignator + ";" + this.ControlCulture.DateTimeFormat.PMDesignator : "";
          string attributeValue2 = control1.UserTimeFormat == MaskedEditUserTimeFormat.None ? str2 : "";
          if (control1.AcceptAMPM && !string.IsNullOrEmpty(attributeValue2))
          {
            char ch = char.Parse(timeSeparator1);
            string[] strArray2 = attributeValue2.Split(ch);
            num2 += strArray2[0].Length + 1;
          }
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "TimeSeparator", timeSeparator1, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "AmPmSymbol", attributeValue2, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "evaluationfunction", "MaskedEditValidatorTime", true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "LastMaskPosition", num2.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          break;
        case MaskedEditType.DateTime:
          string dateSeparator2 = this.ControlCulture.DateTimeFormat.DateSeparator;
          string[] strArray3 = this.ControlCulture.DateTimeFormat.ShortDatePattern.Split(char.Parse(this.ControlCulture.DateTimeFormat.DateSeparator));
          string str3 = strArray3[0].Substring(0, 1).ToUpper(this.ControlCulture) + strArray3[1].Substring(0, 1).ToUpper(this.ControlCulture) + strArray3[2].Substring(0, 1).ToUpper(this.ControlCulture);
          string attributeValue3 = control1.UserDateFormat == MaskedEditUserDateFormat.None ? str3 : control1.UserDateFormat.ToString();
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "DateSeparator", dateSeparator2, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "DateFormat", attributeValue3, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "Century", control1.Century.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          string timeSeparator2 = this.ControlCulture.DateTimeFormat.TimeSeparator;
          string str4 = !string.IsNullOrEmpty(this.ControlCulture.DateTimeFormat.AMDesignator + this.ControlCulture.DateTimeFormat.PMDesignator) ? this.ControlCulture.DateTimeFormat.AMDesignator + ";" + this.ControlCulture.DateTimeFormat.PMDesignator : "";
          string attributeValue4 = control1.UserTimeFormat == MaskedEditUserTimeFormat.None ? str4 : "";
          if (control1.AcceptAMPM && !string.IsNullOrEmpty(attributeValue4))
          {
            char ch = char.Parse(timeSeparator2);
            string[] strArray4 = attributeValue4.Split(ch);
            num2 += strArray4[0].Length + 1;
          }
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "TimeSeparator", timeSeparator2, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "AmPmSymbol", attributeValue4, true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "evaluationfunction", "MaskedEditValidatorDateTime", true);
          ScriptManager.RegisterExpandoAttribute((Control) this, this.ClientID, "LastMaskPosition", num2.ToString((IFormatProvider) CultureInfo.InvariantCulture), true);
          break;
      }
    }

    protected override bool ControlPropertiesValid() => this.FindControl(this.ControlToValidate) is TextBox;

    protected override bool EvaluateIsValid()
    {
      MaskedEditExtender control1 = (MaskedEditExtender) this.FindControl(this.ControlExtender);
      TextBox control2 = (TextBox) control1.FindControl(this.ControlToValidate);
      base.ErrorMessage = "";
      this.Text = "";
      string str1 = "";
      bool isValid = true;
      if (!this.IsValidEmpty && control2.Text.Trim() == this.InitialValue)
      {
        base.ErrorMessage = this.EmptyValueMessage;
        if (string.IsNullOrEmpty(this.EmptyValueBlurredText))
          this.Text = base.ErrorMessage;
        else
          this.Text = this.EmptyValueBlurredText;
        str1 = control1.OnInvalidCssClass;
        isValid = false;
      }
      if (isValid && control2.Text.Length != 0)
      {
        if (this.ValidationExpression.Length != 0)
        {
          try
          {
            isValid = new Regex(this.ValidationExpression).IsMatch(control2.Text);
          }
          catch
          {
            isValid = false;
          }
        }
      }
      if (isValid && control2.Text.Length != 0)
      {
        if (string.IsNullOrEmpty(control1.CultureName))
        {
          string name = CultureInfo.CurrentCulture.Name;
        }
        string str2 = "";
        if (!string.IsNullOrEmpty(this.ControlCulture.DateTimeFormat.AMDesignator) && !string.IsNullOrEmpty(this.ControlCulture.DateTimeFormat.PMDesignator))
          str2 = this.ControlCulture.DateTimeFormat.AMDesignator + ";" + this.ControlCulture.DateTimeFormat.PMDesignator;
        switch (control1.MaskType)
        {
          case MaskedEditType.Date:
          case MaskedEditType.Time:
          case MaskedEditType.DateTime:
            int length = control2.Text.Length;
            if (control1.AcceptAMPM && !string.IsNullOrEmpty(str2) && (control1.MaskType == MaskedEditType.Time || control1.MaskType == MaskedEditType.DateTime))
            {
              char[] chArray = new char[1]{ ';' };
              string[] strArray = str2.Split(chArray);
              if (strArray[0].Length != 0)
                length -= strArray[0].Length + 1;
            }
            if (MaskedEditCommon.GetValidMask(control1.Mask).Length != length)
              isValid = false;
            if (isValid)
            {
              try
              {
                DateTime.Parse(control2.Text, (IFormatProvider) this.ControlCulture);
                break;
              }
              catch
              {
                isValid = false;
                break;
              }
            }
            else
              break;
          case MaskedEditType.Number:
            try
            {
              Decimal.Parse(control2.Text, (IFormatProvider) this.ControlCulture);
              break;
            }
            catch
            {
              isValid = false;
              break;
            }
        }
        if (!isValid)
        {
          base.ErrorMessage = this.InvalidValueMessage;
          if (string.IsNullOrEmpty(this.InvalidValueBlurredMessage))
            this.Text = base.ErrorMessage;
          else
            this.Text = this.InvalidValueBlurredMessage;
          str1 = control1.OnInvalidCssClass;
        }
        if (isValid && (!string.IsNullOrEmpty(this.MaximumValue) || !string.IsNullOrEmpty(this.MinimumValue)))
        {
          switch (control1.MaskType)
          {
            case MaskedEditType.None:
              if (!string.IsNullOrEmpty(this.MaximumValue))
              {
                try
                {
                  isValid = int.Parse(this.MaximumValue, (IFormatProvider) this.ControlCulture) >= control2.Text.Length;
                }
                catch
                {
                  base.ErrorMessage = this.InvalidValueMessage;
                  if (string.IsNullOrEmpty(this.InvalidValueBlurredMessage))
                    this.Text = base.ErrorMessage;
                  else
                    this.Text = this.InvalidValueBlurredMessage;
                  isValid = false;
                }
                if (!isValid)
                {
                  base.ErrorMessage = this.MaximumValueMessage;
                  if (string.IsNullOrEmpty(this.MaximumValueBlurredMessage))
                    this.Text = base.ErrorMessage;
                  else
                    this.Text = this.MaximumValueBlurredMessage;
                  str1 = control1.OnInvalidCssClass;
                }
              }
              if (isValid)
              {
                if (!string.IsNullOrEmpty(this.MinimumValue))
                {
                  try
                  {
                    isValid = int.Parse(this.MinimumValue, (IFormatProvider) this.ControlCulture) <= control2.Text.Length;
                  }
                  catch
                  {
                    base.ErrorMessage = this.InvalidValueMessage;
                    if (string.IsNullOrEmpty(this.InvalidValueBlurredMessage))
                      this.Text = base.ErrorMessage;
                    else
                      this.Text = this.InvalidValueBlurredMessage;
                    isValid = false;
                  }
                  if (!isValid)
                  {
                    base.ErrorMessage = this.MinimumValueMessage;
                    if (string.IsNullOrEmpty(this.MinimumValueBlurredText))
                      this.Text = base.ErrorMessage;
                    else
                      this.Text = this.MinimumValueBlurredText;
                    str1 = control1.OnInvalidCssClass;
                    break;
                  }
                  break;
                }
                break;
              }
              break;
            case MaskedEditType.Date:
            case MaskedEditType.Time:
            case MaskedEditType.DateTime:
              DateTime dateTime = DateTime.Parse(control2.Text, (IFormatProvider) this.ControlCulture);
              if (!string.IsNullOrEmpty(this.MaximumValue))
              {
                try
                {
                  isValid = DateTime.Parse(this.MaximumValue, (IFormatProvider) this.ControlCulture) >= dateTime;
                }
                catch
                {
                  isValid = false;
                }
                if (!isValid)
                {
                  base.ErrorMessage = this.MaximumValueMessage;
                  if (string.IsNullOrEmpty(this.MaximumValueBlurredMessage))
                    this.Text = base.ErrorMessage;
                  else
                    this.Text = this.MaximumValueBlurredMessage;
                  str1 = control1.OnInvalidCssClass;
                }
              }
              if (isValid)
              {
                if (!string.IsNullOrEmpty(this.MinimumValue))
                {
                  try
                  {
                    isValid = DateTime.Parse(this.MinimumValue, (IFormatProvider) this.ControlCulture) <= dateTime;
                  }
                  catch
                  {
                    isValid = false;
                  }
                  if (!isValid)
                  {
                    base.ErrorMessage = this.MinimumValueMessage;
                    if (string.IsNullOrEmpty(this.MinimumValueBlurredText))
                      this.Text = base.ErrorMessage;
                    else
                      this.Text = this.MinimumValueBlurredText;
                    str1 = control1.OnInvalidCssClass;
                    break;
                  }
                  break;
                }
                break;
              }
              break;
            case MaskedEditType.Number:
              Decimal num = Decimal.Parse(control2.Text, (IFormatProvider) this.ControlCulture);
              if (!string.IsNullOrEmpty(this.MaximumValue))
              {
                try
                {
                  isValid = Decimal.Parse(this.MaximumValue, (IFormatProvider) this.ControlCulture) >= num;
                }
                catch
                {
                  isValid = false;
                }
                if (!isValid)
                {
                  base.ErrorMessage = this.MaximumValueMessage;
                  if (string.IsNullOrEmpty(this.MaximumValueBlurredMessage))
                    this.Text = base.ErrorMessage;
                  else
                    this.Text = this.MaximumValueBlurredMessage;
                  str1 = control1.OnInvalidCssClass;
                }
              }
              if (isValid)
              {
                if (!string.IsNullOrEmpty(this.MinimumValue))
                {
                  try
                  {
                    isValid = Decimal.Parse(this.MinimumValue, (IFormatProvider) this.ControlCulture) <= num;
                  }
                  catch
                  {
                    isValid = false;
                  }
                  if (!isValid)
                  {
                    base.ErrorMessage = this.MinimumValueMessage;
                    if (string.IsNullOrEmpty(this.MinimumValueBlurredText))
                      this.Text = base.ErrorMessage;
                    else
                      this.Text = this.MinimumValueBlurredText;
                    str1 = control1.OnInvalidCssClass;
                    break;
                  }
                  break;
                }
                break;
              }
              break;
          }
        }
      }
      if (isValid && this.MaskedEditServerValidator != null)
      {
        ServerValidateEventArgs e = new ServerValidateEventArgs(control2.Text, isValid);
        this.MaskedEditServerValidator((object) control2, e);
        isValid = e.IsValid;
        if (!isValid)
        {
          str1 = control1.OnInvalidCssClass;
          base.ErrorMessage = this.InvalidValueMessage;
          if (string.IsNullOrEmpty(this.InvalidValueBlurredMessage))
            this.Text = base.ErrorMessage;
          else
            this.Text = this.InvalidValueBlurredMessage;
        }
      }
      if (!isValid)
        ScriptManager.RegisterStartupScript((Control) this, typeof (MaskedEditValidator), "MaskedEditServerValidator_" + this.ID, "MaskedEditSetCssClass(" + this.ClientID + ",'" + str1 + "');", true);
      return isValid;
    }
  }
}
