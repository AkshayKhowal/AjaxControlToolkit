﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ExtenderControlBase
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [PersistChildren(false)]
  [Themeable(true)]
  [ClientScriptResource(null, "AjaxControlToolkit.ExtenderBase.BaseScripts.js")]
  [ParseChildren(true)]
  public abstract class ExtenderControlBase : ExtenderControl, IControlResolver
  {
    private Dictionary<string, Control> _findControlHelperCache = new Dictionary<string, Control>();
    private bool _renderingScript;
    private bool _loadedClientStateValues;
    private bool _isDisposed;
    internal static string[] ForceSerializationProps = new string[1]
    {
      nameof (ClientStateFieldID)
    };
    private bool _enableClientState;
    private string _clientState;
    private ProfilePropertyBindingCollection _profileBindings;

    [Browsable(true)]
    public override string SkinID
    {
      get => base.SkinID;
      set => base.SkinID = value;
    }

    public event ResolveControlEventHandler ResolveControlID;

    protected virtual bool AllowScriptPath => true;

    protected virtual string ClientControlType => ((ClientScriptResourceAttribute) TypeDescriptor.GetAttributes((object) this)[typeof (ClientScriptResourceAttribute)]).ComponentType;

    public bool Enabled
    {
      get => !this._isDisposed && this.GetPropertyValue<bool>(nameof (Enabled), true);
      set => this.SetPropertyValue<bool>(nameof (Enabled), value);
    }

    protected bool IsRenderingScript => this._renderingScript;

    public string ScriptPath
    {
      get => this.GetPropertyValue<string>(nameof (ScriptPath), (string) null);
      set
      {
        if (!this.AllowScriptPath)
          throw new InvalidOperationException("This class does not allow setting of ScriptPath.");
        this.SetPropertyValue<string>(nameof (ScriptPath), value);
      }
    }

    public override void Dispose()
    {
      this._isDisposed = true;
      base.Dispose();
      GC.SuppressFinalize((object) this);
    }

    internal IEnumerable<ScriptReference> EnsureScripts()
    {
      List<ScriptReference> scriptReferenceList = new List<ScriptReference>();
      scriptReferenceList.AddRange(ScriptObjectBuilder.GetScriptReferences(this.GetType(), null != this.ScriptPath));
      string scriptPath = this.ScriptPath;
      if (!string.IsNullOrEmpty(scriptPath))
        scriptReferenceList.Add(new ScriptReference(scriptPath));
      return (IEnumerable<ScriptReference>) scriptReferenceList;
    }

    protected Control FindControlHelper(string id)
    {
      Control control;
      if (this._findControlHelperCache.ContainsKey(id))
      {
        control = this._findControlHelperCache[id];
      }
      else
      {
        control = base.FindControl(id);
        for (Control namingContainer = this.NamingContainer; control == null && namingContainer != null; namingContainer = namingContainer.NamingContainer)
          control = namingContainer.FindControl(id);
        if (control == null)
        {
          ResolveControlEventArgs e = new ResolveControlEventArgs(id);
          this.OnResolveControlID(e);
          control = e.Control;
        }
        if (control != null)
          this._findControlHelperCache[id] = control;
      }
      return control;
    }

    public override Control FindControl(string id) => this.FindControlHelper(id);

    protected Control TargetControl => this.FindControlHelper(this.TargetControlID);

    [ClientPropertyName("id")]
    [ExtenderControlProperty]
    public string BehaviorID
    {
      get
      {
        string propertyValue = this.GetPropertyValue<string>(nameof (BehaviorID), "");
        return !string.IsNullOrEmpty(propertyValue) ? propertyValue : this.ClientID;
      }
      set => this.SetPropertyValue<string>(nameof (BehaviorID), value);
    }

    protected string GetClientID(string controlId)
    {
      Control controlHelper = this.FindControlHelper(controlId);
      if (controlHelper != null)
        controlId = controlHelper.ClientID;
      return controlId;
    }

    private string GetClientStateFieldID() => string.Format((IFormatProvider) CultureInfo.InvariantCulture, "{0}_ClientState", (object) this.ID);

    protected override void OnInit(EventArgs e)
    {
      if (this.EnableClientState)
        this.CreateClientStateField();
      this.Page.PreLoad += new EventHandler(this.Page_PreLoad);
      base.OnInit(e);
    }

    private void Page_PreLoad(object sender, EventArgs e) => this.LoadClientStateValues();

    protected override void OnLoad(EventArgs e)
    {
      if (!this._loadedClientStateValues)
        this.LoadClientStateValues();
      base.OnLoad(e);
      ScriptObjectBuilder.RegisterCssReferences((Control) this);
    }

    private HiddenField CreateClientStateField()
    {
      HiddenField child = new HiddenField();
      child.ID = this.GetClientStateFieldID();
      this.Controls.Add((Control) child);
      this.ClientStateFieldID = child.ID;
      return child;
    }

    private void LoadClientStateValues()
    {
      if (this.EnableClientState && !string.IsNullOrEmpty(this.ClientStateFieldID))
      {
        HiddenField control = (HiddenField) this.NamingContainer.FindControl(this.ClientStateFieldID);
        if (control != null && !string.IsNullOrEmpty(control.Value))
          this.ClientState = control.Value;
      }
      if (this.ClientStateValuesLoaded != null)
        this.ClientStateValuesLoaded((object) this, EventArgs.Empty);
      this._loadedClientStateValues = true;
    }

    protected event EventHandler ClientStateValuesLoaded;

    protected override void Render(HtmlTextWriter writer)
    {
      if (this.Page != null)
        this.Page.VerifyRenderingInServerForm((Control) this);
      base.Render(writer);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      if (!this.Enabled || !this.TargetControl.Visible)
        return;
      this.SaveClientStateValues();
    }

    protected virtual void OnResolveControlID(ResolveControlEventArgs e)
    {
      if (this.ResolveControlID == null)
        return;
      this.ResolveControlID((object) this, e);
    }

    protected virtual void RenderInnerScript(ScriptBehaviorDescriptor descriptor)
    {
    }

    protected virtual void RenderScriptAttributes(ScriptBehaviorDescriptor descriptor)
    {
      try
      {
        this._renderingScript = true;
        ScriptObjectBuilder.DescribeComponent((object) this, (ScriptComponentDescriptor) descriptor, (IUrlResolutionService) this, (IControlResolver) this);
      }
      finally
      {
        this._renderingScript = false;
      }
    }

    protected override IEnumerable<ScriptDescriptor> GetScriptDescriptors(
      Control targetControl)
    {
      if (!this.Enabled || !targetControl.Visible)
        return (IEnumerable<ScriptDescriptor>) null;
      this.EnsureValid();
      ScriptBehaviorDescriptor descriptor = new ScriptBehaviorDescriptor(this.ClientControlType, targetControl.ClientID);
      this.RenderScriptAttributes(descriptor);
      this.RenderInnerScript(descriptor);
      return (IEnumerable<ScriptDescriptor>) new List<ScriptDescriptor>((IEnumerable<ScriptDescriptor>) new ScriptDescriptor[1]
      {
        (ScriptDescriptor) descriptor
      });
    }

    protected override IEnumerable<ScriptReference> GetScriptReferences() => this.Enabled ? this.EnsureScripts() : (IEnumerable<ScriptReference>) null;

    private void SaveClientStateValues()
    {
      if (!this.EnableClientState)
        return;
      HiddenField hiddenField = !string.IsNullOrEmpty(this.ClientStateFieldID) ? (HiddenField) this.NamingContainer.FindControl(this.ClientStateFieldID) : this.CreateClientStateField();
      if (hiddenField == null)
        return;
      hiddenField.Value = this.ClientState;
    }

    private bool ShouldSerializeBehaviorID() => this.IsRenderingScript || 0 != string.Compare(this.ClientID, this.BehaviorID, StringComparison.OrdinalIgnoreCase);

    [Obsolete("Replaced by a call to ScriptObjectBuilder")]
    protected object SerializeProperty(PropertyDescriptor prop) => this.SerializeProperty(prop, false);

    [Obsolete("Replaced by a call to ScriptObjectBuilder")]
    protected virtual object SerializeProperty(PropertyDescriptor prop, bool force)
    {
      if (prop == null)
        return (object) null;
      object obj = prop.GetValue((object) this);
      if (obj != null)
      {
        bool flag = prop.ShouldSerializeValue((object) this);
        if (flag)
        {
          DesignerSerializationVisibilityAttribute attribute = (DesignerSerializationVisibilityAttribute) prop.Attributes[typeof (DesignerSerializationVisibilityAttribute)];
          if (attribute != null && attribute.Visibility == DesignerSerializationVisibility.Hidden)
            flag = -1 != Array.IndexOf<string>(ExtenderControlBase.ForceSerializationProps, prop.Name);
        }
        if (!force && !flag)
          return (object) null;
        if (!prop.PropertyType.IsPrimitive && !prop.PropertyType.IsEnum)
          obj = prop.PropertyType != typeof (Color) ? (object) prop.Converter.ConvertToString((ITypeDescriptorContext) null, CultureInfo.InvariantCulture, obj) : (object) ColorTranslator.ToHtml((Color) obj);
        if (prop.PropertyType == typeof (string) && prop.Attributes[typeof (UrlPropertyAttribute)] != null)
          obj = (object) this.ResolveClientUrl((string) obj);
      }
      return obj;
    }

    [PersistenceMode(PersistenceMode.InnerProperty)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Obsolete("WARNING: ProfileBindings are disabled for this Toolkit release pending technical issues.  We hope to re-enable this in an upcoming release")]
    [Browsable(false)]
    public ProfilePropertyBindingCollection ProfileBindings
    {
      get
      {
        if (this._profileBindings == null)
          this._profileBindings = new ProfilePropertyBindingCollection();
        return this._profileBindings;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    private bool ShouldSerializeProfileBindings() => false;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public string ClientState
    {
      get => this._clientState;
      set => this._clientState = value;
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ExtenderControlProperty]
    [IDReferenceProperty(typeof (HiddenField))]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DefaultValue("")]
    public string ClientStateFieldID
    {
      get => this.GetPropertyValue<string>(nameof (ClientStateFieldID), "");
      set => this.SetPropertyValue<string>(nameof (ClientStateFieldID), value);
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool EnableClientState
    {
      get => this._enableClientState;
      set => this._enableClientState = value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeClientStateFieldID() => this.EnableClientState;

    protected static void SuppressUnusedParameterWarning(object unused) => unused?.GetType();

    protected virtual bool CheckIfValid(bool throwException)
    {
      bool flag = true;
      foreach (PropertyDescriptor property in TypeDescriptor.GetProperties((object) this))
      {
        if (property.Attributes[typeof (RequiredPropertyAttribute)] != null && (property.GetValue((object) this) == null || !property.ShouldSerializeValue((object) this)))
        {
          flag = false;
          if (throwException)
            throw new ArgumentException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "{0} missing required {1} property value for {2}.", (object) this.GetType().ToString(), (object) property.Name, (object) this.ID), property.Name);
        }
      }
      return flag;
    }

    public virtual void EnsureValid() => this.CheckIfValid(true);

    protected V GetPropertyValue<V>(string propertyName, V nullValue) => this.ViewState[propertyName] == null ? nullValue : (V) this.ViewState[propertyName];

    protected void SetPropertyValue<V>(string propertyName, V value) => this.ViewState[propertyName] = (object) value;

    [Obsolete("Use GetPropertyValue<V> instead")]
    protected string GetPropertyStringValue(string propertyName) => this.GetPropertyValue<string>(propertyName, "");

    [Obsolete("Use SetPropertyValue<V> instead")]
    protected void SetPropertyStringValue(string propertyName, string value) => this.SetPropertyValue<string>(propertyName, value);

    [Obsolete("Use GetPropertyValue<V> instead")]
    protected int GetPropertyIntValue(string propertyName) => this.GetPropertyValue<int>(propertyName, 0);

    [Obsolete("Use SetPropertyValue<V> instead")]
    protected void SetPropertyIntValue(string propertyName, int value) => this.SetPropertyValue<int>(propertyName, value);

    [Obsolete("Use GetPropertyValue<V> instead")]
    protected bool GetPropertyBoolValue(string propertyName) => this.GetPropertyValue<bool>(propertyName, false);

    [Obsolete("Use SetPropertyValue<V> instead")]
    protected void SetPropertyBoolValue(string propertyName, bool value) => this.SetPropertyValue<bool>(propertyName, value);

    public Control ResolveControl(string controlId) => this.FindControl(controlId);
  }
}
