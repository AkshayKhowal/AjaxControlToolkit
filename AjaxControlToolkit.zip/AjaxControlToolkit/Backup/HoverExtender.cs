﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HoverExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [Designer("AjaxControlToolkit.HoverExtenderDesigner, AjaxControlToolkit")]
  [ToolboxItem(false)]
  [TargetControlType(typeof (Control))]
  [ClientScriptResource("AjaxControlToolkit.HoverBehavior", "AjaxControlToolkit.HoverExtender.HoverBehavior.js")]
  public class HoverExtender : ExtenderControlBase
  {
    [ClientPropertyName("hoverDelay")]
    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int HoverDelay
    {
      get => this.GetPropertyValue<int>("hoverDelay", 0);
      set => this.SetPropertyValue<int>("hoverDelay", value);
    }

    [ClientPropertyName("hoverScript")]
    [ExtenderControlProperty]
    public string HoverScript
    {
      get => this.GetPropertyValue<string>(nameof (HoverScript), "");
      set => this.SetPropertyValue<string>(nameof (HoverScript), value);
    }

    [ClientPropertyName("unhoverDelay")]
    [DefaultValue(0)]
    [ExtenderControlProperty]
    public int UnhoverDelay
    {
      get => this.GetPropertyValue<int>(nameof (UnhoverDelay), 0);
      set => this.SetPropertyValue<int>(nameof (UnhoverDelay), value);
    }

    [ClientPropertyName("unhoverScript")]
    [ExtenderControlProperty]
    public string UnhoverScript
    {
      get => this.GetPropertyValue<string>(nameof (UnhoverScript), "");
      set => this.SetPropertyValue<string>(nameof (UnhoverScript), value);
    }
  }
}
