﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MaskedEditCommon
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Globalization;
using System.Text;

namespace AjaxControlToolkit
{
  public static class MaskedEditCommon
  {
    private const string _charEscape = "\\";
    private const string _CharsEditMask = "9L$CAN?";
    private const string _charNumbers = "0123456789";

    public static int GetFirstMaskPosition(string text)
    {
      bool flag = false;
      text = MaskedEditCommon.ConvertMask(text);
      for (int startIndex = 0; startIndex < text.Length; ++startIndex)
      {
        if (text.Substring(startIndex, 1) == "\\" && !flag)
        {
          flag = true;
        }
        else
        {
          if ("9L$CAN?".IndexOf(text.Substring(startIndex, 1), StringComparison.Ordinal) != -1 && !flag)
            return startIndex;
          if (flag)
            flag = false;
        }
      }
      return -1;
    }

    public static int GetLastMaskPosition(string text)
    {
      bool flag = false;
      text = MaskedEditCommon.ConvertMask(text);
      int lastMaskPosition = -1;
      for (int startIndex = 0; startIndex < text.Length; ++startIndex)
      {
        if (text.Substring(startIndex, 1) == "\\" && !flag)
          flag = true;
        else if ("9L$CAN?".IndexOf(text.Substring(startIndex, 1), StringComparison.Ordinal) != -1 && !flag)
          lastMaskPosition = startIndex;
        else if (flag)
          flag = false;
      }
      return lastMaskPosition;
    }

    public static string GetValidMask(string text)
    {
      int firstMaskPosition = MaskedEditCommon.GetFirstMaskPosition(text);
      int lastMaskPosition = MaskedEditCommon.GetLastMaskPosition(text);
      text = MaskedEditCommon.ConvertMask(text);
      return text.Substring(firstMaskPosition, lastMaskPosition - firstMaskPosition + 1);
    }

    public static string ConvertMask(string text)
    {
      if (text == null)
        throw new ArgumentNullException(nameof (text));
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      string str = "";
      for (int startIndex = 0; startIndex < text.Length; ++startIndex)
      {
        if ("9L$CAN?".IndexOf(text.Substring(startIndex, 1), StringComparison.Ordinal) != -1)
        {
          if (stringBuilder2.Length == 0)
          {
            stringBuilder1.Append(text.Substring(startIndex, 1));
            stringBuilder2.Length = 0;
            str = text.Substring(startIndex, 1);
          }
          else if (text.Substring(startIndex, 1) == "9")
            stringBuilder2.Append("9");
          else if (text.Substring(startIndex, 1) == "0")
            stringBuilder2.Append("0");
        }
        else if ("9L$CAN?".IndexOf(text.Substring(startIndex, 1), StringComparison.Ordinal) == -1 && text.Substring(startIndex, 1) != "{" && text.Substring(startIndex, 1) != "}")
        {
          if (stringBuilder2.Length == 0)
          {
            stringBuilder1.Append(text.Substring(startIndex, 1));
            stringBuilder2.Length = 0;
            str = "";
          }
          else if ("0123456789".IndexOf(text.Substring(startIndex, 1), StringComparison.Ordinal) != -1)
            stringBuilder2.Append(text.Substring(startIndex, 1));
        }
        else if (text.Substring(startIndex, 1) == "{" && stringBuilder2.Length == 0)
        {
          stringBuilder2.Length = 0;
          stringBuilder2.Append("0");
        }
        else if (text.Substring(startIndex, 1) == "}" && stringBuilder2.Length != 0)
        {
          int num = int.Parse(stringBuilder2.ToString(), (IFormatProvider) CultureInfo.InvariantCulture) - 1;
          if (num > 0)
          {
            for (int index = 0; index < num; ++index)
              stringBuilder1.Append(str);
          }
          stringBuilder2.Length = 0;
          stringBuilder2.Append("0");
          str = "";
        }
      }
      return stringBuilder1.ToString();
    }
  }
}
