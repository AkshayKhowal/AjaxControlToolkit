﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.CollapsiblePanelExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [TargetControlType(typeof (Panel))]
  [ToolboxBitmap(typeof (CollapsiblePanelExtender), "CollapsiblePanel.CollapsiblePanel.ico")]
  [Designer("AjaxControlToolkit.CollapsiblePanelDesigner, AjaxControlToolkit")]
  [ClientScriptResource("AjaxControlToolkit.CollapsiblePanelBehavior", "AjaxControlToolkit.CollapsiblePanel.CollapsiblePanelBehavior.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (AnimationScripts))]
  [DefaultProperty("CollapseControlID")]
  public class CollapsiblePanelExtender : ExtenderControlBase
  {
    public CollapsiblePanelExtender()
    {
      this.ClientStateValuesLoaded += new EventHandler(this.CollapsiblePanelExtender_ClientStateValuesLoaded);
      this.EnableClientState = true;
    }

    [ExtenderControlProperty]
    [IDReferenceProperty(typeof (WebControl))]
    [DefaultValue("")]
    public string CollapseControlID
    {
      get => this.GetPropertyValue<string>(nameof (CollapseControlID), "");
      set => this.SetPropertyValue<string>(nameof (CollapseControlID), value);
    }

    [IDReferenceProperty(typeof (WebControl))]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string ExpandControlID
    {
      get => this.GetPropertyValue<string>(nameof (ExpandControlID), "");
      set => this.SetPropertyValue<string>(nameof (ExpandControlID), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool AutoCollapse
    {
      get => this.GetPropertyValue<bool>(nameof (AutoCollapse), false);
      set => this.SetPropertyValue<bool>(nameof (AutoCollapse), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool AutoExpand
    {
      get => this.GetPropertyValue<bool>(nameof (AutoExpand), false);
      set => this.SetPropertyValue<bool>(nameof (AutoExpand), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(-1)]
    public int CollapsedSize
    {
      get => this.GetPropertyValue<int>("CollapseHeight", -1);
      set => this.SetPropertyValue<int>("CollapseHeight", value);
    }

    [DefaultValue(-1)]
    [ExtenderControlProperty]
    public int ExpandedSize
    {
      get => this.GetPropertyValue<int>(nameof (ExpandedSize), -1);
      set => this.SetPropertyValue<int>(nameof (ExpandedSize), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool ScrollContents
    {
      get => this.GetPropertyValue<bool>(nameof (ScrollContents), false);
      set => this.SetPropertyValue<bool>(nameof (ScrollContents), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool SuppressPostBack
    {
      get => this.GetPropertyValue<bool>(nameof (SuppressPostBack), false);
      set => this.SetPropertyValue<bool>(nameof (SuppressPostBack), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool Collapsed
    {
      get => this.GetPropertyValue<bool>(nameof (Collapsed), false);
      set => this.SetPropertyValue<bool>(nameof (Collapsed), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string CollapsedText
    {
      get => this.GetPropertyValue<string>(nameof (CollapsedText), "");
      set => this.SetPropertyValue<string>(nameof (CollapsedText), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string ExpandedText
    {
      get => this.GetPropertyValue<string>(nameof (ExpandedText), "");
      set => this.SetPropertyValue<string>(nameof (ExpandedText), value);
    }

    [ExtenderControlProperty]
    [IDReferenceProperty(typeof (Label))]
    [DefaultValue("")]
    public string TextLabelID
    {
      get => this.GetPropertyValue<string>(nameof (TextLabelID), "");
      set => this.SetPropertyValue<string>(nameof (TextLabelID), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    [UrlProperty]
    public string ExpandedImage
    {
      get => this.GetPropertyValue<string>(nameof (ExpandedImage), "");
      set => this.SetPropertyValue<string>(nameof (ExpandedImage), value);
    }

    [UrlProperty]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string CollapsedImage
    {
      get => this.GetPropertyValue<string>(nameof (CollapsedImage), "");
      set => this.SetPropertyValue<string>(nameof (CollapsedImage), value);
    }

    [IDReferenceProperty(typeof (System.Web.UI.WebControls.Image))]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string ImageControlID
    {
      get => this.GetPropertyValue<string>(nameof (ImageControlID), "");
      set => this.SetPropertyValue<string>(nameof (ImageControlID), value);
    }

    [DefaultValue(CollapsiblePanelExpandDirection.Vertical)]
    [ExtenderControlProperty]
    public CollapsiblePanelExpandDirection ExpandDirection
    {
      get => this.GetPropertyValue<CollapsiblePanelExpandDirection>(nameof (ExpandDirection), CollapsiblePanelExpandDirection.Vertical);
      set => this.SetPropertyValue<CollapsiblePanelExpandDirection>(nameof (ExpandDirection), value);
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public override void EnsureValid()
    {
      base.EnsureValid();
      if ((this.ExpandedText != null || this.CollapsedText != null) && this.TextLabelID == null)
        throw new ArgumentException("If CollapsedText or ExpandedText is set, TextLabelID must also be set.");
    }

    private void CollapsiblePanelExtender_ClientStateValuesLoaded(object sender, EventArgs e)
    {
      if (!(this.FindControl(this.TargetControlID) is WebControl control) || string.IsNullOrEmpty(this.ClientState))
        return;
      if (bool.Parse(this.ClientState))
        control.Style["display"] = "none";
      else
        control.Style["display"] = "";
    }
  }
}
