﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DropShadowExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Drawing;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (CommonToolkitScripts), 1)]
  [ClientScriptResource("AjaxControlToolkit.DropShadowBehavior", "AjaxControlToolkit.DropShadow.DropShadowBehavior.js")]
  [Designer("AjaxControlToolkit.DropShadowDesigner, AjaxControlToolkit")]
  [RequiredScript(typeof (RoundedCornersExtender), 2)]
  [RequiredScript(typeof (TimerScript), 3)]
  [TargetControlType(typeof (Control))]
  [ToolboxBitmap(typeof (DropShadowExtender), "DropShadow.DropShadow.ico")]
  public class DropShadowExtender : ExtenderControlBase
  {
    [ExtenderControlProperty]
    [DefaultValue(1f)]
    public float Opacity
    {
      get => this.GetPropertyValue<float>(nameof (Opacity), 1f);
      set => this.SetPropertyValue<float>(nameof (Opacity), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(5)]
    public int Width
    {
      get => this.GetPropertyValue<int>(nameof (Width), 5);
      set => this.SetPropertyValue<int>(nameof (Width), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool TrackPosition
    {
      get => this.GetPropertyValue<bool>(nameof (TrackPosition), false);
      set => this.SetPropertyValue<bool>(nameof (TrackPosition), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool Rounded
    {
      get => this.GetPropertyValue<bool>(nameof (Rounded), false);
      set => this.SetPropertyValue<bool>(nameof (Rounded), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(5)]
    public int Radius
    {
      get => this.GetPropertyValue<int>(nameof (Radius), 5);
      set => this.SetPropertyValue<int>(nameof (Radius), value);
    }
  }
}
