﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DynamicPopulateExtenderControlBase
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (DynamicPopulateExtender))]
  public abstract class DynamicPopulateExtenderControlBase : AnimationExtenderControlBase
  {
    [Category("Behavior")]
    [IDReferenceProperty(typeof (WebControl))]
    [DefaultValue("")]
    [ExtenderControlProperty]
    [ClientPropertyName("dynamicControlID")]
    public string DynamicControlID
    {
      get => this.GetPropertyValue<string>(nameof (DynamicControlID), "");
      set => this.SetPropertyValue<string>(nameof (DynamicControlID), value);
    }

    [DefaultValue("")]
    [Category("Behavior")]
    [ClientPropertyName("dynamicContextKey")]
    [ExtenderControlProperty]
    public string DynamicContextKey
    {
      get => this.GetPropertyValue<string>(nameof (DynamicContextKey), "");
      set => this.SetPropertyValue<string>(nameof (DynamicContextKey), value);
    }

    [Category("Behavior")]
    [ClientPropertyName("dynamicServicePath")]
    [ExtenderControlProperty]
    [UrlProperty]
    [TypeConverter(typeof (ServicePathConverter))]
    public string DynamicServicePath
    {
      get => this.GetPropertyValue<string>(nameof (DynamicServicePath), "");
      set => this.SetPropertyValue<string>(nameof (DynamicServicePath), value);
    }

    private bool ShouldSerializeServicePath() => !string.IsNullOrEmpty(this.DynamicServiceMethod);

    [DefaultValue("")]
    [Category("Behavior")]
    [ExtenderControlProperty]
    [ClientPropertyName("dynamicServiceMethod")]
    public string DynamicServiceMethod
    {
      get => this.GetPropertyValue<string>(nameof (DynamicServiceMethod), "");
      set => this.SetPropertyValue<string>(nameof (DynamicServiceMethod), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("cacheDynamicResults")]
    [Category("Behavior")]
    public bool CacheDynamicResults
    {
      get => this.GetPropertyValue<bool>(nameof (CacheDynamicResults), false);
      set => this.SetPropertyValue<bool>(nameof (CacheDynamicResults), value);
    }

    public override void EnsureValid()
    {
      base.EnsureValid();
      if (string.IsNullOrEmpty(this.DynamicControlID) && string.IsNullOrEmpty(this.DynamicContextKey) && string.IsNullOrEmpty(this.DynamicServicePath) && string.IsNullOrEmpty(this.DynamicServiceMethod))
        return;
      if (string.IsNullOrEmpty(this.DynamicControlID))
        throw new ArgumentException("DynamicControlID must be set");
      if (string.IsNullOrEmpty(this.DynamicServiceMethod))
        throw new ArgumentException("DynamicServiceMethod must be set");
    }
  }
}
