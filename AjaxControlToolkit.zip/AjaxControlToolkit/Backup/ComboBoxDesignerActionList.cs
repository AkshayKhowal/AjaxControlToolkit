﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ComboBoxDesignerActionList
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.ComponentModel.Design;

namespace AjaxControlToolkit
{
  internal class ComboBoxDesignerActionList : DesignerActionList
  {
    private ComboBox _comboBox;

    public ComboBoxDesignerActionList(IComponent component)
      : base(component)
    {
      this._comboBox = (ComboBox) component;
    }

    public bool AppendDataBoundItems
    {
      get => this._comboBox.AppendDataBoundItems;
      set => this.SetComponentProperty(nameof (AppendDataBoundItems), (object) value);
    }

    public bool CaseSensitive
    {
      get => this._comboBox.CaseSensitive;
      set => this.SetComponentProperty(nameof (CaseSensitive), (object) value);
    }

    public ComboBoxStyle DropDownStyle
    {
      get => this._comboBox.DropDownStyle;
      set => this.SetComponentProperty(nameof (DropDownStyle), (object) value);
    }

    public ComboBoxAutoCompleteMode AutoCompleteMode
    {
      get => this._comboBox.AutoCompleteMode;
      set => this.SetComponentProperty(nameof (AutoCompleteMode), (object) value);
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection sortedActionItems = new DesignerActionItemCollection();
      DesignerActionPropertyItem propertyItem1 = this.GetPropertyItem("AppendDataBoundItems", "Append DataBound Items");
      if (propertyItem1 != null)
        sortedActionItems.Add((DesignerActionItem) propertyItem1);
      DesignerActionPropertyItem propertyItem2 = this.GetPropertyItem("CaseSensitive", "Case Sensitive");
      if (propertyItem2 != null)
        sortedActionItems.Add((DesignerActionItem) propertyItem2);
      DesignerActionPropertyItem propertyItem3 = this.GetPropertyItem("DropDownStyle", "DropDown Style");
      if (propertyItem3 != null)
        sortedActionItems.Add((DesignerActionItem) propertyItem3);
      DesignerActionPropertyItem propertyItem4 = this.GetPropertyItem("AutoCompleteMode", "AutoComplete Mode");
      if (propertyItem4 != null)
        sortedActionItems.Add((DesignerActionItem) propertyItem4);
      return sortedActionItems;
    }

    protected virtual DesignerActionPropertyItem GetPropertyItem(
      string propertyName,
      string displayName)
    {
      PropertyDescriptor property = TypeDescriptor.GetProperties((object) this._comboBox)[propertyName];
      return property != null && property.IsBrowsable ? new DesignerActionPropertyItem(propertyName, displayName, property.Category, property.Description) : (DesignerActionPropertyItem) null;
    }

    protected virtual void SetComponentProperty(string propertyName, object value) => (TypeDescriptor.GetProperties((object) this._comboBox)[propertyName] ?? throw new ArgumentException("Property not found", propertyName)).SetValue((object) this._comboBox, value);
  }
}
