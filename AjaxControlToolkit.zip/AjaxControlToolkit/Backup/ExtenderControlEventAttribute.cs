﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ExtenderControlEventAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [AttributeUsage(AttributeTargets.Property, Inherited = true)]
  public sealed class ExtenderControlEventAttribute : Attribute
  {
    private static ExtenderControlEventAttribute Yes = new ExtenderControlEventAttribute(true);
    private static ExtenderControlEventAttribute No = new ExtenderControlEventAttribute(false);
    private static ExtenderControlEventAttribute Default = ExtenderControlEventAttribute.No;
    private bool _isScriptEvent;

    public ExtenderControlEventAttribute()
      : this(true)
    {
    }

    public ExtenderControlEventAttribute(bool isScriptEvent) => this._isScriptEvent = isScriptEvent;

    public bool IsScriptEvent => this._isScriptEvent;

    public override bool Equals(object obj)
    {
      if (object.ReferenceEquals(obj, (object) this))
        return true;
      return obj is ExtenderControlEventAttribute controlEventAttribute && controlEventAttribute._isScriptEvent == this._isScriptEvent;
    }

    public override int GetHashCode() => this._isScriptEvent.GetHashCode();

    public override bool IsDefaultAttribute() => this.Equals((object) ExtenderControlEventAttribute.Default);
  }
}
