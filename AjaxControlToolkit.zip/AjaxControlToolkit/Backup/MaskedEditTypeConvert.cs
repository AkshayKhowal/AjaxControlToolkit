﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MaskedEditTypeConvert
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit
{
  public class MaskedEditTypeConvert : StringConverter
  {
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context) => true;

    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) => false;

    public override TypeConverter.StandardValuesCollection GetStandardValues(
      ITypeDescriptorContext context)
    {
      if (context == null || context.Container == null)
        return (TypeConverter.StandardValuesCollection) null;
      object[] controls = MaskedEditTypeConvert.GetControls(context.Container);
      return controls != null ? new TypeConverter.StandardValuesCollection((ICollection) controls) : (TypeConverter.StandardValuesCollection) null;
    }

    private static object[] GetControls(IContainer container)
    {
      ArrayList arrayList = new ArrayList();
      foreach (IComponent component in (ReadOnlyCollectionBase) container.Components)
      {
        if (component is Control serverControl && !(serverControl is Page) && serverControl.ID != null && serverControl.ID.Length != 0 && MaskedEditTypeConvert.IncludeControl(serverControl))
          arrayList.Add((object) serverControl.ID);
      }
      arrayList.Sort((IComparer) Comparer.Default);
      return arrayList.ToArray();
    }

    private static bool IncludeControl(Control serverControl)
    {
      bool flag = false;
      if (serverControl.GetType().ToString().IndexOf("ajaxcontroltoolkit.maskededitextender", StringComparison.OrdinalIgnoreCase) != -1)
        flag = true;
      return flag;
    }
  }
}
