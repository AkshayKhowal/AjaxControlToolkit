﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ModePanel
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Editor", "AjaxControlToolkit.HTMLEditor.ModePanel.js")]
  public abstract class ModePanel : ScriptControlBase
  {
    private EditPanel _editPanel;

    protected ModePanel(HtmlTextWriterTag tag)
      : base(false, tag)
    {
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.Style.Add(HtmlTextWriterStyle.Height, Unit.Percentage(100.0).ToString());
      this.Style.Add(HtmlTextWriterStyle.Width, Unit.Percentage(100.0).ToString());
      this.Style.Add(HtmlTextWriterStyle.Display, "none");
    }

    internal void setEditPanel(EditPanel editPanel) => this._editPanel = editPanel;

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      if (this._editPanel == null)
        return;
      descriptor.AddComponentProperty("editPanel", this._editPanel.ClientID);
    }
  }
}
