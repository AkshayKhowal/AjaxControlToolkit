Type.registerNamespace("AjaxControlToolkit.HTMLEditor.ToolbarButton");

AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector = function(element) {
    AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector.prototype = {
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector.registerClass("AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector", AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignModePopupImageButton);

