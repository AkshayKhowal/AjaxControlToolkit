Type.registerNamespace("AjaxControlToolkit.HTMLEditor.ToolbarButton");

AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignMode = function(element) {
    AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignMode.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignMode.prototype = {
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignMode.registerClass("AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignMode", AjaxControlToolkit.HTMLEditor.ToolbarButton.ModeButton);

