Type.registerNamespace("AjaxControlToolkit.HTMLEditor.ToolbarButton");

AjaxControlToolkit.HTMLEditor.ToolbarButton.HtmlMode = function(element) {
    AjaxControlToolkit.HTMLEditor.ToolbarButton.HtmlMode.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.HtmlMode.prototype = {
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.HtmlMode.registerClass("AjaxControlToolkit.HTMLEditor.ToolbarButton.HtmlMode", AjaxControlToolkit.HTMLEditor.ToolbarButton.ModeButton);

