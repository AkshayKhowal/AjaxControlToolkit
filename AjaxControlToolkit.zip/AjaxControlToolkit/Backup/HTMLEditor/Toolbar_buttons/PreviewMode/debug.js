Type.registerNamespace("AjaxControlToolkit.HTMLEditor.ToolbarButton");

AjaxControlToolkit.HTMLEditor.ToolbarButton.PreviewMode = function(element) {
    AjaxControlToolkit.HTMLEditor.ToolbarButton.PreviewMode.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.PreviewMode.prototype = {
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.PreviewMode.registerClass("AjaxControlToolkit.HTMLEditor.ToolbarButton.PreviewMode", AjaxControlToolkit.HTMLEditor.ToolbarButton.ModeButton);

