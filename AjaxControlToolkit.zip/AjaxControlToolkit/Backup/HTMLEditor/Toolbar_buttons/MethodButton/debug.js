Type.registerNamespace("AjaxControlToolkit.HTMLEditor.ToolbarButton");

AjaxControlToolkit.HTMLEditor.ToolbarButton.MethodButton = function(element) {
    AjaxControlToolkit.HTMLEditor.ToolbarButton.MethodButton.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.MethodButton.prototype = {
}

AjaxControlToolkit.HTMLEditor.ToolbarButton.MethodButton.registerClass("AjaxControlToolkit.HTMLEditor.ToolbarButton.MethodButton", AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignModeImageButton);

