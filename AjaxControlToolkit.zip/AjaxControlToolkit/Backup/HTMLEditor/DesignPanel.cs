﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.DesignPanel
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor
{
  [RequiredScript(typeof (AjaxControlToolkit.HTMLEditor.HTMLEditor))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [RequiredScript(typeof (ExecCommandEmulation))]
  [RequiredScript(typeof (DesignPanelEventHandler))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.DesignPanel", "AjaxControlToolkit.HTMLEditor.DesignPanel.js")]
  [PersistChildren(false)]
  internal class DesignPanel : ModePanel
  {
    public DesignPanel()
      : base(HtmlTextWriterTag.Iframe)
    {
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.Attributes.Add("name", this.ClientID);
      this.Attributes.Add("marginheight", "0");
      this.Attributes.Add("marginwidth", "0");
      this.Attributes.Add("frameborder", "0");
      if (EditPanel.IE(this.Page))
        this.Attributes.Add("src", "javascript:false;");
      this.Style.Add(HtmlTextWriterStyle.BorderWidth, Unit.Pixel(0).ToString());
    }
  }
}
