﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.EditPanel
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor
{
  [RequiredScript(typeof (AjaxControlToolkit.HTMLEditor.Events))]
  [RequiredScript(typeof (Enums))]
  [PersistChildren(false)]
  [ValidationProperty("Content")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [RequiredScript(typeof (AjaxControlToolkit.HTMLEditor.HTMLEditor))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.EditPanel", "AjaxControlToolkit.HTMLEditor.EditPanel.js")]
  public abstract class EditPanel : ScriptControlBase, IPostBackEventHandler
  {
    public static readonly object EventContentChanged = new object();
    private bool _contentChanged;
    private readonly ModePanel[] ModePanels = new ModePanel[3]
    {
      (ModePanel) new DesignPanel(),
      (ModePanel) new HtmlPanel(),
      (ModePanel) new PreviewPanel()
    };
    private Collection<Toolbar> _toolbars;
    private ControlDesigner _designer;

    protected EditPanel()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    [Category("Behavior")]
    public event ContentChangedEventHandler ContentChanged
    {
      add => this.Events.AddHandler(EditPanel.EventContentChanged, (Delegate) value);
      remove => this.Events.RemoveHandler(EditPanel.EventContentChanged, (Delegate) value);
    }

    protected virtual void OnRaiseContentChanged(EventArgs e)
    {
      ContentChangedEventHandler changedEventHandler = (ContentChangedEventHandler) this.Events[EditPanel.EventContentChanged];
      if (changedEventHandler != null)
        changedEventHandler((object) this, e);
      else
        this.RaiseBubbleEvent((object) this, (EventArgs) new CommandEventArgs("contentchanged", (object) ""));
    }

    protected override void RaisePostDataChangedEvent()
    {
      if (!this._contentChanged)
        return;
      this.OnRaiseContentChanged(EventArgs.Empty);
      this._contentChanged = false;
    }

    protected override bool LoadPostData(string postDataKey, NameValueCollection postCollection)
    {
      base.LoadPostData(postDataKey, postCollection);
      bool flag = false;
      if (!string.IsNullOrEmpty(postCollection[this.ContentForceId]))
        flag = true;
      string post1 = postCollection[this.ActiveModeId];
      if (!string.IsNullOrEmpty(post1))
        this.ActiveMode = (ActiveModeType) long.Parse(post1, (IFormatProvider) CultureInfo.InvariantCulture);
      this._contentChanged = false;
      string post2 = postCollection[this.ContentId];
      if (post2 != null && flag)
      {
        string str = post2.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"").Replace("&amp;", "&");
        if (str == "<br />")
          str = "";
        this._contentChanged = this.Content.Replace("\n", "").Replace("\r", "") != str.Replace("\n", "").Replace("\r", "");
        this.Content = str;
      }
      if (!string.IsNullOrEmpty(postCollection[this.ContentChangedId]))
        this._contentChanged = true;
      return this._contentChanged;
    }

    public void RaisePostBackEvent(string eventArgument)
    {
    }

    protected override bool OnBubbleEvent(object source, EventArgs args) => true;

    private bool isDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    [DefaultValue(false)]
    [ClientPropertyName("suppressTabInDesignMode")]
    [Category("Behavior")]
    [ExtenderControlProperty]
    public bool SuppressTabInDesignMode
    {
      get => (bool) (this.ViewState[nameof (SuppressTabInDesignMode)] ?? (object) false);
      set => this.ViewState[nameof (SuppressTabInDesignMode)] = (object) value;
    }

    [DefaultValue(false)]
    [Category("Behavior")]
    public bool IgnoreTab
    {
      get => (bool) (this.ViewState[nameof (IgnoreTab)] ?? (object) false);
      set => this.ViewState[nameof (IgnoreTab)] = (object) value;
    }

    [ClientPropertyName("noUnicode")]
    [DefaultValue(false)]
    [Category("Behavior")]
    [ExtenderControlProperty]
    public bool NoUnicode
    {
      get => (bool) (this.ViewState[nameof (NoUnicode)] ?? (object) false);
      set => this.ViewState[nameof (NoUnicode)] = (object) value;
    }

    [Category("Behavior")]
    [DefaultValue(false)]
    [ClientPropertyName("noScript")]
    [ExtenderControlProperty]
    public bool NoScript
    {
      get => (bool) (this.ViewState[nameof (NoScript)] ?? (object) false);
      set => this.ViewState[nameof (NoScript)] = (object) value;
    }

    [ClientPropertyName("initialCleanUp")]
    [ExtenderControlProperty]
    [Category("Behavior")]
    [DefaultValue(false)]
    public bool InitialCleanUp
    {
      get => (bool) (this.ViewState[nameof (InitialCleanUp)] ?? (object) false);
      set => this.ViewState[nameof (InitialCleanUp)] = (object) value;
    }

    [Category("Appearance")]
    [DefaultValue("ajax__htmleditor_htmlpanel_default")]
    public string HtmlPanelCssClass
    {
      get => (string) (this.ViewState[nameof (HtmlPanelCssClass)] ?? (object) "ajax__htmleditor_htmlpanel_default");
      set => this.ViewState[nameof (HtmlPanelCssClass)] = (object) value;
    }

    [Category("Appearance")]
    [DefaultValue("")]
    public string DocumentCssPath
    {
      get => (string) (this.ViewState[nameof (DocumentCssPath)] ?? (object) string.Empty);
      set => this.ViewState[nameof (DocumentCssPath)] = (object) value;
    }

    [Browsable(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("documentCssPath")]
    public string ClientDocumentCssPath => this.getClientCSSPath(this.DocumentCssPath, "Document");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeClientDocumentCssPath() => this.IsRenderingScript;

    [Category("Appearance")]
    [DefaultValue("")]
    public string DesignPanelCssPath
    {
      get => (string) (this.ViewState[nameof (DesignPanelCssPath)] ?? (object) string.Empty);
      set => this.ViewState[nameof (DesignPanelCssPath)] = (object) value;
    }

    [ExtenderControlProperty]
    [Browsable(false)]
    [ClientPropertyName("designPanelCssPath")]
    public string ClientDesignPanelCssPath => this.getClientCSSPath(this.DesignPanelCssPath, "DesignPanel");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeClientDesignPanelCssPath() => this.IsRenderingScript;

    [ClientPropertyName("imagePath_1x1")]
    [Browsable(false)]
    [ExtenderControlProperty]
    public string ImagePath_1X1 => this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor.Images.ed_1x1.gif");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeImagePath_1X1() => this.IsRenderingScript;

    [Browsable(false)]
    [ClientPropertyName("imagePath_flash")]
    [ExtenderControlProperty]
    public string ImagePath_Flash => this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor.Images.ed_flash.gif");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeImagePath_Flash() => this.IsRenderingScript;

    [ClientPropertyName("imagePath_media")]
    [Browsable(false)]
    [ExtenderControlProperty]
    public string ImagePath_Media => this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor.Images.ed_media.gif");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeImagePath_Media() => this.IsRenderingScript;

    [ClientPropertyName("imagePath_anchor")]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string ImagePath_Anchor => this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor.Images.ed_anchor.gif");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeImagePath_Anchor() => this.IsRenderingScript;

    [ExtenderControlProperty]
    [Browsable(false)]
    [ClientPropertyName("imagePath_placeHolder")]
    public string ImagePath_Placeholder => this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor.Images.ed_placeHolder.gif");

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeImagePath_Placeholder() => this.IsRenderingScript;

    [ClientPropertyName("autofocus")]
    [DefaultValue(true)]
    [Category("Behavior")]
    [ExtenderControlProperty]
    public bool AutoFocus
    {
      get => (bool) (this.ViewState[nameof (AutoFocus)] ?? (object) true);
      set => this.ViewState[nameof (AutoFocus)] = (object) value;
    }

    [Category("Appearance")]
    [DefaultValue("")]
    public string Content
    {
      get => (string) (this.ViewState[nameof (Content)] ?? (object) string.Empty);
      set => this.ViewState[nameof (Content)] = (object) value;
    }

    [Category("Behavior")]
    [DefaultValue(ActiveModeType.Design)]
    public ActiveModeType ActiveMode
    {
      get => (ActiveModeType) (this.ViewState[nameof (ActiveMode)] ?? (object) ActiveModeType.Design);
      set
      {
        this.ViewState[nameof (ActiveMode)] = (object) value;
        if (this._designer == null || !this.isDesign)
          return;
        this.RefreshDesigner();
      }
    }

    [ExtenderControlEvent]
    [ClientPropertyName("activeModeChanged")]
    [DefaultValue("")]
    [Category("Behavior")]
    public string OnClientActiveModeChanged
    {
      get => (string) (this.ViewState[nameof (OnClientActiveModeChanged)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientActiveModeChanged)] = (object) value;
    }

    [DefaultValue("")]
    [ExtenderControlEvent]
    [ClientPropertyName("beforeActiveModeChanged")]
    [Category("Behavior")]
    public string OnClientBeforeActiveModeChanged
    {
      get => (string) (this.ViewState[nameof (OnClientBeforeActiveModeChanged)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientBeforeActiveModeChanged)] = (object) value;
    }

    [Category("Appearance")]
    [DefaultValue(typeof (Unit), "100%")]
    public override Unit Height => Unit.Percentage(100.0);

    [Category("Appearance")]
    [DefaultValue(typeof (Unit), "100%")]
    public override Unit Width => Unit.Percentage(100.0);

    [Browsable(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("modePanelIds")]
    public string ClientModePanelIds
    {
      get
      {
        string clientModePanelIds = "";
        for (int index = 0; index < this.ModePanels.Length; ++index)
        {
          if (index > 0)
            clientModePanelIds += ";";
          clientModePanelIds += this.ModePanels[index].ClientID;
        }
        return clientModePanelIds;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeClientModePanelIds() => this.IsRenderingScript;

    [PersistenceMode(PersistenceMode.InnerProperty)]
    internal Collection<Toolbar> Toolbars
    {
      get
      {
        if (this._toolbars == null)
          this._toolbars = new Collection<Toolbar>();
        return this._toolbars;
      }
      set => this._toolbars = value;
    }

    [ClientPropertyName("toolbarIds")]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string ToolbarIds
    {
      get
      {
        string toolbarIds = "";
        for (int index = 0; index < this.Toolbars.Count; ++index)
        {
          if (index > 0)
            toolbarIds += ";";
          toolbarIds += this.Toolbars[index].ClientID;
        }
        return toolbarIds;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeToolbarIds() => this.IsRenderingScript;

    internal new EventHandlerList Events => base.Events;

    protected string ContentChangedId => "_contentChanged_" + this.ClientID;

    protected string ContentId => "_content_" + this.ClientID;

    protected string ContentForceId => "_contentForce_" + this.ClientID;

    protected string ActiveModeId => "_activeMode_" + this.ClientID;

    protected void RefreshDesigner()
    {
      if (this._designer == null || !this.isDesign)
        return;
      this._designer.UpdateDesignTimeHtml();
    }

    public void SetDesigner(ControlDesigner designer) => this._designer = designer;

    protected string LocalResolveUrl(string path) => new Regex("(\\(S\\([A-Za-z0-9_]+\\)\\)/)", RegexOptions.Compiled).Replace(this.ResolveUrl(path), "");

    internal string getClientCSSPath(string pathN, string name)
    {
      bool flag = false;
      string path = pathN.Length > 0 ? this.LocalResolveUrl(pathN) : "";
      if (path.Length > 0)
      {
        try
        {
          if (File.Exists(HttpContext.Current.Server.MapPath(path)))
            flag = true;
        }
        catch
        {
        }
      }
      return !flag ? this.Page.ClientScript.GetWebResourceUrl(typeof (EditPanel), "AjaxControlToolkit.HTMLEditor." + name + ".css") : path;
    }

    internal static bool IE(Page page)
    {
      try
      {
        return page.Request.Browser.Browser.IndexOf(nameof (IE), StringComparison.OrdinalIgnoreCase) > -1;
      }
      catch
      {
        return false;
      }
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      ScriptManager.RegisterHiddenField((Control) this, this.ContentChangedId, string.Empty);
      ScriptManager.RegisterHiddenField((Control) this, this.ContentForceId, "1");
      ScriptManager.RegisterHiddenField((Control) this, this.ContentId, this.Content.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;"));
      ScriptManager.RegisterHiddenField((Control) this, this.ActiveModeId, ((int) this.ActiveMode).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      this.Page.RegisterRequiresPostBack((Control) this);
      for (int index = 0; index < this.Controls.Count; ++index)
      {
        if (this.IgnoreTab)
          (this.Controls[index] as ModePanel).Attributes.Add("tabindex", "-1");
        if (this.Controls[index].GetType() == typeof (HtmlPanel))
          (this.Controls[index] as HtmlPanel).CssClass = this.HtmlPanelCssClass;
      }
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddElementProperty("contentChangedElement", this.ContentChangedId);
      descriptor.AddElementProperty("contentForceElement", this.ContentForceId);
      descriptor.AddElementProperty("contentElement", this.ContentId);
      descriptor.AddElementProperty("activeModeElement", this.ActiveModeId);
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.Style.Add(HtmlTextWriterStyle.Height, Unit.Percentage(100.0).ToString());
      this.Style.Add(HtmlTextWriterStyle.Width, Unit.Percentage(100.0).ToString());
      if (!this.isDesign)
      {
        for (int index = 0; index < this.ModePanels.Length; ++index)
        {
          this.ModePanels[index].setEditPanel(this);
          this.Controls.Add((Control) this.ModePanels[index]);
        }
      }
      else
        this.Controls.Add((Control) this.ModePanels[0]);
    }
  }
}
