﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Toolbar
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Toolbar", "AjaxControlToolkit.HTMLEditor.Toolbar.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [PersistChildren(false)]
  public abstract class Toolbar : ScriptControlBase
  {
    private Collection<CommonButton> _buttons;
    private bool _wasPreRender;

    protected Toolbar()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    protected bool IsDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    [ClientPropertyName("alwaysVisible")]
    [DefaultValue(false)]
    [Category("Behavior")]
    [ExtenderControlProperty]
    public bool AlwaysVisible
    {
      get => (bool) (this.ViewState[nameof (AlwaysVisible)] ?? (object) false);
      set => this.ViewState[nameof (AlwaysVisible)] = (object) value;
    }

    [PersistenceMode(PersistenceMode.InnerProperty)]
    public Collection<CommonButton> Buttons
    {
      get
      {
        if (this._buttons == null)
          this._buttons = new Collection<CommonButton>();
        return this._buttons;
      }
      internal set => this._buttons = value;
    }

    [ClientPropertyName("buttonIds")]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string ButtonIds
    {
      get
      {
        string buttonIds = "";
        for (int index = 0; index < this.Buttons.Count; ++index)
        {
          if (index > 0)
            buttonIds += ";";
          buttonIds += this.Buttons[index].ClientID;
        }
        return buttonIds;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeButtonIds() => this.IsRenderingScript;

    [Description("Folder used for toolbar's buttons' images")]
    [Category("Appearance")]
    [DefaultValue("")]
    public string ButtonImagesFolder
    {
      get => (string) (this.ViewState[nameof (ButtonImagesFolder)] ?? (object) "");
      set
      {
        string str1 = this.LocalResolveUrl(value);
        if (str1.Length <= 0)
          return;
        string str2 = str1.Substring(str1.Length - 1, 1);
        if (str2 != "\\" && str2 != "/")
          str1 += "/";
        this.ViewState[nameof (ButtonImagesFolder)] = (object) str1;
      }
    }

    protected string LocalResolveUrl(string path) => new Regex("(\\(S\\([A-Za-z0-9_]+\\)\\)/)", RegexOptions.Compiled).Replace(this.ResolveUrl(path), "");

    protected override void CreateChildControls()
    {
      for (int index1 = 0; index1 < this.Buttons.Count; ++index1)
      {
        this.Controls.Add((Control) this.Buttons[index1]);
        if (!this.AlwaysVisible && !this.IsDesign)
        {
          if (!this.Buttons[index1].PreservePlace)
            this.Buttons[index1].Style[HtmlTextWriterStyle.Display] = "none";
          else
            this.Buttons[index1].Style[HtmlTextWriterStyle.Visibility] = "hidden";
        }
        for (int index2 = 0; index2 < this.Buttons[index1].ExportedControls.Count; ++index2)
          this.Controls.Add(this.Buttons[index1].ExportedControls[index2]);
      }
    }

    protected override void OnPreRender(EventArgs e)
    {
      try
      {
        base.OnPreRender(e);
      }
      catch
      {
      }
      this._wasPreRender = true;
      for (int index = 0; index < this.Controls.Count; ++index)
      {
        if (this.Controls[index] is CommonButton control)
        {
          if (!this.IsDesign)
          {
            if (!control.PreservePlace)
              control.Style[HtmlTextWriterStyle.Display] = "none";
            else
              control.Style[HtmlTextWriterStyle.Visibility] = "hidden";
          }
          else
          {
            control.Style.Remove(HtmlTextWriterStyle.Display);
            control.Style.Remove(HtmlTextWriterStyle.Visibility);
          }
        }
      }
    }

    protected override void Render(HtmlTextWriter writer)
    {
      if (!this._wasPreRender)
        this.OnPreRender(new EventArgs());
      base.Render(writer);
    }

    internal void CreateChilds(DesignerWithMapPath designer)
    {
      this.Controls.Clear();
      this.CreateChildControls();
      for (int index = 0; index < this.Controls.Count; ++index)
      {
        if (this.Controls[index] is CommonButton control)
          control.CreateChilds(designer);
      }
    }
  }
}
