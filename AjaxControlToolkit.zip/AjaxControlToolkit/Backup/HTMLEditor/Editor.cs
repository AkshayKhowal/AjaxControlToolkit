﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Editor
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor
{
  [RequiredScript(typeof (Enums))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Editor", "AjaxControlToolkit.HTMLEditor.Editor.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [PersistChildren(false)]
  [ValidationProperty("Content")]
  [ClientCssResource("AjaxControlToolkit.HTMLEditor.Editor.css")]
  [ToolboxBitmap(typeof (Editor), "HTMLEditor.Editor.ico")]
  [Designer("AjaxControlToolkit.EditorDesigner, AjaxControlToolkit")]
  public class Editor : ScriptControlBase
  {
    private EditPanel _editPanel;
    private Toolbar _changingToolbar;
    private TableCell _editPanelCell;
    private TableRow _topToolbarRow;
    private TableRow _bottomToolbarRow;
    internal Toolbar _bottomToolbar;
    internal Toolbar _topToolbar;
    private bool _wasPreRender;

    public Editor()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    [Category("Behavior")]
    public event ContentChangedEventHandler ContentChanged
    {
      add => this.EditPanel.Events.AddHandler(EditPanel.EventContentChanged, (Delegate) value);
      remove => this.EditPanel.Events.RemoveHandler(EditPanel.EventContentChanged, (Delegate) value);
    }

    protected bool IsDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    [DefaultValue(false)]
    [Category("Behavior")]
    public virtual bool SuppressTabInDesignMode
    {
      get => this.EditPanel.SuppressTabInDesignMode;
      set => this.EditPanel.SuppressTabInDesignMode = value;
    }

    [DefaultValue(false)]
    public virtual bool TopToolbarPreservePlace
    {
      get => (bool) (this.ViewState[nameof (TopToolbarPreservePlace)] ?? (object) false);
      set => this.ViewState[nameof (TopToolbarPreservePlace)] = (object) value;
    }

    [Category("Behavior")]
    [DefaultValue(false)]
    public virtual bool IgnoreTab
    {
      get => (bool) (this.ViewState[nameof (IgnoreTab)] ?? (object) false);
      set => this.ViewState[nameof (IgnoreTab)] = (object) value;
    }

    [Description("Folder used for toolbar's buttons' images")]
    [DefaultValue("")]
    [Category("Appearance")]
    public virtual string ButtonImagesFolder
    {
      get => (string) (this.ViewState[nameof (ButtonImagesFolder)] ?? (object) "");
      set => this.ViewState[nameof (ButtonImagesFolder)] = (object) value;
    }

    [Category("Behavior")]
    [DefaultValue(false)]
    public virtual bool NoUnicode
    {
      get => this.EditPanel.NoUnicode;
      set => this.EditPanel.NoUnicode = value;
    }

    [Category("Behavior")]
    [DefaultValue(false)]
    public virtual bool NoScript
    {
      get => this.EditPanel.NoScript;
      set => this.EditPanel.NoScript = value;
    }

    [DefaultValue(false)]
    [Category("Behavior")]
    public virtual bool InitialCleanUp
    {
      get => this.EditPanel.InitialCleanUp;
      set => this.EditPanel.InitialCleanUp = value;
    }

    [Category("Appearance")]
    [DefaultValue("ajax__htmleditor_htmlpanel_default")]
    public virtual string HtmlPanelCssClass
    {
      get => this.EditPanel.HtmlPanelCssClass;
      set => this.EditPanel.HtmlPanelCssClass = value;
    }

    [Category("Appearance")]
    [DefaultValue("")]
    public virtual string DocumentCssPath
    {
      get => this.EditPanel.DocumentCssPath;
      set => this.EditPanel.DocumentCssPath = value;
    }

    [Category("Appearance")]
    [DefaultValue("")]
    public virtual string DesignPanelCssPath
    {
      get => this.EditPanel.DesignPanelCssPath;
      set => this.EditPanel.DesignPanelCssPath = value;
    }

    [DefaultValue(true)]
    [Category("Behavior")]
    public virtual bool AutoFocus
    {
      get => this.EditPanel.AutoFocus;
      set => this.EditPanel.AutoFocus = value;
    }

    [Category("Appearance")]
    [DefaultValue("")]
    public virtual string Content
    {
      get => this.EditPanel.Content;
      set => this.EditPanel.Content = value;
    }

    [Category("Behavior")]
    [DefaultValue(ActiveModeType.Design)]
    public virtual ActiveModeType ActiveMode
    {
      get => this.EditPanel.ActiveMode;
      set => this.EditPanel.ActiveMode = value;
    }

    [DefaultValue("")]
    [Category("Behavior")]
    public virtual string OnClientActiveModeChanged
    {
      get => this.EditPanel.OnClientActiveModeChanged;
      set => this.EditPanel.OnClientActiveModeChanged = value;
    }

    [DefaultValue("")]
    [Category("Behavior")]
    public virtual string OnClientBeforeActiveModeChanged
    {
      get => this.EditPanel.OnClientBeforeActiveModeChanged;
      set => this.EditPanel.OnClientBeforeActiveModeChanged = value;
    }

    [Category("Appearance")]
    [DefaultValue(typeof (Unit), "")]
    public override Unit Height
    {
      get => base.Height;
      set => base.Height = value;
    }

    [Category("Appearance")]
    [DefaultValue(typeof (Unit), "")]
    public override Unit Width
    {
      get => base.Width;
      set => base.Width = value;
    }

    [Category("Appearance")]
    [DefaultValue("ajax__htmleditor_editor_default")]
    public override string CssClass
    {
      get => base.CssClass;
      set => base.CssClass = value;
    }

    internal EditPanel EditPanel
    {
      get
      {
        if (this._editPanel == null)
          this._editPanel = (EditPanel) new EditPanelInstance();
        return this._editPanel;
      }
    }

    protected Toolbar BottomToolbar
    {
      get
      {
        if (this._bottomToolbar == null)
          this._bottomToolbar = (Toolbar) new ToolbarInstance();
        return this._bottomToolbar;
      }
    }

    protected Toolbar TopToolbar
    {
      get
      {
        if (this._topToolbar == null)
          this._topToolbar = (Toolbar) new ToolbarInstance();
        return this._topToolbar;
      }
    }

    protected override Style CreateControlStyle()
    {
      Editor.EditorStyle controlStyle = new Editor.EditorStyle(this.ViewState);
      controlStyle.CssClass = "ajax__htmleditor_editor_default";
      return (Style) controlStyle;
    }

    protected override void AddAttributesToRender(HtmlTextWriter writer)
    {
      if (!this.ControlStyleCreated || this.IsDesign)
        writer.AddAttribute(HtmlTextWriterAttribute.Class, (this.IsDesign ? "ajax__htmleditor_editor_base " : "") + "ajax__htmleditor_editor_default");
      base.AddAttributesToRender(writer);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddComponentProperty("editPanel", this.EditPanel.ClientID);
      if (this._changingToolbar == null)
        return;
      descriptor.AddComponentProperty("changingToolbar", this._changingToolbar.ClientID);
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.EditPanel.Toolbars.Add(this.BottomToolbar);
      this._changingToolbar = this.TopToolbar;
      this.EditPanel.Toolbars.Add(this.TopToolbar);
      Table child = new Table();
      child.CellPadding = 0;
      child.CellSpacing = 0;
      child.CssClass = "ajax__htmleditor_editor_container";
      child.Style[HtmlTextWriterStyle.BorderCollapse] = "separate";
      TableRow row1;
      this._topToolbarRow = row1 = new TableRow();
      TableCell cell1 = new TableCell();
      cell1.Controls.Add((Control) this.TopToolbar);
      cell1.CssClass = "ajax__htmleditor_editor_toptoolbar";
      row1.Cells.Add(cell1);
      child.Rows.Add(row1);
      TableRow row2 = new TableRow();
      TableCell cell2;
      this._editPanelCell = cell2 = new TableCell();
      cell2.CssClass = "ajax__htmleditor_editor_editpanel";
      cell2.Controls.Add((Control) this.EditPanel);
      row2.Cells.Add(cell2);
      child.Rows.Add(row2);
      TableRow row3;
      this._bottomToolbarRow = row3 = new TableRow();
      TableCell cell3 = new TableCell();
      cell3.Controls.Add((Control) this.BottomToolbar);
      cell3.CssClass = "ajax__htmleditor_editor_bottomtoolbar";
      row3.Cells.Add(cell3);
      child.Rows.Add(row3);
      this.Controls.Add((Control) child);
    }

    protected virtual void FillBottomToolbar()
    {
      this.BottomToolbar.Buttons.Add((CommonButton) new DesignMode());
      this.BottomToolbar.Buttons.Add((CommonButton) new HtmlMode());
      this.BottomToolbar.Buttons.Add((CommonButton) new PreviewMode());
    }

    protected virtual void FillTopToolbar()
    {
      this.TopToolbar.Buttons.Add((CommonButton) new Undo());
      this.TopToolbar.Buttons.Add((CommonButton) new Redo());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new Bold());
      this.TopToolbar.Buttons.Add((CommonButton) new Italic());
      this.TopToolbar.Buttons.Add((CommonButton) new Underline());
      this.TopToolbar.Buttons.Add((CommonButton) new StrikeThrough());
      this.TopToolbar.Buttons.Add((CommonButton) new SubScript());
      this.TopToolbar.Buttons.Add((CommonButton) new SuperScript());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new Ltr());
      this.TopToolbar.Buttons.Add((CommonButton) new Rtl());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      FixedForeColor fixedForeColor = new FixedForeColor();
      this.TopToolbar.Buttons.Add((CommonButton) fixedForeColor);
      ForeColorSelector foreColorSelector = new ForeColorSelector();
      foreColorSelector.FixedColorButtonId = fixedForeColor.ID = "FixedForeColor";
      this.TopToolbar.Buttons.Add((CommonButton) foreColorSelector);
      this.TopToolbar.Buttons.Add((CommonButton) new ForeColorClear());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      FixedBackColor fixedBackColor = new FixedBackColor();
      this.TopToolbar.Buttons.Add((CommonButton) fixedBackColor);
      BackColorSelector backColorSelector = new BackColorSelector();
      backColorSelector.FixedColorButtonId = fixedBackColor.ID = "FixedBackColor";
      this.TopToolbar.Buttons.Add((CommonButton) backColorSelector);
      this.TopToolbar.Buttons.Add((CommonButton) new BackColorClear());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new RemoveStyles());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      FontName fontName = new FontName();
      this.TopToolbar.Buttons.Add((CommonButton) fontName);
      Collection<SelectOption> options1 = fontName.Options;
      options1.Add(new SelectOption()
      {
        Value = "arial,helvetica,sans-serif",
        Text = "Arial"
      });
      options1.Add(new SelectOption()
      {
        Value = "courier new,courier,monospace",
        Text = "Courier New"
      });
      options1.Add(new SelectOption()
      {
        Value = "georgia,times new roman,times,serif",
        Text = "Georgia"
      });
      options1.Add(new SelectOption()
      {
        Value = "tahoma,arial,helvetica,sans-serif",
        Text = "Tahoma"
      });
      options1.Add(new SelectOption()
      {
        Value = "times new roman,times,serif",
        Text = "Times New Roman"
      });
      options1.Add(new SelectOption()
      {
        Value = "verdana,arial,helvetica,sans-serif",
        Text = "Verdana"
      });
      options1.Add(new SelectOption()
      {
        Value = "impact",
        Text = "Impact"
      });
      options1.Add(new SelectOption()
      {
        Value = "wingdings",
        Text = "WingDings"
      });
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      AjaxControlToolkit.HTMLEditor.ToolbarButton.FontSize fontSize = new AjaxControlToolkit.HTMLEditor.ToolbarButton.FontSize();
      this.TopToolbar.Buttons.Add((CommonButton) fontSize);
      Collection<SelectOption> options2 = fontSize.Options;
      options2.Add(new SelectOption()
      {
        Value = "8pt",
        Text = "1 ( 8 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "10pt",
        Text = "2 (10 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "12pt",
        Text = "3 (12 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "14pt",
        Text = "4 (14 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "18pt",
        Text = "5 (18 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "24pt",
        Text = "6 (24 pt)"
      });
      options2.Add(new SelectOption()
      {
        Value = "36pt",
        Text = "7 (36 pt)"
      });
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new Cut());
      this.TopToolbar.Buttons.Add((CommonButton) new Copy());
      this.TopToolbar.Buttons.Add((CommonButton) new Paste());
      this.TopToolbar.Buttons.Add((CommonButton) new PasteText());
      this.TopToolbar.Buttons.Add((CommonButton) new PasteWord());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new DecreaseIndent());
      this.TopToolbar.Buttons.Add((CommonButton) new IncreaseIndent());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new Paragraph());
      this.TopToolbar.Buttons.Add((CommonButton) new JustifyLeft());
      this.TopToolbar.Buttons.Add((CommonButton) new JustifyCenter());
      this.TopToolbar.Buttons.Add((CommonButton) new JustifyRight());
      this.TopToolbar.Buttons.Add((CommonButton) new JustifyFull());
      this.TopToolbar.Buttons.Add((CommonButton) new RemoveAlignment());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new OrderedList());
      this.TopToolbar.Buttons.Add((CommonButton) new AjaxControlToolkit.HTMLEditor.ToolbarButton.BulletedList());
      this.TopToolbar.Buttons.Add((CommonButton) new HorizontalSeparator());
      this.TopToolbar.Buttons.Add((CommonButton) new InsertHR());
      this.TopToolbar.Buttons.Add((CommonButton) new InsertLink());
      this.TopToolbar.Buttons.Add((CommonButton) new RemoveLink());
    }

    protected override void CreateChildControls()
    {
      this.BottomToolbar.Buttons.Clear();
      this.FillBottomToolbar();
      if (this.BottomToolbar.Buttons.Count == 0)
      {
        if (this.EditPanel.Toolbars.Contains(this.BottomToolbar))
          this.EditPanel.Toolbars.Remove(this.BottomToolbar);
        this._bottomToolbarRow.Visible = false;
        (this.EditPanel.Parent as TableCell).Style["border-bottom-width"] = "0px";
      }
      else
      {
        this.BottomToolbar.AlwaysVisible = true;
        this.BottomToolbar.ButtonImagesFolder = this.ButtonImagesFolder;
        for (int index = 0; index < this.BottomToolbar.Buttons.Count; ++index)
          this.BottomToolbar.Buttons[index].IgnoreTab = this.IgnoreTab;
      }
      this.TopToolbar.Buttons.Clear();
      this.FillTopToolbar();
      if (this.TopToolbar.Buttons.Count == 0)
      {
        if (this.EditPanel.Toolbars.Contains(this.TopToolbar))
          this.EditPanel.Toolbars.Remove(this.TopToolbar);
        this._topToolbarRow.Visible = false;
        (this.EditPanel.Parent as TableCell).Style["border-top-width"] = "0px";
        this._changingToolbar = (Toolbar) null;
      }
      else
      {
        this.TopToolbar.ButtonImagesFolder = this.ButtonImagesFolder;
        for (int index = 0; index < this.TopToolbar.Buttons.Count; ++index)
        {
          this.TopToolbar.Buttons[index].IgnoreTab = this.IgnoreTab;
          this.TopToolbar.Buttons[index].PreservePlace = this.TopToolbarPreservePlace;
        }
      }
      if (!this.Height.IsEmpty)
        (this.Controls[0] as Table).Style.Add(HtmlTextWriterStyle.Height, this.Height.ToString());
      if (!this.Width.IsEmpty)
        (this.Controls[0] as Table).Style.Add(HtmlTextWriterStyle.Width, this.Width.ToString());
      if (EditPanel.IE(this.Page) && !this.IsDesign)
        this._editPanelCell.Style[HtmlTextWriterStyle.Height] = "expression(AjaxControlToolkit.HTMLEditor.Editor.MidleCellHeightForIE(this.parentNode.parentNode.parentNode,this.parentNode))";
      this.EditPanel.IgnoreTab = this.IgnoreTab;
    }

    protected override void OnPreRender(EventArgs e)
    {
      try
      {
        base.OnPreRender(e);
      }
      catch
      {
      }
      this._wasPreRender = true;
    }

    protected override void Render(HtmlTextWriter writer)
    {
      if (!this._wasPreRender)
        this.OnPreRender(new EventArgs());
      base.Render(writer);
    }

    internal void CreateChilds(DesignerWithMapPath designer)
    {
      this.CreateChildControls();
      this.TopToolbar.CreateChilds(designer);
      this.BottomToolbar.CreateChilds(designer);
      this.EditPanel.SetDesigner((ControlDesigner) designer);
    }

    private sealed class EditorStyle : Style
    {
      public EditorStyle(StateBag state)
        : base(state)
      {
      }

      protected override void FillStyleAttributes(
        CssStyleCollection attributes,
        IUrlResolutionService urlResolver)
      {
        base.FillStyleAttributes(attributes, urlResolver);
        attributes.Remove(HtmlTextWriterStyle.Height);
        attributes.Remove(HtmlTextWriterStyle.Width);
      }
    }
  }
}
