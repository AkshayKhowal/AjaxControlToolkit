﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.FixedColorButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.FixedColorButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.FixedColorButton.js")]
  [PersistChildren(false)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  public abstract class FixedColorButton : DesignModeBoxButton
  {
    private MethodButton _methodButton;
    private DesignModeBoxButton _colorDiv;
    private string _defaultColor = "#000000";

    protected MethodButton MethodButton
    {
      get => this._methodButton;
      set => this._methodButton = value;
    }

    protected DesignModeBoxButton ColorDiv
    {
      get => this._colorDiv;
      set => this._colorDiv = value;
    }

    [DefaultValue("#000000")]
    [ExtenderControlProperty]
    [Category("Behavior")]
    [ClientPropertyName("defaultColor")]
    public string DefaultColor
    {
      get => this._defaultColor;
      set => this._defaultColor = value;
    }

    protected override void CreateChildControls()
    {
      Table table = new Table();
      table.Attributes.Add("border", "0");
      table.Attributes.Add("cellspacing", "0");
      table.Attributes.Add("cellpadding", "0");
      table.Style[HtmlTextWriterStyle.Margin] = "1px";
      table.Style[HtmlTextWriterStyle.Padding] = "0px";
      TableRow row1 = new TableRow();
      TableCell cell1 = new TableCell();
      table.Rows.Add(row1);
      row1.Cells.Add(cell1);
      if (this.MethodButton != null)
        cell1.Controls.Add((Control) this.MethodButton);
      TableRow row2 = new TableRow();
      TableCell cell2 = new TableCell();
      table.Rows.Add(row2);
      row2.Cells.Add(cell2);
      this.ColorDiv = new DesignModeBoxButton();
      this.ColorDiv.CssClass = "";
      this.ColorDiv.Style[HtmlTextWriterStyle.Margin] = "0px";
      this.ColorDiv.Style[HtmlTextWriterStyle.Padding] = "0px";
      this.ColorDiv.Width = new Unit(21.0, UnitType.Pixel);
      this.ColorDiv.Height = new Unit(5.0, UnitType.Pixel);
      this.ColorDiv.Style["background-color"] = this.DefaultColor;
      this.ColorDiv.Style["font-size"] = "1px";
      cell2.Controls.Add((Control) this.ColorDiv);
      this.Content.Add((Control) table);
      base.CreateChildControls();
    }

    protected override void OnPreRender(EventArgs e)
    {
      this.ColorDiv.ToolTip = this.ToolTip;
      if (this.MethodButton != null)
        this.MethodButton.ToolTip = this.ToolTip;
      base.OnPreRender(e);
    }

    internal override void CreateChilds(DesignerWithMapPath designer)
    {
      if (this.MethodButton != null)
        this.MethodButton._designer = designer;
      this.Content.Clear();
      base.CreateChilds(designer);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddComponentProperty("colorDiv", this.ColorDiv.ClientID);
      if (this.MethodButton == null)
        return;
      descriptor.AddComponentProperty("methodButton", this.MethodButton.ClientID);
    }
  }
}
