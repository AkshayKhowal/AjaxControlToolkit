﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.ImageButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.IO;
using System.Web;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [ParseChildren(true)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.ImageButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.ImageButton.js")]
  [PersistChildren(false)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  public abstract class ImageButton : CommonButton
  {
    public ImageButton()
      : base(HtmlTextWriterTag.Img)
    {
    }

    protected virtual Type BaseImageButtonType => typeof (ImageButton);

    [DefaultValue("")]
    [ClientPropertyName("normalSrc")]
    [Category("Appearance")]
    [ExtenderControlProperty]
    public string NormalSrc
    {
      get => (string) (this.ViewState[nameof (NormalSrc)] ?? (object) string.Empty);
      set => this.ViewState[nameof (NormalSrc)] = (object) value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeNormalSrc() => this.IsRenderingScript;

    [DefaultValue("")]
    [ExtenderControlProperty]
    [ClientPropertyName("hoverSrc")]
    [Category("Appearance")]
    public string HoverSrc
    {
      get => (string) (this.ViewState[nameof (HoverSrc)] ?? (object) string.Empty);
      set => this.ViewState[nameof (HoverSrc)] = (object) value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeHoverSrc() => this.IsRenderingScript;

    [ClientPropertyName("downSrc")]
    [DefaultValue("")]
    [Category("Appearance")]
    [ExtenderControlProperty]
    public string DownSrc
    {
      get => (string) (this.ViewState[nameof (DownSrc)] ?? (object) string.Empty);
      set => this.ViewState[nameof (DownSrc)] = (object) value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeDownSrc() => this.IsRenderingScript;

    [Category("Appearance")]
    [ClientPropertyName("activeSrc")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string ActiveSrc
    {
      get => (string) (this.ViewState[nameof (ActiveSrc)] ?? (object) string.Empty);
      set => this.ViewState[nameof (ActiveSrc)] = (object) value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeActiveSrc() => this.IsRenderingScript;

    protected void RegisterButtonImages(string name, string ext)
    {
      Type type1 = this.GetType();
      toolbar = (Toolbar) null;
      Control parent = this.Parent;
      while (true)
      {
        switch (parent)
        {
          case null:
          case Toolbar toolbar:
            goto label_3;
          default:
            parent = parent.Parent;
            continue;
        }
      }
label_3:
      if (toolbar == null)
        throw new NotSupportedException("Toolbar's ImageButton can be inside Toolbar control only");
      bool flag1 = false;
      for (Type type2 = type1; type2 != typeof (CommonButton); type2 = type2.BaseType)
      {
        if (type2 == typeof (HorizontalSeparator))
        {
          flag1 = true;
          break;
        }
      }
      if (flag1)
      {
        this.NormalSrc = this.getImagePath(this.BaseImageButtonType, name, ext, toolbar);
      }
      else
      {
        this.NormalSrc = this.getImagePath(this.BaseImageButtonType, name + "_n", ext, toolbar);
        this.DownSrc = this.getImagePath(this.BaseImageButtonType, name + "_a", ext, toolbar);
      }
      bool flag2 = false;
      for (Type baseType = type1.BaseType; baseType != typeof (CommonButton); baseType = baseType.BaseType)
      {
        if (baseType == typeof (EditorToggleButton) || baseType == typeof (ModeButton))
        {
          flag2 = true;
          break;
        }
      }
      if (!flag2)
        return;
      this.ActiveSrc = this.DownSrc;
    }

    protected void RegisterButtonImages(string name) => this.RegisterButtonImages(name, "gif");

    internal void InternalRegisterButtonImages(string name) => this.RegisterButtonImages(name, "gif");

    private string getImagePath(Type type, string name, string ext, Toolbar toolbar)
    {
      string buttonImagesFolder = toolbar.ButtonImagesFolder;
      string imagePath = this.Page.ClientScript.GetWebResourceUrl(type, "AjaxControlToolkit.HTMLEditor.Images." + name + "." + ext);
      if (buttonImagesFolder.Length > 0)
      {
        string str = buttonImagesFolder + name + "." + ext;
        string path = !this.IsDesign || this._designer == null ? HttpContext.Current.Server.MapPath(str) : this._designer.MapPath(str);
        if (path != null && File.Exists(path))
          imagePath = str;
      }
      return imagePath;
    }

    protected override void AddAttributesToRender(HtmlTextWriter writer)
    {
      writer.AddAttribute("src", this.NormalSrc);
      writer.AddAttribute("alt", "");
      base.AddAttributesToRender(writer);
    }
  }
}
