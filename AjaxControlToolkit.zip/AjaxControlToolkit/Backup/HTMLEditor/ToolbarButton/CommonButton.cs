﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.CommonButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [PersistChildren(false)]
  [ParseChildren(true)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.CommonButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.CommonButton.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  public abstract class CommonButton : ScriptControlBase
  {
    private Collection<ActiveModeType> _activeModes;
    private Collection<Control> _exportedControls;
    private bool _wasPreRender;
    private bool _IgnoreTab;
    internal DesignerWithMapPath _designer;
    private ResourceManager _rm;

    protected CommonButton(HtmlTextWriterTag tag)
      : base(false, tag)
    {
      this.CssClass = "ajax__htmleditor_toolbar_button";
    }

    protected CommonButton()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    protected bool IsDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    internal new Page Page
    {
      get => base.Page;
      set => base.Page = value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Collection<ActiveModeType> ActiveModes
    {
      get
      {
        if (this._activeModes == null)
          this._activeModes = new Collection<ActiveModeType>();
        return this._activeModes;
      }
    }

    internal Collection<Control> ExportedControls
    {
      get
      {
        if (this._exportedControls == null)
          this._exportedControls = new Collection<Control>();
        return this._exportedControls;
      }
    }

    [ExtenderControlProperty]
    [ClientPropertyName("preservePlace")]
    [DefaultValue(false)]
    public bool PreservePlace
    {
      get => (bool) (this.ViewState[nameof (PreservePlace)] ?? (object) false);
      set => this.ViewState[nameof (PreservePlace)] = (object) value;
    }

    [DefaultValue("ajax__htmleditor_toolbar_button")]
    public override string CssClass => "ajax__htmleditor_toolbar_button";

    [Category("Behavior")]
    [DefaultValue(false)]
    public bool IgnoreTab
    {
      get => this._IgnoreTab;
      set => this._IgnoreTab = value;
    }

    [Browsable(false)]
    [ClientPropertyName("activeModesIds")]
    [ExtenderControlProperty]
    public string ActiveModesIds
    {
      get
      {
        string activeModesIds = "";
        for (int index = 0; index < this.ActiveModes.Count; ++index)
        {
          if (index > 0)
            activeModesIds += ";";
          activeModesIds += ((int) this.ActiveModes[index]).ToString((IFormatProvider) CultureInfo.InvariantCulture).ToLowerInvariant();
        }
        return activeModesIds;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeActiveModesIds() => this.IsRenderingScript;

    protected string GetFromResource(string name) => this._rm.GetString("HTMLEditor_toolbar_button_" + this.GetType().Name + "_" + name);

    protected override void OnInit(EventArgs e)
    {
      this._rm = new ResourceManager("AjaxControlToolkit.ScriptResources.ScriptResources", Assembly.GetExecutingAssembly());
      this.ToolTip = this._rm.GetString("HTMLEditor_toolbar_button_" + this.GetType().Name + "_title");
      base.OnInit(e);
    }

    protected override void OnPreRender(EventArgs e)
    {
      try
      {
        base.OnPreRender(e);
      }
      catch
      {
      }
      this._wasPreRender = true;
    }

    protected override void Render(HtmlTextWriter writer)
    {
      if (!this._wasPreRender)
        this.OnPreRender(new EventArgs());
      base.Render(writer);
    }

    internal virtual void CreateChilds(DesignerWithMapPath designer)
    {
      this._designer = designer;
      this.Controls.Clear();
      this.CreateChildControls();
    }
  }
}
