﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.SelectButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.SelectButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.SelectButton.js")]
  [PersistChildren(false)]
  public abstract class SelectButton : CommonButton
  {
    private Collection<SelectOption> _options;

    public SelectButton()
      : base(HtmlTextWriterTag.Div)
    {
    }

    [PersistenceMode(PersistenceMode.InnerProperty)]
    public Collection<SelectOption> Options
    {
      get
      {
        if (this._options == null)
          this._options = new Collection<SelectOption>();
        return this._options;
      }
    }

    [Category("Appearance")]
    [System.ComponentModel.DefaultValue("")]
    public virtual string SelectWidth => string.Empty;

    [System.ComponentModel.DefaultValue("")]
    [Category("Appearance")]
    public virtual string DefaultValue => string.Empty;

    [System.ComponentModel.DefaultValue(true)]
    [Category("Appearance")]
    public virtual bool UseDefaultValue => true;

    protected override void CreateChildControls()
    {
      HtmlGenericControl child1 = new HtmlGenericControl("nobr");
      HtmlGenericControl child2 = new HtmlGenericControl("span");
      child2.Attributes.Add("class", "ajax__htmleditor_toolbar_selectlable");
      child2.ID = "label";
      child2.Controls.Add((Control) new LiteralControl(this.GetFromResource("label") + "&nbsp;"));
      child1.Controls.Add((Control) child2);
      HtmlGenericControl child3 = new HtmlGenericControl("select");
      child3.Attributes.Add("class", "ajax__htmleditor_toolbar_selectbutton");
      child3.ID = "select";
      if (!string.IsNullOrEmpty(this.SelectWidth))
        child3.Style[HtmlTextWriterStyle.Width] = this.SelectWidth;
      if (this.IgnoreTab)
        child3.Attributes.Add("tabindex", "-1");
      child1.Controls.Add((Control) child3);
      if (this.UseDefaultValue)
        child3.Controls.Add((Control) new LiteralControl("<option value=\"" + this.DefaultValue + "\">" + this.GetFromResource("defaultValue") + "</option>"));
      for (int index = 0; index < this.Options.Count; ++index)
        child3.Controls.Add((Control) new LiteralControl("<option value=\"" + this.Options[index].Value + "\">" + this.Options[index].Text + "</option>"));
      this.Controls.Add((Control) child1);
    }

    protected override Style CreateControlStyle() => (Style) new SelectButton.SelectButtonStyle(this.ViewState);

    private sealed class SelectButtonStyle : Style
    {
      public SelectButtonStyle(StateBag state)
        : base(state)
      {
      }

      protected override void FillStyleAttributes(
        CssStyleCollection attributes,
        IUrlResolutionService urlResolver)
      {
        base.FillStyleAttributes(attributes, urlResolver);
        attributes.Add("background-color", "transparent");
        attributes.Add("cursor", "text");
      }
    }
  }
}
