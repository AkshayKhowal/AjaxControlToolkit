﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignModePopupImageButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using AjaxControlToolkit.HTMLEditor.Popups;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.DesignModePopupImageButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.DesignModePopupImageButton.js")]
  [ParseChildren(true)]
  [PersistChildren(false)]
  public abstract class DesignModePopupImageButton : MethodButton
  {
    private Popup _popup;
    private bool _autoClose = true;

    protected Popup RelatedPopup
    {
      get => this._popup;
      set
      {
        this._popup = value;
        if (this.IsDesign)
          return;
        Popup existingPopup = Popup.GetExistingPopup(this.Parent, this.RelatedPopup.GetType());
        if (existingPopup == null)
          this.ExportedControls.Add((Control) this._popup);
        else
          this._popup = existingPopup;
      }
    }

    protected bool AutoClose
    {
      get => this._autoClose;
      set => this._autoClose = value;
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      if (this.RelatedPopup != null && !this.IsDesign)
        descriptor.AddComponentProperty("relatedPopup", this.RelatedPopup.ClientID);
      descriptor.AddProperty("autoClose", (object) this.AutoClose);
    }
  }
}
