﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.ModeButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [ParseChildren(true)]
  [PersistChildren(false)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (Enums))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.ModeButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.ModeButton.js")]
  public abstract class ModeButton : ImageButton
  {
    public ModeButton()
    {
      this.ActiveModes.Add(ActiveModeType.Design);
      this.ActiveModes.Add(ActiveModeType.Html);
      this.ActiveModes.Add(ActiveModeType.Preview);
    }

    [Category("Behavior")]
    [ExtenderControlProperty]
    [ClientPropertyName("activeMode")]
    [DefaultValue(ActiveModeType.Design)]
    public ActiveModeType ActiveMode
    {
      get => (ActiveModeType) (this.ViewState[nameof (ActiveMode)] ?? (object) ActiveModeType.Design);
      set => this.ViewState[nameof (ActiveMode)] = (object) value;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public bool ShouldSerializeActiveMode() => this.IsRenderingScript;
  }
}
