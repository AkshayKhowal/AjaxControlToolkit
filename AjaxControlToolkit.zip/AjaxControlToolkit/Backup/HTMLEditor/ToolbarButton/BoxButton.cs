﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.BoxButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.BoxButton", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.BoxButton.js")]
  [PersistChildren(false)]
  public abstract class BoxButton : CommonButton
  {
    private ITemplate _contentTemplate;
    private Collection<Control> _content;

    protected BoxButton()
      : base(HtmlTextWriterTag.Div)
    {
    }

    [MergableProperty(false)]
    [Browsable(false)]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    [TemplateInstance(TemplateInstance.Single)]
    public ITemplate ContentTemplate
    {
      get => this._contentTemplate;
      set => this._contentTemplate = value;
    }

    protected Collection<Control> Content
    {
      get
      {
        if (this._content == null)
          this._content = new Collection<Control>();
        return this._content;
      }
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      if (this._contentTemplate == null)
        return;
      Control container = new Control();
      this._contentTemplate.InstantiateIn(container);
      this.Content.Add(container);
    }

    protected override void CreateChildControls()
    {
      for (int index = 0; index < this.Content.Count; ++index)
        this.Controls.Add(this.Content[index]);
      base.CreateChildControls();
    }
  }
}
