﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.ColorSelector
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using AjaxControlToolkit.HTMLEditor.Popups;
using System;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.ColorSelector", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.ColorSelector.js")]
  [ParseChildren(true)]
  [PersistChildren(false)]
  public abstract class ColorSelector : Selector
  {
    private string _fixedColorButtonId = "";

    [DefaultValue("")]
    public string FixedColorButtonId
    {
      get => this._fixedColorButtonId;
      set => this._fixedColorButtonId = value;
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.RelatedPopup = (Popup) new BaseColorsPopup();
    }

    protected override void OnPreRender(EventArgs e)
    {
      if (this.FixedColorButtonId.Length > 0 && !this.IsDesign && this.Parent.FindControl(this.FixedColorButtonId) is FixedColorButton control)
        this.ToolTip = control.ToolTip;
      base.OnPreRender(e);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      if (this.FixedColorButtonId.Length <= 0 || this.IsDesign)
        return;
      if (!(this.Parent.FindControl(this.FixedColorButtonId) is FixedColorButton control))
        throw new ArgumentException("FixedColorButton control's ID expected");
      descriptor.AddComponentProperty("fixedColorButton", control.ClientID);
    }
  }
}
