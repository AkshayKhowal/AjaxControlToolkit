﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [PersistChildren(false)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.Selector", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.Selector.js")]
  public abstract class Selector : DesignModePopupImageButton
  {
    protected override void OnPreRender(EventArgs e)
    {
      this.RegisterButtonImages("ed_selector");
      base.OnPreRender(e);
    }

    protected override Style CreateControlStyle() => (Style) new Selector.SelectorStyle(this.ViewState);

    private sealed class SelectorStyle : Style
    {
      public SelectorStyle(StateBag state)
        : base(state)
      {
      }

      protected override void FillStyleAttributes(
        CssStyleCollection attributes,
        IUrlResolutionService urlResolver)
      {
        base.FillStyleAttributes(attributes, urlResolver);
        attributes.Add("width", "11px");
      }
    }
  }
}
