﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.ToolbarButton.FontSize
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.ToolbarButton
{
  [PersistChildren(false)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.ToolbarButton.FontSize", "AjaxControlToolkit.HTMLEditor.Toolbar_buttons.FontSize.js")]
  [ParseChildren(true)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ToolboxItem(false)]
  public class FontSize : DesignModeSelectButton
  {
    [Category("Appearance")]
    [DefaultValue("70px")]
    public override string SelectWidth => "70px";
  }
}
