Type.registerNamespace("AjaxControlToolkit.HTMLEditor.Popups");

AjaxControlToolkit.HTMLEditor.Popups.BaseColorsPopup = function(element) {
    AjaxControlToolkit.HTMLEditor.Popups.BaseColorsPopup.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.Popups.BaseColorsPopup.prototype = {
}

AjaxControlToolkit.HTMLEditor.Popups.BaseColorsPopup.registerClass("AjaxControlToolkit.HTMLEditor.Popups.BaseColorsPopup", AjaxControlToolkit.HTMLEditor.Popups.AttachedTemplatePopup);
