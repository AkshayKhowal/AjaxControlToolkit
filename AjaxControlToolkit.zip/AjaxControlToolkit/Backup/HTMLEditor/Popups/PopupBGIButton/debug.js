Type.registerNamespace("AjaxControlToolkit.HTMLEditor.Popups");

AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton = function(element) {
    AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton.initializeBase(this, [element]);
}

AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton.prototype = {
}

AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton.registerClass("AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton", AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton);

