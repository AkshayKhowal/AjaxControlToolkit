Type.registerNamespace("AjaxControlToolkit.HTMLEditor.Popups");

AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton = function(element) {
    AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton.initializeBase(this, [element]);

    this._designPanel = null;
}

AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton.prototype = {
}

AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton.registerClass("AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton", AjaxControlToolkit.HTMLEditor.Popups.PopupCommonButton);

