﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.PopupCommonButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [RequiredScript(typeof (CommonToolkitScripts))]
  [PersistChildren(false)]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.PopupCommonButton", "AjaxControlToolkit.HTMLEditor.Popups.PopupCommonButton.js")]
  [ParseChildren(true)]
  public abstract class PopupCommonButton : ScriptControlBase
  {
    private Collection<Control> _exportedControls;
    private string _name = string.Empty;

    protected PopupCommonButton(HtmlTextWriterTag tag)
      : base(false, tag)
    {
    }

    protected PopupCommonButton()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    protected bool IsDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    internal Collection<Control> ExportedControls
    {
      get
      {
        if (this._exportedControls == null)
          this._exportedControls = new Collection<Control>();
        return this._exportedControls;
      }
    }

    [Category("Behavior")]
    [ExtenderControlProperty]
    [ClientPropertyName("name")]
    [DefaultValue("")]
    public string Name
    {
      get => this._name;
      set => this._name = value;
    }
  }
}
