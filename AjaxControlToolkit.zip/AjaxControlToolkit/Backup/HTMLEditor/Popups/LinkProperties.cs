﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.LinkProperties
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.LinkProperties", "AjaxControlToolkit.HTMLEditor.Popups.LinkProperties.js")]
  [ParseChildren(true)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  internal class LinkProperties : OkCancelAttachedTemplatePopup
  {
    private string _defaultTarget = "_self";
    private TextBox _url = new TextBox();
    private HtmlSelect _target = new HtmlSelect();

    [DefaultValue("_self")]
    [Category("Behavior")]
    public string DefaultTarget
    {
      get => this._defaultTarget;
      set => this._defaultTarget = value;
    }

    protected override void CreateChildControls()
    {
      HtmlGenericControl child1 = new HtmlGenericControl("span");
      HtmlGenericControl child2 = new HtmlGenericControl("span");
      Table table = new Table();
      table.Attributes.Add("border", "0");
      table.Attributes.Add("cellspacing", "0");
      table.Attributes.Add("cellpadding", "2");
      TableRow row1 = new TableRow();
      table.Rows.Add(row1);
      TableCell cell1 = new TableCell();
      row1.Cells.Add(cell1);
      cell1.HorizontalAlign = HorizontalAlign.Left;
      cell1.Controls.Add((Control) child1);
      child1.Controls.Add((Control) new LiteralControl(this.GetField("URL")));
      cell1.Controls.Add((Control) new LiteralControl(":"));
      TableCell cell2 = new TableCell();
      row1.Cells.Add(cell2);
      cell2.HorizontalAlign = HorizontalAlign.Left;
      this._url.Style["width"] = "200px";
      this._url.MaxLength = (int) byte.MaxValue;
      cell2.Controls.Add((Control) this._url);
      TableRow row2 = new TableRow();
      table.Rows.Add(row2);
      TableCell cell3 = new TableCell();
      row2.Cells.Add(cell3);
      cell3.HorizontalAlign = HorizontalAlign.Left;
      cell3.Controls.Add((Control) child2);
      child2.Controls.Add((Control) new LiteralControl(this.GetField("Target")));
      cell3.Controls.Add((Control) new LiteralControl(":"));
      TableCell cell4 = new TableCell();
      row2.Cells.Add(cell4);
      cell4.HorizontalAlign = HorizontalAlign.Left;
      this._target.Style["width"] = "105px";
      this._target.Items.Add(new ListItem(this.GetField("Target", "New"), "_blank"));
      this._target.Items.Add(new ListItem(this.GetField("Target", "Current"), "_self"));
      this._target.Items.Add(new ListItem(this.GetField("Target", "Parent"), "_parent"));
      this._target.Items.Add(new ListItem(this.GetField("Target", "Top"), "_top"));
      cell4.Controls.Add((Control) this._target);
      this.Content.Add((Control) table);
      this.RegisteredFields.Add(new RegisteredField("url", (Control) this._url));
      this.RegisteredFields.Add(new RegisteredField("target", (Control) this._target));
      base.CreateChildControls();
    }

    protected override void OnPreRender(EventArgs e)
    {
      this._url.Attributes.Add("id", this._url.ClientID);
      this._target.Attributes.Add("id", this._target.ClientID);
      base.OnPreRender(e);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddProperty("defaultTarget", (object) this.DefaultTarget);
    }
  }
}
