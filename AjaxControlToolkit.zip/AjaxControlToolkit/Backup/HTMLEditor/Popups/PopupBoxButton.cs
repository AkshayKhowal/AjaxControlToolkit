﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton", "AjaxControlToolkit.HTMLEditor.Popups.PopupBoxButton.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ParseChildren(true)]
  [PersistChildren(false)]
  internal class PopupBoxButton : PopupCommonButton
  {
    private ITemplate _contentTemplate;
    private Collection<Control> _content;

    public PopupBoxButton()
      : base(HtmlTextWriterTag.Div)
    {
      this.CssClass = "ajax__htmleditor_popup_boxbutton";
    }

    public PopupBoxButton(HtmlTextWriterTag tag)
      : base(tag)
    {
      this.CssClass = "ajax__htmleditor_popup_boxbutton";
    }

    [PersistenceMode(PersistenceMode.InnerProperty)]
    [TemplateInstance(TemplateInstance.Single)]
    [Browsable(false)]
    [MergableProperty(false)]
    public ITemplate ContentTemplate
    {
      get => this._contentTemplate;
      set => this._contentTemplate = value;
    }

    protected Collection<Control> Content
    {
      get
      {
        if (this._content == null)
          this._content = new Collection<Control>();
        return this._content;
      }
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      if (this._contentTemplate == null)
        return;
      Control container = new Control();
      this._contentTemplate.InstantiateIn(container);
      this.Content.Add(container);
    }

    protected override void CreateChildControls()
    {
      for (int index = 0; index < this.Content.Count; ++index)
        this.Controls.Add(this.Content[index]);
      base.CreateChildControls();
    }
  }
}
