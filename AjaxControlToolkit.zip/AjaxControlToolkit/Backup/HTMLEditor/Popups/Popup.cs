﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.Popup
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Reflection;
using System.Resources;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.Popup", "AjaxControlToolkit.HTMLEditor.Popups.Popup.js")]
  [ParseChildren(true)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  public abstract class Popup : ScriptControlBase
  {
    private HtmlGenericControl _iframe;
    private string _savedCSS;
    private string _initialContent = "";
    private string _cssPath = "";
    private bool _autoDimensions = true;
    private Collection<RegisteredField> _registeredFields;
    private Collection<RegisteredField> _registeredHandlers;
    private ResourceManager _rm;

    public static Popup GetExistingPopup(Control parent, Type type)
    {
      foreach (Control control in parent.Controls)
      {
        if (control.GetType().Equals(type))
          return control as Popup;
        Control existingPopup = (Control) Popup.GetExistingPopup(control, type);
        if (existingPopup != null)
          return existingPopup as Popup;
      }
      return (Popup) null;
    }

    protected Popup()
      : base(false, HtmlTextWriterTag.Div)
    {
    }

    private bool isDesign
    {
      get
      {
        try
        {
          return this.Context == null || this.Site != null && this.Site.DesignMode;
        }
        catch
        {
          return true;
        }
      }
    }

    [Category("behavior")]
    [ClientPropertyName("autoDimensions")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public bool AutoDimensions
    {
      get => this._autoDimensions;
      set => this._autoDimensions = value;
    }

    [Category("Appearance")]
    [ClientPropertyName("initialContent")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string InitialContent
    {
      get => this._initialContent;
      set => this._initialContent = value;
    }

    [ClientPropertyName("cssPath")]
    [ExtenderControlProperty]
    [Category("Appearance")]
    [DefaultValue("")]
    public string CssPath
    {
      get => this._cssPath;
      set => this._cssPath = value;
    }

    public Collection<RegisteredField> RegisteredFields
    {
      get
      {
        if (this._registeredFields == null)
          this._registeredFields = new Collection<RegisteredField>();
        return this._registeredFields;
      }
    }

    private string RegisteredFieldsIds
    {
      get
      {
        string str = "[";
        for (int index = 0; index < this.RegisteredFields.Count; ++index)
        {
          if (index > 0)
            str += ",";
          str = str + "{name: " + "'" + this.RegisteredFields[index].Name + "'" + ", clientID: " + "'" + this.RegisteredFields[index].Control.ClientID + "'" + "}";
        }
        return str + "]";
      }
    }

    public Collection<RegisteredField> RegisteredHandlers
    {
      get
      {
        if (this._registeredHandlers == null)
          this._registeredHandlers = new Collection<RegisteredField>();
        return this._registeredHandlers;
      }
    }

    private string RegisteredHandlersIds
    {
      get
      {
        string str = "[";
        for (int index = 0; index < this.RegisteredHandlers.Count; ++index)
        {
          if (index > 0)
            str += ",";
          str = str + "{name: " + "'" + this.RegisteredHandlers[index].Name + "'" + ", clientID: " + "'" + this.RegisteredHandlers[index].Control.ClientID + "'" + ", callMethod: null" + "}";
        }
        return str + "]";
      }
    }

    protected string GetButton(string name) => this._rm.GetString("HTMLEditor_toolbar_popup_" + this.GetType().Name + "_button_" + name);

    protected string GetField(string name) => this._rm.GetString("HTMLEditor_toolbar_popup_" + this.GetType().Name + "_field_" + name);

    protected string GetField(string name, string subName) => this.GetField(name + "_" + subName);

    protected override Style CreateControlStyle() => (Style) new Popup.PopupStyle(this.ViewState, this);

    protected override void OnInit(EventArgs e)
    {
      this._rm = new ResourceManager("AjaxControlToolkit.ScriptResources.ScriptResources", Assembly.GetExecutingAssembly());
      base.OnInit(e);
      if (this.isDesign)
        return;
      this._iframe = new HtmlGenericControl("iframe");
      this._iframe.Attributes.Add("scrolling", "no");
      this._iframe.Attributes.Add("marginHeight", "0");
      this._iframe.Attributes.Add("marginWidth", "0");
      this._iframe.Attributes.Add("frameborder", "0");
      this._iframe.Attributes.Add("tabindex", "-1");
      this.Controls.Add((Control) this._iframe);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      if (this._iframe != null)
      {
        string str = this._savedCSS != null ? this._savedCSS : this.Style.Value;
        if (str != null && str.Length > 0)
          this._iframe.Style.Value = str;
        if (this.Height.ToString().Length > 0)
          this._iframe.Style[HtmlTextWriterStyle.Height] = this.Height.ToString();
        if (this.Width.ToString().Length > 0)
          this._iframe.Style[HtmlTextWriterStyle.Width] = this.Width.ToString();
        this._iframe.Attributes.Add("id", this._iframe.ClientID);
      }
      this.Height = this.Height;
    }

    protected override void Render(HtmlTextWriter writer)
    {
      if (this.isDesign)
        return;
      base.Render(writer);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddElementProperty("iframe", this._iframe.ClientID);
      descriptor.AddProperty("registeredFields", (object) this.RegisteredFieldsIds);
      descriptor.AddProperty("registeredHandlers", (object) this.RegisteredHandlersIds);
    }

    private sealed class PopupStyle : Style
    {
      private Popup _popup;

      public PopupStyle(StateBag state, Popup popup)
        : base(state)
      {
        this._popup = popup;
      }

      protected override void FillStyleAttributes(
        CssStyleCollection attributes,
        IUrlResolutionService urlResolver)
      {
        this._popup._savedCSS = attributes.Value;
        attributes.Add(HtmlTextWriterStyle.Position, "absolute");
        attributes.Add(HtmlTextWriterStyle.Top, "-2000px");
        attributes.Add(HtmlTextWriterStyle.Left, "-2000px");
      }
    }
  }
}
