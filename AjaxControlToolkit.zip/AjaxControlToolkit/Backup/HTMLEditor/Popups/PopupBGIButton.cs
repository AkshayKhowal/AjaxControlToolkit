﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton", "AjaxControlToolkit.HTMLEditor.Popups.PopupBGIButton.js")]
  [ParseChildren(true)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [PersistChildren(false)]
  internal class PopupBGIButton : PopupBoxButton
  {
    private string _text = "";

    public PopupBGIButton()
      : base(HtmlTextWriterTag.Div)
    {
    }

    public PopupBGIButton(HtmlTextWriterTag tag)
      : base(tag)
    {
    }

    [DefaultValue("")]
    [Category("Appearance")]
    public string Text
    {
      get => this._text;
      set => this._text = value;
    }

    protected override void CreateChildControls()
    {
      HtmlGenericControl child1 = new HtmlGenericControl("span");
      Table table = new Table();
      table.Attributes.Add("border", "0");
      table.Attributes.Add("cellspacing", "0");
      table.Attributes.Add("cellpadding", "0");
      TableRow row = new TableRow();
      table.Rows.Add(row);
      TableCell cell = new TableCell();
      row.Cells.Add(cell);
      cell.VerticalAlign = VerticalAlign.Middle;
      cell.HorizontalAlign = HorizontalAlign.Center;
      cell.CssClass = "ajax__htmleditor_popup_bgibutton";
      LiteralControl child2 = new LiteralControl(this.Text);
      child1.Controls.Add((Control) child2);
      cell.Controls.Add((Control) child1);
      this.Content.Add((Control) table);
      base.CreateChildControls();
    }
  }
}
