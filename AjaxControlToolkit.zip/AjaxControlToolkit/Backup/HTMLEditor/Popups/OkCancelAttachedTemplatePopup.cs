﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.OkCancelAttachedTemplatePopup
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ToolboxItem(false)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.OkCancelAttachedTemplatePopup", "AjaxControlToolkit.HTMLEditor.Popups.OkCancelAttachedTemplatePopup.js")]
  [ParseChildren(true)]
  public class OkCancelAttachedTemplatePopup : AttachedTemplatePopup
  {
    protected override void CreateChildControls()
    {
      PopupBGIButton child1 = new PopupBGIButton();
      child1.Text = this.GetButton("OK");
      child1.Name = "OK";
      child1.CssClass += " ajax__htmleditor_popup_confirmbutton ";
      PopupBGIButton child2 = new PopupBGIButton();
      child2.Text = this.GetButton("Cancel");
      child2.Name = "Cancel";
      child2.CssClass += " ajax__htmleditor_popup_confirmbutton";
      Table table = new Table();
      table.Attributes.Add("border", "0");
      table.Attributes.Add("cellspacing", "0");
      table.Attributes.Add("cellpadding", "0");
      table.Style["width"] = "100%";
      TableRow row = new TableRow();
      table.Rows.Add(row);
      TableCell cell = new TableCell();
      row.Cells.Add(cell);
      cell.HorizontalAlign = HorizontalAlign.Right;
      cell.Controls.Add((Control) child1);
      cell.Controls.Add((Control) child2);
      this.Content.Add((Control) table);
      this.RegisteredHandlers.Add(new RegisteredField("OK", (Control) child1));
      this.RegisteredHandlers.Add(new RegisteredField("Cancel", (Control) child2));
      base.CreateChildControls();
    }
  }
}
