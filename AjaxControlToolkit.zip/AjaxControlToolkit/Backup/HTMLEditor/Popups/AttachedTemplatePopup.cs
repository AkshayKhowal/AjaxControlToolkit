﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.HTMLEditor.Popups.AttachedTemplatePopup
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace AjaxControlToolkit.HTMLEditor.Popups
{
  [ClientScriptResource("AjaxControlToolkit.HTMLEditor.Popups.AttachedTemplatePopup", "AjaxControlToolkit.HTMLEditor.Popups.AttachedTemplatePopup.js")]
  [ParseChildren(true)]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ToolboxItem(false)]
  public class AttachedTemplatePopup : AttachedPopup
  {
    private ITemplate _contentTemplate;
    private HtmlGenericControl _contentDiv;
    private Collection<Control> _content;
    private string _containerCSSClass = "ajax__htmleditor_attachedpopup_default";

    [DefaultValue("ajax__htmleditor_attachedpopup_default")]
    [Category("Appearance")]
    public string ContainerCSSClass
    {
      get => this._containerCSSClass;
      set => this._containerCSSClass = value;
    }

    [PersistenceMode(PersistenceMode.InnerProperty)]
    [TemplateInstance(TemplateInstance.Single)]
    [Browsable(false)]
    [MergableProperty(false)]
    public ITemplate ContentTemplate
    {
      get => this._contentTemplate;
      set => this._contentTemplate = value;
    }

    protected Collection<Control> Content
    {
      get
      {
        if (this._content == null)
          this._content = new Collection<Control>();
        return this._content;
      }
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      if (this.CssPath.Length == 0)
        this.CssPath = this.Page.ClientScript.GetWebResourceUrl(typeof (AttachedPopup), "AjaxControlToolkit.HTMLEditor.Popups.AttachedTemplatePopup.css");
      if (this._contentTemplate == null)
        return;
      Control container = new Control();
      this._contentTemplate.InstantiateIn(container);
      this.Content.Add(container);
    }

    protected override void CreateChildControls()
    {
      this._contentDiv = new HtmlGenericControl("div");
      this._contentDiv.Style[HtmlTextWriterStyle.Display] = "none";
      HtmlGenericControl child = new HtmlGenericControl("div");
      child.Attributes.Add("class", this.ContainerCSSClass);
      this._contentDiv.Controls.Add((Control) child);
      for (int index = 0; index < this.Content.Count; ++index)
        child.Controls.Add(this.Content[index]);
      this.Controls.Add((Control) this._contentDiv);
      base.CreateChildControls();
    }

    protected override void OnPreRender(EventArgs e)
    {
      this._contentDiv.Attributes.Add("id", this._contentDiv.ClientID);
      base.OnPreRender(e);
    }

    protected override void DescribeComponent(ScriptComponentDescriptor descriptor)
    {
      base.DescribeComponent(descriptor);
      descriptor.AddElementProperty("contentDiv", this._contentDiv.ClientID);
    }
  }
}
