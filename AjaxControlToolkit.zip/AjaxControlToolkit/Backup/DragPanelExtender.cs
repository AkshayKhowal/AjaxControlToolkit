﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DragPanelExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ClientScriptResource("AjaxControlToolkit.FloatingBehavior", "AjaxControlToolkit.DragPanel.FloatingBehavior.js")]
  [RequiredScript(typeof (DragDropScripts))]
  [ToolboxBitmap(typeof (DragPanelExtender), "DragPanel.DragPanel.ico")]
  [TargetControlType(typeof (WebControl))]
  [Designer("AjaxControlToolkit.DragPanelDesigner, AjaxControlToolkit")]
  public class DragPanelExtender : ExtenderControlBase
  {
    [ClientPropertyName("handle")]
    [IDReferenceProperty(typeof (WebControl))]
    [ExtenderControlProperty]
    [ElementReference]
    [RequiredProperty]
    public string DragHandleID
    {
      get
      {
        string dragHandleId = this.GetPropertyValue<string>(nameof (DragHandleID), "");
        if (string.IsNullOrEmpty(dragHandleId))
          dragHandleId = this.TargetControlID;
        return dragHandleId;
      }
      set => this.SetPropertyValue<string>(nameof (DragHandleID), value);
    }
  }
}
