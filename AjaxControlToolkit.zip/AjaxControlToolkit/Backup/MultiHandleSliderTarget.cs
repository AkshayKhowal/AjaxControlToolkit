﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MultiHandleSliderTarget
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [PersistChildren(false)]
  [ParseChildren(true)]
  public class MultiHandleSliderTarget
  {
    private string _controlID;
    private string _handleCssClass;
    private int _decimals;
    private int _offset;

    [IDReferenceProperty(typeof (WebControl))]
    [ExtenderControlProperty]
    [Description("Sets the ID of the control that is bound to the location of this handle.")]
    [NotifyParentProperty(true)]
    public string ControlID
    {
      get => this._controlID;
      set => this._controlID = value;
    }

    [Description("Sets the style of the handle associated with the MultiHandleSliderTarget, if custom styles are used.")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    [NotifyParentProperty(true)]
    public string HandleCssClass
    {
      get => this._handleCssClass;
      set => this._handleCssClass = value;
    }

    [Description("Sets the number of decimal places to store with the value.")]
    [DefaultValue(0)]
    [NotifyParentProperty(true)]
    [ExtenderControlProperty]
    public int Decimals
    {
      get => this._decimals;
      set => this._decimals = value;
    }

    [Description("Sets the number of pixels to offset the width of the handle, for handles with transparent space.")]
    [ExtenderControlProperty]
    [DefaultValue(0)]
    [NotifyParentProperty(true)]
    public int Offset
    {
      get => this._offset;
      set => this._offset = value;
    }
  }
}
