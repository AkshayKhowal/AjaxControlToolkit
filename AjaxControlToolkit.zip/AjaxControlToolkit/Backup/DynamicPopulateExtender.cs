﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DynamicPopulateExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [ClientScriptResource("AjaxControlToolkit.DynamicPopulateBehavior", "AjaxControlToolkit.DynamicPopulate.DynamicPopulateBehavior.js")]
  [ToolboxBitmap(typeof (DynamicPopulateExtender), "DynamicPopulate.DynamicPopulate.ico")]
  [Designer("AjaxControlToolkit.DynamicPopulateDesigner, AjaxControlToolkit")]
  [TargetControlType(typeof (Control))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  public class DynamicPopulateExtender : ExtenderControlBase
  {
    [Category("Behavior")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public bool ClearContentsDuringUpdate
    {
      get => this.GetPropertyValue<bool>(nameof (ClearContentsDuringUpdate), true);
      set => this.SetPropertyValue<bool>(nameof (ClearContentsDuringUpdate), value);
    }

    [Category("Behavior")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string ContextKey
    {
      get => this.GetPropertyValue<string>(nameof (ContextKey), "");
      set => this.SetPropertyValue<string>(nameof (ContextKey), value);
    }

    [ExtenderControlProperty]
    [IDReferenceProperty(typeof (Control))]
    [ClientPropertyName("PopulateTriggerID")]
    [Category("Behavior")]
    public string PopulateTriggerControlID
    {
      get => this.GetPropertyValue<string>(nameof (PopulateTriggerControlID), "");
      set => this.SetPropertyValue<string>(nameof (PopulateTriggerControlID), value);
    }

    [ExtenderControlProperty]
    [Category("Behavior")]
    [DefaultValue("")]
    public string ServiceMethod
    {
      get => this.GetPropertyValue<string>(nameof (ServiceMethod), "");
      set
      {
        if (!string.IsNullOrEmpty(this.CustomScript))
          throw new InvalidOperationException("ServiceMethod can not be set if a CustomScript is set.");
        this.SetPropertyValue<string>(nameof (ServiceMethod), value);
      }
    }

    [UrlProperty]
    [ExtenderControlProperty]
    [Category("Behavior")]
    [TypeConverter(typeof (ServicePathConverter))]
    public string ServicePath
    {
      get => this.GetPropertyValue<string>(nameof (ServicePath), "");
      set => this.SetPropertyValue<string>(nameof (ServicePath), value);
    }

    private bool ShouldSerializeServicePath() => !string.IsNullOrEmpty(this.ServiceMethod);

    [Category("Behavior")]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string UpdatingCssClass
    {
      get => this.GetPropertyValue<string>("UpdatingCss", "");
      set => this.SetPropertyValue<string>("UpdatingCss", value);
    }

    [Category("Behavior")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string CustomScript
    {
      get => this.GetPropertyValue<string>(nameof (CustomScript), "");
      set
      {
        if (!string.IsNullOrEmpty(this.ServiceMethod))
          throw new InvalidOperationException("CustomScript can not be set if a ServiceMethod is set.");
        this.SetPropertyValue<string>(nameof (CustomScript), value);
      }
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("cacheDynamicResults")]
    [Category("Behavior")]
    public bool CacheDynamicResults
    {
      get => this.GetPropertyValue<bool>(nameof (CacheDynamicResults), false);
      set => this.SetPropertyValue<bool>(nameof (CacheDynamicResults), value);
    }

    protected override bool CheckIfValid(bool throwException)
    {
      if (!string.IsNullOrEmpty(this.CustomScript) || !string.IsNullOrEmpty(this.ServiceMethod))
        return base.CheckIfValid(throwException);
      if (throwException)
        throw new InvalidOperationException("CustomScript or ServiceMethod must be set.");
      return false;
    }
  }
}
