﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ModalPopupExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (DropShadowExtender))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (DragPanelExtender))]
  [TargetControlType(typeof (Control))]
  [ClientScriptResource("AjaxControlToolkit.ModalPopupBehavior", "AjaxControlToolkit.ModalPopup.ModalPopupBehavior.js")]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  [ToolboxBitmap(typeof (ModalPopupExtender), "ModalPopup.ModalPopup.ico")]
  [Designer("AjaxControlToolkit.ModalPopupDesigner, AjaxControlToolkit")]
  public class ModalPopupExtender : DynamicPopulateExtenderControlBase
  {
    private bool? _show;

    [IDReferenceProperty(typeof (WebControl))]
    [RequiredProperty]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string PopupControlID
    {
      get => this.GetPropertyValue<string>(nameof (PopupControlID), "");
      set => this.SetPropertyValue<string>(nameof (PopupControlID), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string BackgroundCssClass
    {
      get => this.GetPropertyValue<string>(nameof (BackgroundCssClass), "");
      set => this.SetPropertyValue<string>(nameof (BackgroundCssClass), value);
    }

    [DefaultValue("")]
    [IDReferenceProperty(typeof (WebControl))]
    [ExtenderControlProperty]
    public string OkControlID
    {
      get => this.GetPropertyValue<string>(nameof (OkControlID), "");
      set => this.SetPropertyValue<string>(nameof (OkControlID), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    [IDReferenceProperty(typeof (WebControl))]
    public string CancelControlID
    {
      get => this.GetPropertyValue<string>(nameof (CancelControlID), "");
      set => this.SetPropertyValue<string>(nameof (CancelControlID), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string OnOkScript
    {
      get => this.GetPropertyValue<string>(nameof (OnOkScript), "");
      set => this.SetPropertyValue<string>(nameof (OnOkScript), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string OnCancelScript
    {
      get => this.GetPropertyValue<string>(nameof (OnCancelScript), "");
      set => this.SetPropertyValue<string>(nameof (OnCancelScript), value);
    }

    [DefaultValue(-1)]
    [ExtenderControlProperty]
    public int X
    {
      get => this.GetPropertyValue<int>(nameof (X), -1);
      set => this.SetPropertyValue<int>(nameof (X), value);
    }

    [DefaultValue(-1)]
    [ExtenderControlProperty]
    public int Y
    {
      get => this.GetPropertyValue<int>(nameof (Y), -1);
      set => this.SetPropertyValue<int>(nameof (Y), value);
    }

    [DefaultValue(false)]
    [Obsolete("The drag feature on modal popup will be automatically turned on if you specify the PopupDragHandleControlID property. Setting the Drag property is a noop")]
    [ExtenderControlProperty]
    public bool Drag
    {
      get => this.GetPropertyValue<bool>("stringDrag", false);
      set => this.SetPropertyValue<bool>("stringDrag", value);
    }

    [ExtenderControlProperty]
    [IDReferenceProperty(typeof (WebControl))]
    [DefaultValue("")]
    public string PopupDragHandleControlID
    {
      get => this.GetPropertyValue<string>(nameof (PopupDragHandleControlID), "");
      set => this.SetPropertyValue<string>(nameof (PopupDragHandleControlID), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    public bool DropShadow
    {
      get => this.GetPropertyValue<bool>("stringDropShadow", false);
      set => this.SetPropertyValue<bool>("stringDropShadow", value);
    }

    [DefaultValue(ModalPopupRepositionMode.RepositionOnWindowResizeAndScroll)]
    [ExtenderControlProperty]
    [ClientPropertyName("repositionMode")]
    public ModalPopupRepositionMode RepositionMode
    {
      get => this.GetPropertyValue<ModalPopupRepositionMode>(nameof (RepositionMode), ModalPopupRepositionMode.RepositionOnWindowResizeAndScroll);
      set => this.SetPropertyValue<ModalPopupRepositionMode>(nameof (RepositionMode), value);
    }

    public void Show() => this._show = new bool?(true);

    public void Hide() => this._show = new bool?(false);

    protected override void OnPreRender(EventArgs e)
    {
      if (this._show.HasValue)
        this.ChangeVisibility(this._show.Value);
      base.OnPreRender(e);
    }

    private void ChangeVisibility(bool show)
    {
      if (this.TargetControl == null)
        throw new ArgumentNullException("TargetControl", "TargetControl property cannot be null");
      string dataItem = show ? nameof (show) : "hide";
      if (ScriptManager.GetCurrent(this.Page).IsInAsyncPostBack)
      {
        ScriptManager.GetCurrent(this.Page).RegisterDataItem(this.TargetControl, dataItem);
      }
      else
      {
        if (!this.Enabled)
          return;
        string script = string.Format((IFormatProvider) CultureInfo.InvariantCulture, ";(function() {{var fn = function() {{AjaxControlToolkit.ModalPopupBehavior.invokeViaServer('{0}', {1}); Sys.Application.remove_load(fn);}};Sys.Application.add_load(fn);}})();", (object) this.BehaviorID, show ? (object) "true" : (object) "false");
        ScriptManager.RegisterStartupScript((Control) this, typeof (ModalPopupExtender), dataItem + this.BehaviorID, script, true);
      }
    }
  }
}
