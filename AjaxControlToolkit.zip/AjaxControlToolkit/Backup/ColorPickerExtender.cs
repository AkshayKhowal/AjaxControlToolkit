﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ColorPickerExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (ThreadingScripts), 2)]
  [RequiredScript(typeof (CommonToolkitScripts), 0)]
  [RequiredScript(typeof (PopupExtender), 1)]
  [ClientCssResource("AjaxControlToolkit.ColorPicker.ColorPicker.css")]
  [TargetControlType(typeof (TextBox))]
  [ClientScriptResource("AjaxControlToolkit.ColorPickerBehavior", "AjaxControlToolkit.ColorPicker.ColorPickerBehavior.js")]
  [ToolboxBitmap(typeof (ColorPickerExtender), "AjaxControlToolkit.ColorPicker.ColorPicker.ico")]
  [Designer(typeof (ColorPickerDesigner))]
  public class ColorPickerExtender : ExtenderControlBase
  {
    [ClientPropertyName("enabled")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public virtual bool EnabledOnClient
    {
      get => this.GetPropertyValue<bool>(nameof (EnabledOnClient), true);
      set => this.SetPropertyValue<bool>(nameof (EnabledOnClient), value);
    }

    [IDReferenceProperty]
    [DefaultValue("")]
    [ElementReference]
    [ExtenderControlProperty]
    [ClientPropertyName("button")]
    public virtual string PopupButtonID
    {
      get => this.GetPropertyValue<string>(nameof (PopupButtonID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (PopupButtonID), value);
    }

    [IDReferenceProperty]
    [ClientPropertyName("sample")]
    [ExtenderControlProperty]
    [ElementReference]
    [DefaultValue("")]
    public virtual string SampleControlID
    {
      get => this.GetPropertyValue<string>(nameof (SampleControlID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (SampleControlID), value);
    }

    [DefaultValue(PositioningMode.BottomLeft)]
    [ExtenderControlProperty]
    [Description("Indicates where you want the color picker displayed relative to the textbox.")]
    [ClientPropertyName("popupPosition")]
    public virtual PositioningMode PopupPosition
    {
      get => this.GetPropertyValue<PositioningMode>(nameof (PopupPosition), PositioningMode.BottomLeft);
      set => this.SetPropertyValue<PositioningMode>(nameof (PopupPosition), value);
    }

    [ClientPropertyName("selectedColor")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string SelectedColor
    {
      get => this.GetPropertyValue<string>(nameof (SelectedColor), string.Empty);
      set => this.SetPropertyValue<string>(nameof (SelectedColor), value);
    }

    [DefaultValue("")]
    [ClientPropertyName("showing")]
    [ExtenderControlEvent]
    public virtual string OnClientShowing
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShowing), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShowing), value);
    }

    [ClientPropertyName("shown")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public virtual string OnClientShown
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShown), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShown), value);
    }

    [ClientPropertyName("hiding")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public virtual string OnClientHiding
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHiding), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHiding), value);
    }

    [ExtenderControlEvent]
    [ClientPropertyName("hidden")]
    [DefaultValue("")]
    public virtual string OnClientHidden
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHidden), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHidden), value);
    }

    [DefaultValue("")]
    [ExtenderControlEvent]
    [ClientPropertyName("colorSelectionChanged")]
    public virtual string OnClientColorSelectionChanged
    {
      get => this.GetPropertyValue<string>(nameof (OnClientColorSelectionChanged), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientColorSelectionChanged), value);
    }
  }
}
