﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MaskedEditValidatorCompatibility.BaseValidator
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Security.Permissions;
using System.Web;
using System.Web.UI;

namespace AjaxControlToolkit.MaskedEditValidatorCompatibility
{
  [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
  [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
  public abstract class BaseValidator : System.Web.UI.WebControls.BaseValidator, IBaseValidatorAccessor, IWebControlAccessor
  {
    private ScriptManager _scriptManager;
    private bool _scriptManagerChecked;

    internal ScriptManager ScriptManager
    {
      get
      {
        if (!this._scriptManagerChecked)
        {
          this._scriptManagerChecked = true;
          Page page = this.Page;
          if (page != null)
            this._scriptManager = ScriptManager.GetCurrent(page);
        }
        return this._scriptManager;
      }
    }

    protected override void AddAttributesToRender(HtmlTextWriter writer)
    {
      if (this.ScriptManager == null || !this.ScriptManager.SupportsPartialRendering)
        base.AddAttributesToRender(writer);
      else
        ValidatorHelper.DoBaseValidatorAddAttributes((System.Web.UI.WebControls.BaseValidator) this, (IBaseValidatorAccessor) this, writer);
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      if (this.ScriptManager == null || !this.ScriptManager.SupportsPartialRendering)
        return;
      ValidatorHelper.DoInitRegistration(this.Page);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      if (this.ScriptManager == null || !this.ScriptManager.SupportsPartialRendering)
        return;
      ValidatorHelper.DoPreRenderRegistration((System.Web.UI.WebControls.BaseValidator) this, (IBaseValidatorAccessor) this);
    }

    protected override void RegisterValidatorDeclaration()
    {
      if (this.ScriptManager == null || !this.ScriptManager.SupportsPartialRendering)
        base.RegisterValidatorDeclaration();
      else
        ValidatorHelper.DoValidatorArrayDeclaration((System.Web.UI.WebControls.BaseValidator) this, typeof (BaseValidator));
    }

    bool IBaseValidatorAccessor.RenderUpLevel => this.RenderUplevel;

    HtmlTextWriterTag IWebControlAccessor.TagKey => this.TagKey;

    void IBaseValidatorAccessor.EnsureID() => this.EnsureID();

    string IBaseValidatorAccessor.GetControlRenderID(string name) => this.GetControlRenderID(name);
  }
}
