﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ExtenderControlPropertyAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [AttributeUsage(AttributeTargets.Property)]
  public sealed class ExtenderControlPropertyAttribute : Attribute
  {
    private static ExtenderControlPropertyAttribute Yes = new ExtenderControlPropertyAttribute(true);
    private static ExtenderControlPropertyAttribute No = new ExtenderControlPropertyAttribute(false);
    private static ExtenderControlPropertyAttribute Default = ExtenderControlPropertyAttribute.No;
    private bool _isScriptProperty;
    private bool _useJsonSerialization;

    public ExtenderControlPropertyAttribute()
      : this(true)
    {
    }

    public ExtenderControlPropertyAttribute(bool isScriptProperty)
      : this(isScriptProperty, false)
    {
    }

    public ExtenderControlPropertyAttribute(bool isScriptProperty, bool useJsonSerialization)
    {
      this._isScriptProperty = isScriptProperty;
      this._useJsonSerialization = useJsonSerialization;
    }

    public bool IsScriptProperty => this._isScriptProperty;

    public bool UseJsonSerialization => this._useJsonSerialization;

    public override bool Equals(object obj)
    {
      if (object.ReferenceEquals(obj, (object) this))
        return true;
      return obj is ExtenderControlPropertyAttribute propertyAttribute && propertyAttribute._isScriptProperty == this._isScriptProperty;
    }

    public override int GetHashCode() => this._isScriptProperty.GetHashCode();

    public override bool IsDefaultAttribute() => this.Equals((object) ExtenderControlPropertyAttribute.Default);
  }
}
