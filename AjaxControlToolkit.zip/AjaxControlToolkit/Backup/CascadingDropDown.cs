﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.CascadingDropDown
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace AjaxControlToolkit
{
  [ClientScriptResource("AjaxControlToolkit.CascadingDropDownBehavior", "AjaxControlToolkit.CascadingDropDown.CascadingDropDownBehavior.js")]
  [TargetControlType(typeof (DropDownList))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ToolboxBitmap(typeof (CascadingDropDown), "CascadingDropDown.CascadingDropDown.ico")]
  [Designer("AjaxControlToolkit.CascadingDropDownDesigner, AjaxControlToolkit")]
  public class CascadingDropDown : ExtenderControlBase
  {
    public CascadingDropDown()
    {
      this.ClientStateValuesLoaded += new EventHandler(this.CascadingDropDown_ClientStateValuesLoaded);
      this.EnableClientState = true;
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    [IDReferenceProperty(typeof (DropDownList))]
    public string ParentControlID
    {
      get => this.GetPropertyValue<string>(nameof (ParentControlID), "");
      set => this.SetPropertyValue<string>(nameof (ParentControlID), value);
    }

    [ExtenderControlProperty]
    [RequiredProperty]
    [DefaultValue("")]
    public string Category
    {
      get => this.GetPropertyValue<string>(nameof (Category), "");
      set => this.SetPropertyValue<string>(nameof (Category), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string PromptText
    {
      get => this.GetPropertyValue<string>(nameof (PromptText), "");
      set => this.SetPropertyValue<string>(nameof (PromptText), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string PromptValue
    {
      get => this.GetPropertyValue<string>(nameof (PromptValue), "");
      set => this.SetPropertyValue<string>(nameof (PromptValue), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string EmptyText
    {
      get => this.GetPropertyValue<string>(nameof (EmptyText), "");
      set => this.SetPropertyValue<string>(nameof (EmptyText), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string EmptyValue
    {
      get => this.GetPropertyValue<string>(nameof (EmptyValue), "");
      set => this.SetPropertyValue<string>(nameof (EmptyValue), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string LoadingText
    {
      get => this.GetPropertyValue<string>(nameof (LoadingText), "");
      set => this.SetPropertyValue<string>(nameof (LoadingText), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    public string SelectedValue
    {
      get => this.ClientState ?? "";
      set => this.ClientState = value;
    }

    [TypeConverter(typeof (ServicePathConverter))]
    [ExtenderControlProperty]
    [UrlProperty]
    public string ServicePath
    {
      get => this.GetPropertyValue<string>(nameof (ServicePath), "");
      set => this.SetPropertyValue<string>(nameof (ServicePath), value);
    }

    private bool ShouldSerializeServicePath() => !string.IsNullOrEmpty(this.ServiceMethod);

    [ExtenderControlProperty]
    [DefaultValue("")]
    [RequiredProperty]
    public string ServiceMethod
    {
      get => this.GetPropertyValue<string>(nameof (ServiceMethod), "");
      set => this.SetPropertyValue<string>(nameof (ServiceMethod), value);
    }

    [ClientPropertyName("contextKey")]
    [ExtenderControlProperty]
    [DefaultValue(null)]
    public string ContextKey
    {
      get => this.GetPropertyValue<string>(nameof (ContextKey), (string) null);
      set
      {
        this.SetPropertyValue<string>(nameof (ContextKey), value);
        this.UseContextKey = true;
      }
    }

    [ClientPropertyName("useContextKey")]
    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool UseContextKey
    {
      get => this.GetPropertyValue<bool>(nameof (UseContextKey), false);
      set => this.SetPropertyValue<bool>(nameof (UseContextKey), value);
    }

    private void CascadingDropDown_ClientStateValuesLoaded(object sender, EventArgs e)
    {
      DropDownList targetControl = (DropDownList) this.TargetControl;
      targetControl.Items.Clear();
      string str1 = ":::";
      string clientState = this.ClientState;
      int length = (clientState ?? "").IndexOf(str1, StringComparison.Ordinal);
      if (-1 == length)
      {
        targetControl.Items.Add(clientState);
      }
      else
      {
        string str2 = clientState.Substring(0, length);
        string text = clientState.Substring(length + str1.Length);
        targetControl.Items.Add(new ListItem(text, str2));
      }
    }

    public static StringDictionary ParseKnownCategoryValuesString(
      string knownCategoryValues)
    {
      if (knownCategoryValues == null)
        throw new ArgumentNullException(nameof (knownCategoryValues));
      StringDictionary categoryValuesString = new StringDictionary();
      if (knownCategoryValues != null)
      {
        string str1 = knownCategoryValues;
        char[] chArray1 = new char[1]{ ';' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ ':' };
          string[] strArray = str2.Split(chArray2);
          if (2 == strArray.Length)
            categoryValuesString.Add(strArray[0].ToLowerInvariant(), strArray[1]);
        }
      }
      return categoryValuesString;
    }

    public static CascadingDropDownNameValue[] QuerySimpleCascadingDropDownDocument(
      XmlDocument document,
      string[] documentHierarchy,
      StringDictionary knownCategoryValuesDictionary,
      string category)
    {
      return CascadingDropDown.QuerySimpleCascadingDropDownDocument(document, documentHierarchy, knownCategoryValuesDictionary, category, new Regex("^[^/'\\*]*$"));
    }

    public static CascadingDropDownNameValue[] QuerySimpleCascadingDropDownDocument(
      XmlDocument document,
      string[] documentHierarchy,
      StringDictionary knownCategoryValuesDictionary,
      string category,
      Regex inputValidationRegex)
    {
      if (document == null)
        throw new ArgumentNullException(nameof (document));
      if (documentHierarchy == null)
        throw new ArgumentNullException(nameof (documentHierarchy));
      if (knownCategoryValuesDictionary == null)
        throw new ArgumentNullException(nameof (knownCategoryValuesDictionary));
      if (category == null)
        throw new ArgumentNullException(nameof (category));
      if (inputValidationRegex == null)
        throw new ArgumentNullException(nameof (inputValidationRegex));
      foreach (string key in (IEnumerable) knownCategoryValuesDictionary.Keys)
      {
        if (!inputValidationRegex.IsMatch(key) || !inputValidationRegex.IsMatch(knownCategoryValuesDictionary[key]))
          throw new ArgumentException("Invalid characters present.", nameof (category));
      }
      if (!inputValidationRegex.IsMatch(category))
        throw new ArgumentException("Invalid characters present.", nameof (category));
      string str1 = "/" + document.DocumentElement.Name;
      foreach (string key in documentHierarchy)
      {
        if (knownCategoryValuesDictionary.ContainsKey(key))
          str1 += string.Format((IFormatProvider) CultureInfo.InvariantCulture, "/{0}[(@name and @value='{1}') or (@name='{1}' and not(@value))]", (object) key, (object) knownCategoryValuesDictionary[key]);
      }
      string xpath = str1 + "/" + category.ToLowerInvariant();
      List<CascadingDropDownNameValue> dropDownNameValueList = new List<CascadingDropDownNameValue>();
      foreach (XmlNode selectNode in document.SelectNodes(xpath))
      {
        string name = selectNode.Attributes.GetNamedItem("name").Value;
        XmlNode namedItem1 = selectNode.Attributes.GetNamedItem("value");
        string str2 = namedItem1 != null ? namedItem1.Value : name;
        XmlNode namedItem2 = selectNode.Attributes.GetNamedItem("default");
        bool defaultValue = namedItem2 != null && bool.Parse(namedItem2.Value);
        dropDownNameValueList.Add(new CascadingDropDownNameValue(name, str2, defaultValue));
      }
      return dropDownNameValueList.ToArray();
    }
  }
}
