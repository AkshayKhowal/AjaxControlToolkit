﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.CalendarExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [Designer("AjaxControlToolkit.CalendarDesigner, AjaxControlToolkit")]
  [RequiredScript(typeof (DateTimeScripts), 1)]
  [RequiredScript(typeof (PopupExtender), 2)]
  [RequiredScript(typeof (AnimationScripts), 3)]
  [RequiredScript(typeof (ThreadingScripts), 4)]
  [TargetControlType(typeof (TextBox))]
  [ClientCssResource("AjaxControlToolkit.Calendar.Calendar.css")]
  [RequiredScript(typeof (CommonToolkitScripts), 0)]
  [ClientScriptResource("AjaxControlToolkit.CalendarBehavior", "AjaxControlToolkit.Calendar.CalendarBehavior.js")]
  [ToolboxBitmap(typeof (CalendarExtender), "Calendar.Calendar.ico")]
  public class CalendarExtender : ExtenderControlBase
  {
    [ExtenderControlProperty]
    [DefaultValue("")]
    [ClientPropertyName("cssClass")]
    public virtual string CssClass
    {
      get => this.GetPropertyValue<string>(nameof (CssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (CssClass), value);
    }

    [ClientPropertyName("format")]
    [DefaultValue("d")]
    [ExtenderControlProperty]
    public virtual string Format
    {
      get => this.GetPropertyValue<string>(nameof (Format), "d");
      set => this.SetPropertyValue<string>(nameof (Format), value);
    }

    [DefaultValue("MMMM d, yyyy")]
    [ClientPropertyName("todaysDateFormat")]
    [ExtenderControlProperty]
    public virtual string TodaysDateFormat
    {
      get => this.GetPropertyValue<string>(nameof (TodaysDateFormat), "MMMM d, yyyy");
      set => this.SetPropertyValue<string>(nameof (TodaysDateFormat), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("MMMM, yyyy")]
    [ClientPropertyName("daysModeTitleFormat")]
    public virtual string DaysModeTitleFormat
    {
      get => this.GetPropertyValue<string>(nameof (DaysModeTitleFormat), "MMMM, yyyy");
      set => this.SetPropertyValue<string>(nameof (DaysModeTitleFormat), value);
    }

    [ClientPropertyName("clearTime")]
    [DefaultValue(false)]
    [ExtenderControlProperty]
    public virtual bool ClearTime
    {
      get => this.GetPropertyValue<bool>(nameof (ClearTime), false);
      set => this.SetPropertyValue<bool>(nameof (ClearTime), value);
    }

    [ClientPropertyName("enabled")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public virtual bool EnabledOnClient
    {
      get => this.GetPropertyValue<bool>(nameof (EnabledOnClient), true);
      set => this.SetPropertyValue<bool>(nameof (EnabledOnClient), value);
    }

    [ClientPropertyName("animated")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public virtual bool Animated
    {
      get => this.GetPropertyValue<bool>(nameof (Animated), true);
      set => this.SetPropertyValue<bool>(nameof (Animated), value);
    }

    [DefaultValue(FirstDayOfWeek.Default)]
    [ClientPropertyName("firstDayOfWeek")]
    [ExtenderControlProperty]
    public virtual FirstDayOfWeek FirstDayOfWeek
    {
      get => this.GetPropertyValue<FirstDayOfWeek>(nameof (FirstDayOfWeek), FirstDayOfWeek.Default);
      set => this.SetPropertyValue<FirstDayOfWeek>(nameof (FirstDayOfWeek), value);
    }

    [DefaultValue("")]
    [ElementReference]
    [IDReferenceProperty]
    [ExtenderControlProperty]
    [ClientPropertyName("button")]
    public virtual string PopupButtonID
    {
      get => this.GetPropertyValue<string>(nameof (PopupButtonID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (PopupButtonID), value);
    }

    [Description("Indicates where you want the calendar displayed, bottom or top of the textbox.")]
    [DefaultValue(CalendarPosition.BottomLeft)]
    [ClientPropertyName("popupPosition")]
    [ExtenderControlProperty]
    public virtual CalendarPosition PopupPosition
    {
      get => this.GetPropertyValue<CalendarPosition>(nameof (PopupPosition), CalendarPosition.BottomLeft);
      set => this.SetPropertyValue<CalendarPosition>(nameof (PopupPosition), value);
    }

    [ClientPropertyName("selectedDate")]
    [DefaultValue(null)]
    [ExtenderControlProperty]
    public DateTime? SelectedDate
    {
      get => this.GetPropertyValue<DateTime?>(nameof (SelectedDate), new DateTime?());
      set => this.SetPropertyValue<DateTime?>(nameof (SelectedDate), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(CalendarDefaultView.Days)]
    [Description("Default view of the calendar when it first pops up.")]
    [ClientPropertyName("defaultView")]
    public virtual CalendarDefaultView DefaultView
    {
      get => this.GetPropertyValue<CalendarDefaultView>(nameof (DefaultView), CalendarDefaultView.Days);
      set => this.SetPropertyValue<CalendarDefaultView>(nameof (DefaultView), value);
    }

    [ClientPropertyName("showing")]
    [ExtenderControlEvent]
    [DefaultValue("")]
    public virtual string OnClientShowing
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShowing), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShowing), value);
    }

    [ExtenderControlEvent]
    [ClientPropertyName("shown")]
    [DefaultValue("")]
    public virtual string OnClientShown
    {
      get => this.GetPropertyValue<string>(nameof (OnClientShown), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientShown), value);
    }

    [ClientPropertyName("hiding")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    public virtual string OnClientHiding
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHiding), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHiding), value);
    }

    [DefaultValue("")]
    [ClientPropertyName("hidden")]
    [ExtenderControlEvent]
    public virtual string OnClientHidden
    {
      get => this.GetPropertyValue<string>(nameof (OnClientHidden), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientHidden), value);
    }

    [ExtenderControlEvent]
    [ClientPropertyName("dateSelectionChanged")]
    [DefaultValue("")]
    public virtual string OnClientDateSelectionChanged
    {
      get => this.GetPropertyValue<string>(nameof (OnClientDateSelectionChanged), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientDateSelectionChanged), value);
    }
  }
}
