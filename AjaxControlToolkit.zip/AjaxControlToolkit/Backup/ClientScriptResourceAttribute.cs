﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ClientScriptResourceAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
  public sealed class ClientScriptResourceAttribute : Attribute
  {
    private string _resourcePath;
    private string _componentType;
    private int _loadOrder;

    public string ComponentType
    {
      get => this._componentType;
      set => this._componentType = value;
    }

    public int LoadOrder
    {
      get => this._loadOrder;
      set => this._loadOrder = value;
    }

    public string ResourcePath
    {
      get => this._resourcePath;
      set => this._resourcePath = value;
    }

    public ClientScriptResourceAttribute()
    {
    }

    public ClientScriptResourceAttribute(string componentType) => this._componentType = componentType;

    public ClientScriptResourceAttribute(string componentType, Type baseType, string resourceName)
    {
      if (baseType == null)
        throw new ArgumentNullException(nameof (baseType));
      if (resourceName == null)
        throw new ArgumentNullException(nameof (resourceName));
      string str = baseType.FullName;
      int length = str.LastIndexOf('.');
      if (length != -1)
        str = str.Substring(0, length);
      this.ResourcePath = str + "." + resourceName;
      this._componentType = componentType;
    }

    public ClientScriptResourceAttribute(string componentType, string fullResourceName)
      : this(componentType)
    {
      this.ResourcePath = fullResourceName != null ? fullResourceName : throw new ArgumentNullException(nameof (fullResourceName));
    }

    public override bool IsDefaultAttribute() => this.ComponentType == null && this.ResourcePath == null;
  }
}
