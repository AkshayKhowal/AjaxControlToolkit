﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DropDownExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [RequiredScript(typeof (AnimationExtender))]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (PopupExtender))]
  [RequiredScript(typeof (HoverExtender))]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  [TargetControlType(typeof (Control))]
  [ClientScriptResource("AjaxControlToolkit.DropDownBehavior", "AjaxControlToolkit.DropDown.DropDownBehavior.js")]
  [Designer("AjaxControlToolkit.DropDownDesigner, AjaxControlToolkit")]
  [ClientCssResource("AjaxControlToolkit.DropDown.DropDown.css")]
  [ToolboxBitmap(typeof (DropDownExtender), "DropDown.DropDown.ico")]
  public class DropDownExtender : DynamicPopulateExtenderControlBase
  {
    private Animation _onShow;
    private Animation _onHide;

    [ClientPropertyName("dropDownControl")]
    [DefaultValue("")]
    [IDReferenceProperty(typeof (Control))]
    [ExtenderControlProperty]
    [ElementReference]
    public string DropDownControlID
    {
      get => (string) (this.ViewState[nameof (DropDownControlID)] ?? (object) string.Empty);
      set => this.ViewState[nameof (DropDownControlID)] = (object) value;
    }

    [DefaultValue(typeof (Color), "")]
    [ClientPropertyName("highlightBorderColor")]
    [ExtenderControlProperty]
    public Color HighlightBorderColor
    {
      get => (Color) (this.ViewState[nameof (HighlightBorderColor)] ?? (object) Color.Empty);
      set => this.ViewState[nameof (HighlightBorderColor)] = (object) value;
    }

    [DefaultValue(typeof (Color), "")]
    [ClientPropertyName("highlightBackgroundColor")]
    [ExtenderControlProperty]
    public Color HighlightBackColor
    {
      get => (Color) (this.ViewState[nameof (HighlightBackColor)] ?? (object) Color.Empty);
      set => this.ViewState[nameof (HighlightBackColor)] = (object) value;
    }

    [ExtenderControlProperty]
    [DefaultValue(typeof (Color), "")]
    [ClientPropertyName("dropArrowBackgroundColor")]
    public Color DropArrowBackColor
    {
      get => (Color) (this.ViewState[nameof (DropArrowBackColor)] ?? (object) Color.Empty);
      set => this.ViewState[nameof (DropArrowBackColor)] = (object) value;
    }

    [ExtenderControlProperty]
    [UrlProperty]
    [DefaultValue("")]
    [ClientPropertyName("dropArrowImageUrl")]
    public string DropArrowImageUrl
    {
      get => (string) (this.ViewState[nameof (DropArrowImageUrl)] ?? (object) string.Empty);
      set => this.ViewState[nameof (DropArrowImageUrl)] = (object) value;
    }

    [ClientPropertyName("dropArrowWidth")]
    [ExtenderControlProperty]
    [DefaultValue(typeof (Unit), "")]
    public Unit DropArrowWidth
    {
      get => (Unit) (this.ViewState[nameof (DropArrowWidth)] ?? (object) Unit.Empty);
      set => this.ViewState[nameof (DropArrowWidth)] = (object) value;
    }

    [ExtenderControlEvent]
    [ClientPropertyName("popup")]
    [DefaultValue("")]
    [Category("Behavior")]
    public string OnClientPopup
    {
      get => (string) (this.ViewState[nameof (OnClientPopup)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientPopup)] = (object) value;
    }

    [ExtenderControlEvent]
    [DefaultValue("")]
    [ClientPropertyName("populating")]
    [Category("Behavior")]
    public string OnClientPopulating
    {
      get => (string) (this.ViewState[nameof (OnClientPopulating)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientPopulating)] = (object) value;
    }

    [DefaultValue("")]
    [ClientPropertyName("populated")]
    [Category("Behavior")]
    [ExtenderControlEvent]
    public string OnClientPopulated
    {
      get => (string) (this.ViewState[nameof (OnClientPopulated)] ?? (object) string.Empty);
      set => this.ViewState[nameof (OnClientPopulated)] = (object) value;
    }

    [ExtenderControlProperty]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [ClientPropertyName("onShow")]
    [Browsable(false)]
    [DefaultValue(null)]
    public Animation OnShow
    {
      get => this.GetAnimation(ref this._onShow, nameof (OnShow));
      set => this.SetAnimation(ref this._onShow, nameof (OnShow), value);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [DefaultValue(null)]
    [Browsable(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("onHide")]
    public Animation OnHide
    {
      get => this.GetAnimation(ref this._onHide, nameof (OnHide));
      set => this.SetAnimation(ref this._onHide, nameof (OnHide), value);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      if ((!string.IsNullOrEmpty(this.DynamicContextKey) || !string.IsNullOrEmpty(this.DynamicServicePath) || !string.IsNullOrEmpty(this.DynamicServiceMethod)) && string.IsNullOrEmpty(this.DynamicControlID))
        this.DynamicControlID = this.DropDownControlID;
      this.ResolveControlIDs(this._onShow);
      this.ResolveControlIDs(this._onHide);
    }
  }
}
