﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MultiHandleSliderExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [TargetControlType(typeof (TextBox))]
  [ClientScriptResource("AjaxControlToolkit.MultiHandleSliderBehavior", "AjaxControlToolkit.MultiHandleSlider.MultiHandleSliderBehavior.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [ClientCssResource("AjaxControlToolkit.MultiHandleSlider.MultiHandleSlider.css")]
  [RequiredScript(typeof (AnimationScripts))]
  [RequiredScript(typeof (TimerScript))]
  [ToolboxBitmap(typeof (MultiHandleSliderExtender), "MultiHandleSlider.MultiHandleSlider.ico")]
  [RequiredScript(typeof (DragDropScripts))]
  [Description("A multi-handled slider allowing selection of multiple point values on a graphical rail.")]
  [Designer(typeof (MultiHandleSliderDesigner))]
  public class MultiHandleSliderExtender : ExtenderControlBase
  {
    [DefaultValue("0")]
    [ExtenderControlProperty]
    [Description("The lowest value on the slider.")]
    [ClientPropertyName("minimum")]
    public int Minimum
    {
      get => this.GetPropertyValue<int>(nameof (Minimum), 0);
      set => this.SetPropertyValue<int>(nameof (Minimum), value);
    }

    [Description("The highest value on the slider.")]
    [ExtenderControlProperty]
    [DefaultValue("100")]
    [ClientPropertyName("maximum")]
    public int Maximum
    {
      get => this.GetPropertyValue<int>(nameof (Maximum), 100);
      set => this.SetPropertyValue<int>(nameof (Maximum), value);
    }

    [DefaultValue(150)]
    [ClientPropertyName("length")]
    [ExtenderControlProperty]
    [Description("The length of the slider rail in pixels.")]
    public int Length
    {
      get => this.GetPropertyValue<int>(nameof (Length), 150);
      set => this.SetPropertyValue<int>(nameof (Length), value);
    }

    [ClientPropertyName("steps")]
    [DefaultValue(0)]
    [Description("Determines number of discrete locations on the slider; otherwise, the slider is continous.")]
    [ExtenderControlProperty]
    public int Steps
    {
      get => this.GetPropertyValue<int>(nameof (Steps), 0);
      set => this.SetPropertyValue<int>(nameof (Steps), value);
    }

    [Description("Determines if the slider will show an inner selected range rail; otherwise, it will display as a uniform rail.")]
    [ExtenderControlProperty]
    [DefaultValue(false)]
    [ClientPropertyName("showInnerRail")]
    public bool ShowInnerRail
    {
      get => this.GetPropertyValue<bool>(nameof (ShowInnerRail), false);
      set => this.SetPropertyValue<bool>(nameof (ShowInnerRail), value);
    }

    [Description("Determines how the inner rail style is handled.")]
    [ClientPropertyName("innerRailStyle")]
    [ExtenderControlProperty]
    [DefaultValue(MultiHandleInnerRailStyle.AsIs)]
    public MultiHandleInnerRailStyle InnerRailStyle
    {
      get => this.GetPropertyValue<MultiHandleInnerRailStyle>(nameof (InnerRailStyle), MultiHandleInnerRailStyle.AsIs);
      set => this.SetPropertyValue<MultiHandleInnerRailStyle>(nameof (InnerRailStyle), value);
    }

    [ClientPropertyName("orientation")]
    [ExtenderControlProperty]
    [Description("Determines if the slider's orientation is horizontal or vertical.")]
    [DefaultValue(SliderOrientation.Horizontal)]
    public SliderOrientation Orientation
    {
      get => this.GetPropertyValue<SliderOrientation>(nameof (Orientation), SliderOrientation.Horizontal);
      set => this.SetPropertyValue<SliderOrientation>(nameof (Orientation), value);
    }

    [Description("Determines if changes to the slider's values are raised as an event when dragging; otherwise, they are raised on drag end.")]
    [ClientPropertyName("raiseChangeOnlyOnMouseUp")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    public bool RaiseChangeOnlyOnMouseUp
    {
      get => this.GetPropertyValue<bool>(nameof (RaiseChangeOnlyOnMouseUp), true);
      set => this.SetPropertyValue<bool>(nameof (RaiseChangeOnlyOnMouseUp), value);
    }

    [ExtenderControlProperty]
    [Description("Determines if the inner rail range can be dragged as a whole, moving both handles defining it.")]
    [ClientPropertyName("enableInnerRangeDrag")]
    [DefaultValue(false)]
    public bool EnableInnerRangeDrag
    {
      get => this.GetPropertyValue<bool>(nameof (EnableInnerRangeDrag), false);
      set => this.SetPropertyValue<bool>(nameof (EnableInnerRangeDrag), value);
    }

    [Description("Determines if clicking on the rail will detect and move the closest handle.")]
    [ClientPropertyName("enableRailClick")]
    [ExtenderControlProperty]
    [DefaultValue(true)]
    public bool EnableRailClick
    {
      get => this.GetPropertyValue<bool>(nameof (EnableRailClick), true);
      set => this.SetPropertyValue<bool>(nameof (EnableRailClick), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("isReadOnly")]
    [DefaultValue(false)]
    [Description("Determines if the slider and its values can be manipulated.")]
    public bool IsReadOnly
    {
      get => this.GetPropertyValue<bool>(nameof (IsReadOnly), false);
      set => this.SetPropertyValue<bool>(nameof (IsReadOnly), value);
    }

    [Description("Determines if the slider will respond to arrow keys when it has focus.")]
    [ExtenderControlProperty]
    [DefaultValue(true)]
    [ClientPropertyName("enableKeyboard")]
    public bool EnableKeyboard
    {
      get => this.GetPropertyValue<bool>(nameof (EnableKeyboard), true);
      set => this.SetPropertyValue<bool>(nameof (EnableKeyboard), value);
    }

    [ClientPropertyName("enableMouseWheel")]
    [DefaultValue(true)]
    [ExtenderControlProperty]
    [Description("Determines if the slider will respond to the mouse wheel when it has focus.")]
    public bool EnableMouseWheel
    {
      get => this.GetPropertyValue<bool>(nameof (EnableMouseWheel), true);
      set => this.SetPropertyValue<bool>(nameof (EnableMouseWheel), value);
    }

    [ClientPropertyName("increment")]
    [DefaultValue(1)]
    [Description("Determines the number of points to increment or decrement the slider using the keyboard or mousewheel; ignored if steps is used.")]
    [ExtenderControlProperty]
    public int Increment
    {
      get => this.GetPropertyValue<int>(nameof (Increment), 1);
      set => this.SetPropertyValue<int>(nameof (Increment), value);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [ExtenderControlProperty(true, true)]
    [ClientPropertyName("multiHandleSliderTargets")]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    [Description("The list of controls used to bind slider handle values. These should be Label or TextBox controls.")]
    [NotifyParentProperty(true)]
    public Collection<MultiHandleSliderTarget> MultiHandleSliderTargets
    {
      get => this.GetPropertyValue<Collection<MultiHandleSliderTarget>>(nameof (MultiHandleSliderTargets), (Collection<MultiHandleSliderTarget>) null);
      set => this.SetPropertyValue<Collection<MultiHandleSliderTarget>>(nameof (MultiHandleSliderTargets), value);
    }

    [Description("Determines if the slider handles display an animation effect when changing position.")]
    [ClientPropertyName("enableHandleAnimation")]
    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool EnableHandleAnimation
    {
      get => this.GetPropertyValue<bool>(nameof (EnableHandleAnimation), false);
      set => this.SetPropertyValue<bool>(nameof (EnableHandleAnimation), value);
    }

    [DefaultValue(false)]
    [Description("Determines if the slider handles will show a style effect when they are hovered over.")]
    [ClientPropertyName("showHandleHoverStyle")]
    [ExtenderControlProperty]
    public bool ShowHandleHoverStyle
    {
      get => this.GetPropertyValue<bool>(nameof (ShowHandleHoverStyle), false);
      set => this.SetPropertyValue<bool>(nameof (ShowHandleHoverStyle), value);
    }

    [DefaultValue(false)]
    [ClientPropertyName("showHandleDragStyle")]
    [Description("Determines if the slider handles will show a style effect when they are being dragged.")]
    [ExtenderControlProperty]
    public bool ShowHandleDragStyle
    {
      get => this.GetPropertyValue<bool>(nameof (ShowHandleDragStyle), false);
      set => this.SetPropertyValue<bool>(nameof (ShowHandleDragStyle), value);
    }

    [Description("Determines the total duration of the animation effect, in seconds.")]
    [DefaultValue(0.02f)]
    [ClientPropertyName("handleAnimationDuration")]
    [ExtenderControlProperty]
    public float HandleAnimationDuration
    {
      get => this.GetPropertyValue<float>(nameof (HandleAnimationDuration), 0.1f);
      set => this.SetPropertyValue<float>(nameof (HandleAnimationDuration), value);
    }

    [DefaultValue("")]
    [ClientPropertyName("tooltipText")]
    [Description("Determines the text to display as the tooltip; {0} denotes the current handle's value in the format string.")]
    [ExtenderControlProperty]
    public string TooltipText
    {
      get => this.GetPropertyValue<string>(nameof (TooltipText), string.Empty);
      set => this.SetPropertyValue<string>(nameof (TooltipText), value);
    }

    [ClientPropertyName("cssClass")]
    [Description("The master style to apply to slider graphical elements.")]
    [ExtenderControlProperty]
    [DefaultValue("")]
    public string CssClass
    {
      get => this.GetPropertyValue<string>(nameof (CssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (CssClass), value);
    }

    [DefaultValue("")]
    [Description("The event raised when the slider is completely loaded on the page.")]
    [ExtenderControlEvent]
    [ClientPropertyName("load")]
    public string OnClientLoad
    {
      get => this.GetPropertyValue<string>(nameof (OnClientLoad), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientLoad), value);
    }

    [Description("The event raised when the user initiates a drag operation on the slider.")]
    [ClientPropertyName("dragStart")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    public string OnClientDragStart
    {
      get => this.GetPropertyValue<string>(nameof (OnClientDragStart), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientDragStart), value);
    }

    [ClientPropertyName("drag")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    [Description("The event raised when the user drags the slider.")]
    public string OnClientDrag
    {
      get => this.GetPropertyValue<string>(nameof (OnClientDrag), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientDrag), value);
    }

    [DefaultValue("")]
    [ExtenderControlEvent]
    [Description("The event raised when the user drops the slider.")]
    [ClientPropertyName("dragEnd")]
    public string OnClientDragEnd
    {
      get => this.GetPropertyValue<string>(nameof (OnClientDragEnd), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientDragEnd), value);
    }

    [Description("The event raised when the slider changes its state.")]
    [DefaultValue("")]
    [ExtenderControlEvent]
    [ClientPropertyName("valueChanged")]
    public string OnClientValueChanged
    {
      get => this.GetPropertyValue<string>(nameof (OnClientValueChanged), string.Empty);
      set => this.SetPropertyValue<string>(nameof (OnClientValueChanged), value);
    }

    public MultiHandleSliderExtender() => this.EnableClientState = true;

    [IDReferenceProperty(typeof (WebControl))]
    [ClientPropertyName("boundControlID")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    public string BoundControlID
    {
      get => this.GetPropertyValue<string>(nameof (BoundControlID), string.Empty);
      set => this.SetPropertyValue<string>(nameof (BoundControlID), value);
    }

    [ExtenderControlProperty]
    [ClientPropertyName("decimals")]
    [DefaultValue(0)]
    public int Decimals
    {
      get => this.GetPropertyValue<int>(nameof (Decimals), 0);
      set => this.SetPropertyValue<int>(nameof (Decimals), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("")]
    [ClientPropertyName("handleCssClass")]
    public string HandleCssClass
    {
      get => this.GetPropertyValue<string>(nameof (HandleCssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (HandleCssClass), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    [ClientPropertyName("railCssClass")]
    public string RailCssClass
    {
      get => this.GetPropertyValue<string>(nameof (RailCssClass), string.Empty);
      set => this.SetPropertyValue<string>(nameof (RailCssClass), value);
    }

    [DefaultValue("")]
    [UrlProperty]
    [Editor("System.Web.UI.Design.ImageUrlEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof (UITypeEditor))]
    [ClientPropertyName("handleImageUrl")]
    [ExtenderControlProperty]
    public string HandleImageUrl
    {
      get => this.GetPropertyValue<string>(nameof (HandleImageUrl), "");
      set => this.SetPropertyValue<string>(nameof (HandleImageUrl), value);
    }
  }
}
