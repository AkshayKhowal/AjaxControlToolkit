﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ClientCssResourceAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
  public sealed class ClientCssResourceAttribute : Attribute
  {
    private string _resourcePath;
    private int _loadOrder;

    public ClientCssResourceAttribute(Type baseType, string resourceName)
    {
      if (baseType == null)
        throw new ArgumentNullException(nameof (baseType));
      if (resourceName == null)
        throw new ArgumentNullException(nameof (resourceName));
      string str = baseType.FullName;
      int length = str.LastIndexOf('.');
      if (length != -1)
        str = str.Substring(0, length);
      this._resourcePath = str + (object) '.' + resourceName;
    }

    public ClientCssResourceAttribute(string fullResourceName) => this._resourcePath = fullResourceName != null ? fullResourceName : throw new ArgumentNullException(nameof (fullResourceName));

    public string ResourcePath => this._resourcePath;

    public int LoadOrder
    {
      get => this._loadOrder;
      set => this._loadOrder = value;
    }
  }
}
