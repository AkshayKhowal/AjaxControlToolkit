﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.DesignerWithMapPath
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.IO;
using System.Web.UI.Design;

namespace AjaxControlToolkit
{
  public class DesignerWithMapPath : ControlDesigner
  {
    public string MapPath(string originalPath)
    {
      string str = (string) null;
      ISite site = this.Component.Site;
      if (site != null)
      {
        IWebApplication service = (IWebApplication) site.GetService(typeof (IWebApplication));
        if (service != null)
        {
          string path2_1 = originalPath.Replace("/", "\\");
          bool flag = false;
          while (path2_1.Length > 0 && (path2_1.Substring(0, 1) == "\\" || path2_1.Substring(0, 1) == "~"))
          {
            flag = true;
            path2_1 = path2_1.Substring(1);
            if (path2_1.Length == 0)
              break;
          }
          string physicalPath = service.RootProjectItem.PhysicalPath;
          string relativeUrl;
          if (flag)
          {
            relativeUrl = Path.Combine(physicalPath, path2_1);
          }
          else
          {
            string path2_2 = Path.GetDirectoryName(this.RootDesigner.DocumentUrl).Replace("/", "\\");
            while (path2_2.Length > 0 && (path2_2.Substring(0, 1) == "\\" || path2_2.Substring(0, 1) == "~"))
            {
              path2_2 = path2_2.Substring(1);
              if (path2_2.Length == 0)
                break;
            }
            relativeUrl = Path.Combine(Path.Combine(physicalPath, path2_2), path2_1);
          }
          str = this.RootDesigner.ResolveUrl(relativeUrl).Substring(8).Replace("/", "\\");
          if (str.IndexOf(physicalPath, StringComparison.OrdinalIgnoreCase) != 0)
            str = (string) null;
        }
      }
      return str;
    }
  }
}
