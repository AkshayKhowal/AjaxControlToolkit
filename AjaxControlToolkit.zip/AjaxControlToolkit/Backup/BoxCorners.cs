﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.BoxCorners
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  [Flags]
  public enum BoxCorners
  {
    None = 0,
    TopLeft = 1,
    TopRight = 2,
    BottomRight = 4,
    BottomLeft = 8,
    Top = TopRight | TopLeft, // 0x00000003
    Right = BottomRight | TopRight, // 0x00000006
    Bottom = BottomLeft | BottomRight, // 0x0000000C
    Left = BottomLeft | TopLeft, // 0x00000009
    All = Left | Right, // 0x0000000F
  }
}
