﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.MaskedEditExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [Designer("AjaxControlToolkit.MaskedEditDesigner, AjaxControlToolkit")]
  [ToolboxBitmap(typeof (MaskedEditExtender), "MaskedEdit.MaskedEdit.ico")]
  [ClientScriptResource("AjaxControlToolkit.MaskedEditBehavior", "AjaxControlToolkit.MaskedEdit.MaskedEditBehavior.js")]
  [RequiredScript(typeof (CommonToolkitScripts))]
  [RequiredScript(typeof (TimerScript))]
  [ClientScriptResource("AjaxControlToolkit.MaskedEditBehavior", "AjaxControlToolkit.MaskedEdit.MaskedEditValidator.js")]
  [TargetControlType(typeof (TextBox))]
  public class MaskedEditExtender : ExtenderControlBase
  {
    public MaskedEditExtender() => this.EnableClientState = true;

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      switch (this.MaskType)
      {
        case MaskedEditType.None:
          this.AcceptAMPM = false;
          this.AcceptNegative = MaskedEditShowSymbol.None;
          this.DisplayMoney = MaskedEditShowSymbol.None;
          this.InputDirection = MaskedEditInputDirection.LeftToRight;
          break;
        case MaskedEditType.Date:
          this.AcceptAMPM = false;
          this.AcceptNegative = MaskedEditShowSymbol.None;
          this.DisplayMoney = MaskedEditShowSymbol.None;
          this.InputDirection = MaskedEditInputDirection.LeftToRight;
          break;
        case MaskedEditType.Number:
          this.AcceptAMPM = false;
          break;
        case MaskedEditType.Time:
          this.AcceptNegative = MaskedEditShowSymbol.None;
          this.DisplayMoney = MaskedEditShowSymbol.None;
          this.InputDirection = MaskedEditInputDirection.LeftToRight;
          break;
        case MaskedEditType.DateTime:
          this.AcceptNegative = MaskedEditShowSymbol.None;
          this.DisplayMoney = MaskedEditShowSymbol.None;
          this.InputDirection = MaskedEditInputDirection.LeftToRight;
          break;
      }
      if (!string.IsNullOrEmpty(this.CultureName))
        return;
      this.CultureName = "";
    }

    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      ((TextBox) this.FindControl(this.TargetControlID)).MaxLength = 0;
      this.ClientState = string.Compare(this.Page.Form.DefaultFocus, this.TargetControlID, StringComparison.OrdinalIgnoreCase) == 0 ? "Focused" : (string) null;
    }

    [DefaultValue("")]
    [RequiredProperty]
    [ExtenderControlProperty]
    public string Mask
    {
      get => this.GetPropertyValue<string>(nameof (Mask), "");
      set
      {
        if (!this.validateMaskType())
          throw new ArgumentException("Validate Type and/or Mask is invalid!");
        this.SetPropertyValue<string>(nameof (Mask), value);
      }
    }

    [ExtenderControlProperty]
    [DefaultValue("Your browser security settings don't permit the automatic execution of paste operations. Please use the keyboard shortcut Ctrl+V instead.")]
    public string ClipboardText
    {
      get => this.GetPropertyValue<string>(nameof (ClipboardText), "Your browser security settings don't permit the automatic execution of paste operations. Please use the keyboard shortcut Ctrl+V instead.");
      set => this.SetPropertyValue<string>(nameof (ClipboardText), value);
    }

    [DefaultValue(MaskedEditType.None)]
    [ExtenderControlProperty]
    [RefreshProperties(RefreshProperties.All)]
    public MaskedEditType MaskType
    {
      get => this.GetPropertyValue<MaskedEditType>(nameof (MaskType), MaskedEditType.None);
      set
      {
        this.SetPropertyValue<MaskedEditType>(nameof (MaskType), value);
        switch (value)
        {
          case MaskedEditType.None:
            this.AcceptAMPM = false;
            this.AcceptNegative = MaskedEditShowSymbol.None;
            this.DisplayMoney = MaskedEditShowSymbol.None;
            this.InputDirection = MaskedEditInputDirection.LeftToRight;
            break;
          case MaskedEditType.Date:
            this.AcceptAMPM = false;
            this.AcceptNegative = MaskedEditShowSymbol.None;
            this.DisplayMoney = MaskedEditShowSymbol.None;
            this.InputDirection = MaskedEditInputDirection.LeftToRight;
            break;
          case MaskedEditType.Number:
            this.AcceptAMPM = false;
            break;
          case MaskedEditType.Time:
            this.AcceptNegative = MaskedEditShowSymbol.None;
            this.DisplayMoney = MaskedEditShowSymbol.None;
            this.InputDirection = MaskedEditInputDirection.LeftToRight;
            break;
          case MaskedEditType.DateTime:
            this.AcceptNegative = MaskedEditShowSymbol.None;
            this.DisplayMoney = MaskedEditShowSymbol.None;
            this.InputDirection = MaskedEditInputDirection.LeftToRight;
            break;
        }
      }
    }

    [ExtenderControlProperty]
    [DefaultValue(true)]
    public bool MessageValidatorTip
    {
      get => this.GetPropertyValue<bool>(nameof (MessageValidatorTip), true);
      set => this.SetPropertyValue<bool>(nameof (MessageValidatorTip), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool ErrorTooltipEnabled
    {
      get => this.GetPropertyValue<bool>(nameof (ErrorTooltipEnabled), false);
      set => this.SetPropertyValue<bool>(nameof (ErrorTooltipEnabled), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string ErrorTooltipCssClass
    {
      get => this.GetPropertyValue<string>(nameof (ErrorTooltipCssClass), "");
      set => this.SetPropertyValue<string>(nameof (ErrorTooltipCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(true)]
    public bool ClipboardEnabled
    {
      get => this.GetPropertyValue<bool>(nameof (ClipboardEnabled), true);
      set => this.SetPropertyValue<bool>(nameof (ClipboardEnabled), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(true)]
    public bool AutoComplete
    {
      get => this.GetPropertyValue<bool>(nameof (AutoComplete), true);
      set => this.SetPropertyValue<bool>(nameof (AutoComplete), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool ClearTextOnInvalid
    {
      get => this.GetPropertyValue<bool>(nameof (ClearTextOnInvalid), false);
      set => this.SetPropertyValue<bool>(nameof (ClearTextOnInvalid), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string AutoCompleteValue
    {
      get => this.GetPropertyValue<string>(nameof (AutoCompleteValue), "");
      set => this.SetPropertyValue<string>(nameof (AutoCompleteValue), value);
    }

    [DefaultValue("")]
    [ExtenderControlProperty]
    public string Filtered
    {
      get => this.GetPropertyValue<string>(nameof (Filtered), "");
      set => this.SetPropertyValue<string>(nameof (Filtered), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(MaskedEditInputDirection.LeftToRight)]
    public MaskedEditInputDirection InputDirection
    {
      get => this.GetPropertyValue<MaskedEditInputDirection>(nameof (InputDirection), MaskedEditInputDirection.LeftToRight);
      set => this.SetPropertyValue<MaskedEditInputDirection>(nameof (InputDirection), value);
    }

    [DefaultValue("_")]
    [ExtenderControlProperty]
    public string PromptCharacter
    {
      get => this.GetPropertyValue<string>("PromptChar", "_");
      set => this.SetPropertyValue<string>("PromptChar", value);
    }

    [DefaultValue("MaskedEditFocus")]
    [ExtenderControlProperty]
    public string OnFocusCssClass
    {
      get => this.GetPropertyValue<string>(nameof (OnFocusCssClass), "MaskedEditFocus");
      set => this.SetPropertyValue<string>(nameof (OnFocusCssClass), value);
    }

    [DefaultValue("MaskedEditError")]
    [ExtenderControlProperty]
    public string OnInvalidCssClass
    {
      get => this.GetPropertyValue<string>(nameof (OnInvalidCssClass), "MaskedEditError");
      set => this.SetPropertyValue<string>(nameof (OnInvalidCssClass), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(MaskedEditUserDateFormat.None)]
    public MaskedEditUserDateFormat UserDateFormat
    {
      get => this.GetPropertyValue<MaskedEditUserDateFormat>(nameof (UserDateFormat), MaskedEditUserDateFormat.None);
      set => this.SetPropertyValue<MaskedEditUserDateFormat>(nameof (UserDateFormat), value);
    }

    [DefaultValue(MaskedEditUserTimeFormat.None)]
    [ExtenderControlProperty]
    public MaskedEditUserTimeFormat UserTimeFormat
    {
      get => this.GetPropertyValue<MaskedEditUserTimeFormat>(nameof (UserTimeFormat), MaskedEditUserTimeFormat.None);
      set => this.SetPropertyValue<MaskedEditUserTimeFormat>(nameof (UserTimeFormat), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(true)]
    public bool ClearMaskOnLostFocus
    {
      get => this.GetPropertyValue<bool>("ClearMaskOnLostfocus", true);
      set => this.SetPropertyValue<bool>("ClearMaskOnLostfocus", value);
    }

    [DefaultValue("")]
    [RefreshProperties(RefreshProperties.All)]
    [ExtenderControlProperty]
    public string CultureName
    {
      get => this.GetPropertyValue<string>(nameof (CultureName), "");
      set
      {
        CultureInfo culture;
        if (string.IsNullOrEmpty(value))
        {
          culture = CultureInfo.CurrentCulture;
          this.OverridePageCulture = false;
        }
        else
        {
          culture = CultureInfo.GetCultureInfo(value);
          this.OverridePageCulture = true;
        }
        this.SetPropertyValue<string>(nameof (CultureName), culture.Name);
        this.CultureDatePlaceholder = culture.DateTimeFormat.DateSeparator;
        this.CultureTimePlaceholder = culture.DateTimeFormat.TimeSeparator;
        this.CultureDecimalPlaceholder = culture.NumberFormat.NumberDecimalSeparator;
        this.CultureThousandsPlaceholder = culture.NumberFormat.NumberGroupSeparator;
        char ch = char.Parse(culture.DateTimeFormat.DateSeparator);
        string[] strArray = culture.DateTimeFormat.ShortDatePattern.Split(ch);
        this.CultureDateFormat = strArray[0].Substring(0, 1).ToUpper(culture) + strArray[1].Substring(0, 1).ToUpper(culture) + strArray[2].Substring(0, 1).ToUpper(culture);
        this.CultureCurrencySymbolPlaceholder = culture.NumberFormat.CurrencySymbol;
        if (string.IsNullOrEmpty(culture.DateTimeFormat.AMDesignator + culture.DateTimeFormat.PMDesignator))
          this.CultureAMPMPlaceholder = "";
        else
          this.CultureAMPMPlaceholder = culture.DateTimeFormat.AMDesignator + ";" + culture.DateTimeFormat.PMDesignator;
      }
    }

    internal bool OverridePageCulture
    {
      get => this.GetPropertyValue<bool>(nameof (OverridePageCulture), false);
      set => this.SetPropertyValue<bool>(nameof (OverridePageCulture), value);
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string CultureDatePlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureDatePlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureDatePlaceholder), value);
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [ExtenderControlProperty]
    public string CultureTimePlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureTimePlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureTimePlaceholder), value);
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    [ExtenderControlProperty]
    public string CultureDecimalPlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureDecimalPlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureDecimalPlaceholder), value);
    }

    [ExtenderControlProperty]
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public string CultureThousandsPlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureThousandsPlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureThousandsPlaceholder), value);
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string CultureDateFormat
    {
      get => this.GetPropertyValue<string>(nameof (CultureDateFormat), "");
      set => this.SetPropertyValue<string>(nameof (CultureDateFormat), value);
    }

    [ExtenderControlProperty]
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public string CultureCurrencySymbolPlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureCurrencySymbolPlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureCurrencySymbolPlaceholder), value);
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [ExtenderControlProperty]
    [Browsable(false)]
    public string CultureAMPMPlaceholder
    {
      get => this.GetPropertyValue<string>(nameof (CultureAMPMPlaceholder), "");
      set => this.SetPropertyValue<string>(nameof (CultureAMPMPlaceholder), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(false)]
    public bool AcceptAMPM
    {
      get => this.GetPropertyValue<bool>("AcceptAmPm", false);
      set => this.SetPropertyValue<bool>("AcceptAmPm", value);
    }

    [DefaultValue(MaskedEditShowSymbol.None)]
    [ExtenderControlProperty]
    public MaskedEditShowSymbol AcceptNegative
    {
      get => this.GetPropertyValue<MaskedEditShowSymbol>(nameof (AcceptNegative), MaskedEditShowSymbol.None);
      set => this.SetPropertyValue<MaskedEditShowSymbol>(nameof (AcceptNegative), value);
    }

    [DefaultValue("MaskedEditFocusNegative")]
    [ExtenderControlProperty]
    public string OnFocusCssNegative
    {
      get => this.GetPropertyValue<string>(nameof (OnFocusCssNegative), "MaskedEditFocusNegative");
      set => this.SetPropertyValue<string>(nameof (OnFocusCssNegative), value);
    }

    [ExtenderControlProperty]
    [DefaultValue("MaskedEditBlurNegative")]
    public string OnBlurCssNegative
    {
      get => this.GetPropertyValue<string>(nameof (OnBlurCssNegative), "MaskedEditBlurNegative");
      set => this.SetPropertyValue<string>(nameof (OnBlurCssNegative), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(MaskedEditShowSymbol.None)]
    public MaskedEditShowSymbol DisplayMoney
    {
      get => this.GetPropertyValue<MaskedEditShowSymbol>(nameof (DisplayMoney), MaskedEditShowSymbol.None);
      set => this.SetPropertyValue<MaskedEditShowSymbol>(nameof (DisplayMoney), value);
    }

    [DefaultValue(1900)]
    [ExtenderControlProperty]
    public int Century
    {
      get => this.GetPropertyValue<int>(nameof (Century), 1900);
      set
      {
        if (value.ToString((IFormatProvider) CultureInfo.InvariantCulture).Length != 4)
          throw new ArgumentException("The Century must have 4 digits.");
        this.SetPropertyValue<int>(nameof (Century), value);
      }
    }

    private bool validateMaskType()
    {
      string mask = this.Mask;
      MaskedEditType maskType = this.MaskType;
      if (!string.IsNullOrEmpty(mask) && (maskType == MaskedEditType.Date || maskType == MaskedEditType.Time))
      {
        string validMask = MaskedEditCommon.GetValidMask(mask);
        switch (maskType)
        {
          case MaskedEditType.Date:
            return Array.IndexOf<string>(new string[4]
            {
              "99/99/9999",
              "99/9999/99",
              "9999/99/99",
              "99/99/99"
            }, validMask) >= 0;
          case MaskedEditType.Number:
            foreach (char ch in validMask)
            {
              switch (ch)
              {
                case ',':
                case '.':
                case '9':
                  continue;
                default:
                  return false;
              }
            }
            break;
          case MaskedEditType.Time:
            return Array.IndexOf<string>(new string[2]
            {
              "99:99:99",
              "99:99"
            }, validMask) >= 0;
          case MaskedEditType.DateTime:
            return Array.IndexOf<string>(new string[8]
            {
              "99/99/9999 99:99:99",
              "99/99/9999 99:99",
              "99/9999/99 99:99:99",
              "99/9999/99 99:99",
              "9999/99/99 99:99:99",
              "9999/99/99 99:99",
              "99/99/99 99:99:99",
              "99/99/99 99:99"
            }, validMask) >= 0;
        }
      }
      return true;
    }
  }
}
