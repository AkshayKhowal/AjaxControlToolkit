﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.ComboBox
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Security.Permissions;
using System.Web;
using System.Web.UI;
using System.Web.UI.Design.WebControls;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [DefaultEvent("SelectedIndexChanged")]
  [RequiredScript(typeof (ScriptControlBase), 2)]
  [RequiredScript(typeof (PopupExtender), 3)]
  [ToolboxBitmap(typeof (ComboBox), "ComboBox.ComboBox.ico")]
  [SupportsEventValidation]
  [ValidationProperty("SelectedItem")]
  [Designer(typeof (ComboBoxDesigner))]
  [Bindable(true, BindingDirection.TwoWay)]
  [DataBindingHandler(typeof (ListControlDataBindingHandler))]
  [DefaultProperty("SelectedValue")]
  [ControlValueProperty("SelectedValue")]
  [ParseChildren(true, "Items")]
  [ToolboxData("<{0}:ComboBox runat=\"server\"></{0}:ComboBox>")]
  [ClientCssResource("AjaxControlToolkit.ComboBox.ComboBox.css", LoadOrder = 1)]
  [ClientScriptResource("AjaxControlToolkit.ComboBox", "AjaxControlToolkit.ComboBox.ComboBox.js")]
  [RequiredScript(typeof (CommonToolkitScripts), 4)]
  [ToolboxItem("System.Web.UI.Design.WebControlToolboxItem, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
  [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
  [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
  public class ComboBox : 
    ListControl,
    IScriptControl,
    IPostBackDataHandler,
    INamingContainer,
    IControlResolver
  {
    private TextBox _textBoxControl;
    private ScriptManager _scriptManager;
    private ComboBoxButton _buttonControl;
    private HiddenField _hiddenFieldControl;
    private System.Web.UI.WebControls.BulletedList _optionListControl;
    private Table _comboTable;
    private TableRow _comboTableRow;
    private TableCell _comboTableTextBoxCell;
    private TableCell _comboTableButtonCell;
    private static readonly object EventItemInserting = new object();
    private static readonly object EventItemInserted = new object();

    protected virtual ScriptManager ScriptManager
    {
      set => this._scriptManager = value;
      get
      {
        if (this._scriptManager == null)
        {
          this._scriptManager = ScriptManager.GetCurrent(this.Page);
          ScriptManager scriptManager = this._scriptManager;
        }
        return this._scriptManager;
      }
    }

    protected virtual string ClientControlType => ((ClientScriptResourceAttribute) TypeDescriptor.GetAttributes((object) this)[typeof (ClientScriptResourceAttribute)]).ComponentType;

    public Control ResolveControl(string controlId) => this.FindControl(controlId);

    [Description("Whether the ComboBox will render as a block or inline HTML element.")]
    [Category("Layout")]
    [DefaultValue(typeof (ComboBoxRenderMode), "Inline")]
    public ComboBoxRenderMode RenderMode
    {
      set => this.ViewState[nameof (RenderMode)] = (object) value;
      get => this.ViewState[nameof (RenderMode)] != null ? (ComboBoxRenderMode) this.ViewState[nameof (RenderMode)] : ComboBoxRenderMode.Inline;
    }

    [Description("Whether the ComboBox requires typed text to match an item in the list or allows new items to be created.")]
    [Category("Behavior")]
    [DefaultValue(typeof (ComboBoxStyle), "DropDown")]
    public virtual ComboBoxStyle DropDownStyle
    {
      set => this.ViewState[nameof (DropDownStyle)] = (object) value;
      get
      {
        object obj = this.ViewState[nameof (DropDownStyle)];
        return obj == null ? ComboBoxStyle.DropDown : (ComboBoxStyle) obj;
      }
    }

    [Description("Whether the ComboBox auto-completes typing by suggesting an item in the list or appending matches as the user types.")]
    [Category("Behavior")]
    [DefaultValue(typeof (ComboBoxAutoCompleteMode), "None")]
    public virtual ComboBoxAutoCompleteMode AutoCompleteMode
    {
      set => this.ViewState[nameof (AutoCompleteMode)] = (object) value;
      get
      {
        object obj = this.ViewState[nameof (AutoCompleteMode)];
        return obj == null ? ComboBoxAutoCompleteMode.None : (ComboBoxAutoCompleteMode) obj;
      }
    }

    [Description("Whether a new item will be appended, prepended, or inserted ordinally into the items collection.")]
    [Category("Behavior")]
    [DefaultValue(typeof (ComboBoxItemInsertLocation), "Append")]
    public virtual ComboBoxItemInsertLocation ItemInsertLocation
    {
      set => this.ViewState[nameof (ItemInsertLocation)] = (object) value;
      get
      {
        object obj = this.ViewState[nameof (ItemInsertLocation)];
        return obj == null ? ComboBoxItemInsertLocation.Append : (ComboBoxItemInsertLocation) obj;
      }
    }

    [Category("Behavior")]
    [ExtenderControlProperty]
    [ClientPropertyName("caseSensitive")]
    [DefaultValue(false)]
    [Description("Whether the ComboBox auto-completes user typing on a case-sensitive basis.")]
    public virtual bool CaseSensitive
    {
      set => this.ViewState[nameof (CaseSensitive)] = (object) value;
      get
      {
        object obj = this.ViewState[nameof (CaseSensitive)];
        return obj != null && (bool) obj;
      }
    }

    [Category("Style")]
    [Description("The CSS class to apply to a hovered item in the list.")]
    [DefaultValue("")]
    [ExtenderControlProperty]
    [ClientPropertyName("listItemHoverCssClass")]
    public virtual string ListItemHoverCssClass
    {
      set => this.ViewState[nameof (ListItemHoverCssClass)] = (object) value;
      get => (string) this.ViewState[nameof (ListItemHoverCssClass)] ?? "";
    }

    [ClientPropertyName("selectedIndex")]
    [ExtenderControlProperty]
    public override int SelectedIndex
    {
      get
      {
        int selectedIndex = base.SelectedIndex;
        if (selectedIndex < 0 && this.Items.Count > 0)
        {
          this.Items[0].Selected = true;
          selectedIndex = 0;
        }
        return selectedIndex;
      }
      set => base.SelectedIndex = value;
    }

    [ExtenderControlProperty]
    [ClientPropertyName("autoPostBack")]
    public override bool AutoPostBack
    {
      get => base.AutoPostBack;
      set => base.AutoPostBack = value;
    }

    public virtual int MaxLength
    {
      get => this.TextBoxControl.MaxLength;
      set => this.TextBoxControl.MaxLength = value;
    }

    public override short TabIndex
    {
      get => this.TextBoxControl.TabIndex;
      set => this.TextBoxControl.TabIndex = value;
    }

    public override bool Enabled
    {
      get => base.Enabled;
      set
      {
        base.Enabled = value;
        this.TextBoxControl.Enabled = base.Enabled;
        this.ButtonControl.Enabled = base.Enabled;
      }
    }

    public override Unit Height
    {
      get => this.TextBoxControl.Height;
      set => this.TextBoxControl.Height = value;
    }

    public override Unit Width
    {
      get => this.TextBoxControl.Width;
      set => this.TextBoxControl.Width = value;
    }

    public override Color ForeColor
    {
      get => this.TextBoxControl.ForeColor;
      set => this.TextBoxControl.ForeColor = value;
    }

    public override Color BackColor
    {
      get => this.TextBoxControl.BackColor;
      set => this.TextBoxControl.BackColor = value;
    }

    public override FontInfo Font => this.TextBoxControl.Font;

    public override Color BorderColor
    {
      get => this.TextBoxControl.BorderColor;
      set
      {
        this.TextBoxControl.BorderColor = value;
        this.ButtonControl.BorderColor = value;
        this.TextBoxControl.Style.Add("border-right", "0px none");
      }
    }

    public override BorderStyle BorderStyle
    {
      get => this.TextBoxControl.BorderStyle;
      set
      {
        this.TextBoxControl.BorderStyle = value;
        this.ButtonControl.BorderStyle = value;
      }
    }

    public override Unit BorderWidth
    {
      get => this.TextBoxControl.BorderWidth;
      set
      {
        this.TextBoxControl.BorderWidth = value;
        this.ButtonControl.BorderWidth = value;
      }
    }

    protected virtual TextBox TextBoxControl
    {
      get
      {
        if (this._textBoxControl == null)
        {
          this._textBoxControl = new TextBox();
          this._textBoxControl.ID = "TextBox";
        }
        return this._textBoxControl;
      }
    }

    protected virtual ComboBoxButton ButtonControl
    {
      get
      {
        if (this._buttonControl == null)
        {
          this._buttonControl = new ComboBoxButton();
          this._buttonControl.ID = "Button";
        }
        return this._buttonControl;
      }
    }

    protected virtual HiddenField HiddenFieldControl
    {
      get
      {
        if (this._hiddenFieldControl == null)
        {
          this._hiddenFieldControl = new HiddenField();
          this._hiddenFieldControl.ID = "HiddenField";
        }
        return this._hiddenFieldControl;
      }
    }

    protected virtual System.Web.UI.WebControls.BulletedList OptionListControl
    {
      get
      {
        if (this._optionListControl == null)
        {
          this._optionListControl = new System.Web.UI.WebControls.BulletedList();
          this._optionListControl.ID = "OptionList";
        }
        return this._optionListControl;
      }
    }

    protected virtual Table ComboTable
    {
      get
      {
        if (this._comboTable == null)
        {
          this._comboTable = new Table();
          this._comboTable.ID = "Table";
          this._comboTable.Rows.Add(this.ComboTableRow);
        }
        return this._comboTable;
      }
    }

    protected virtual TableRow ComboTableRow
    {
      get
      {
        if (this._comboTableRow == null)
        {
          this._comboTableRow = new TableRow();
          this._comboTableRow.Cells.Add(this.ComboTableTextBoxCell);
          this._comboTableRow.Cells.Add(this.ComboTableButtonCell);
        }
        return this._comboTableRow;
      }
    }

    protected virtual TableCell ComboTableTextBoxCell
    {
      get
      {
        if (this._comboTableTextBoxCell == null)
          this._comboTableTextBoxCell = new TableCell();
        return this._comboTableTextBoxCell;
      }
    }

    protected virtual TableCell ComboTableButtonCell
    {
      get
      {
        if (this._comboTableButtonCell == null)
          this._comboTableButtonCell = new TableCell();
        return this._comboTableButtonCell;
      }
    }

    IEnumerable<ScriptReference> IScriptControl.GetScriptReferences() => this.GetScriptReferences();

    protected virtual IEnumerable<ScriptReference> GetScriptReferences()
    {
      if (!this.Visible)
        return (IEnumerable<ScriptReference>) null;
      List<ScriptReference> scriptReferences = new List<ScriptReference>();
      scriptReferences.AddRange(ScriptObjectBuilder.GetScriptReferences(this.GetType(), false));
      return (IEnumerable<ScriptReference>) scriptReferences;
    }

    IEnumerable<ScriptDescriptor> IScriptControl.GetScriptDescriptors() => this.GetScriptDescriptors();

    protected virtual IEnumerable<ScriptDescriptor> GetScriptDescriptors()
    {
      if (!this.Visible)
        return (IEnumerable<ScriptDescriptor>) null;
      List<ScriptDescriptor> scriptDescriptors = new List<ScriptDescriptor>();
      ScriptControlDescriptor descriptor = new ScriptControlDescriptor(this.ClientControlType, this.ClientID);
      ScriptObjectBuilder.DescribeComponent((object) this, (ScriptComponentDescriptor) descriptor, (IUrlResolutionService) this, (IControlResolver) this);
      descriptor.AddElementProperty("textBoxControl", this.TextBoxControl.ClientID);
      descriptor.AddElementProperty("buttonControl", this.ButtonControl.ClientID);
      descriptor.AddElementProperty("hiddenFieldControl", this.HiddenFieldControl.ClientID);
      descriptor.AddElementProperty("optionListControl", this.OptionListControl.ClientID);
      descriptor.AddElementProperty("comboTableControl", this.ComboTable.ClientID);
      descriptor.AddProperty("autoCompleteMode", (object) this.AutoCompleteMode);
      descriptor.AddProperty("dropDownStyle", (object) this.DropDownStyle);
      scriptDescriptors.Add((ScriptDescriptor) descriptor);
      return (IEnumerable<ScriptDescriptor>) scriptDescriptors;
    }

    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      ScriptObjectBuilder.RegisterCssReferences((Control) this);
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);
      this.ScriptManager.RegisterScriptControl<ComboBox>(this);
      this.Page.RegisterRequiresPostBack((Control) this);
    }

    protected override void Render(HtmlTextWriter writer)
    {
      base.Render(writer);
      if (this.DesignMode)
        return;
      this.ScriptManager.RegisterScriptDescriptors((IScriptControl) this);
    }

    protected override void CreateChildControls()
    {
      if (this.Controls.Count >= 1 && this.Controls[0] == this.ComboTable)
        return;
      this.Controls.Clear();
      this.ComboTableTextBoxCell.Controls.Add((Control) this.TextBoxControl);
      this.ComboTableButtonCell.Controls.Add((Control) this.ButtonControl);
      this.Controls.Add((Control) this.ComboTable);
      this.Controls.Add((Control) this.OptionListControl);
      this.Controls.Add((Control) this.HiddenFieldControl);
    }

    protected override HtmlTextWriterTag TagKey => HtmlTextWriterTag.Div;

    protected override void AddAttributesToRender(HtmlTextWriter writer)
    {
      this.AddContainerAttributesToRender(writer);
      this.AddTableAttributesToRender(writer);
      this.AddTextBoxAttributesToRender(writer);
      this.AddButtonAttributesToRender(writer);
      this.AddOptionListAttributesToRender(writer);
    }

    protected virtual void AddContainerAttributesToRender(HtmlTextWriter writer)
    {
      if (this.RenderMode == ComboBoxRenderMode.Inline)
        this.Style.Add(HtmlTextWriterStyle.Display, this.GetInlineDisplayStyle());
      base.AddAttributesToRender(writer);
    }

    protected virtual void AddTableAttributesToRender(HtmlTextWriter writer)
    {
      this.ComboTable.CellPadding = 0;
      this.ComboTable.CellSpacing = 0;
      this.ComboTable.CssClass = "ajax__combobox_inputcontainer";
      this.ComboTableTextBoxCell.CssClass = "ajax__combobox_textboxcontainer";
      this.ComboTableButtonCell.CssClass = "ajax__combobox_buttoncontainer";
      this.ComboTable.BorderStyle = BorderStyle.None;
      this.ComboTable.BorderWidth = Unit.Pixel(0);
      if (this.RenderMode != ComboBoxRenderMode.Inline)
        return;
      this.ComboTable.Style.Add(HtmlTextWriterStyle.Display, this.GetInlineDisplayStyle());
      if (this.DesignMode)
        return;
      this.ComboTable.Style.Add(HtmlTextWriterStyle.Position, "relative");
      this.ComboTable.Style.Add(HtmlTextWriterStyle.Top, "5px");
    }

    protected virtual void AddTextBoxAttributesToRender(HtmlTextWriter writer)
    {
      this.TextBoxControl.AutoCompleteType = AutoCompleteType.None;
      this.TextBoxControl.Attributes.Add("autocomplete", "off");
    }

    protected virtual void AddButtonAttributesToRender(HtmlTextWriter writer)
    {
      if (!this.DesignMode)
      {
        this.ButtonControl.Style.Add(HtmlTextWriterStyle.Visibility, "hidden");
      }
      else
      {
        this.ButtonControl.Width = Unit.Pixel(14);
        this.ButtonControl.Height = Unit.Pixel(14);
      }
    }

    protected virtual void AddOptionListAttributesToRender(HtmlTextWriter writer)
    {
      this.OptionListControl.CssClass = "ajax__combobox_itemlist";
      this.OptionListControl.Style.Add(HtmlTextWriterStyle.Display, "none");
      this.OptionListControl.Style.Add(HtmlTextWriterStyle.Visibility, "hidden");
    }

    public override void RenderControl(HtmlTextWriter writer)
    {
      if (this.DesignMode)
      {
        this.CreateChildControls();
        this.AddAttributesToRender(writer);
        this.ComboTable.RenderControl(writer);
      }
      else
      {
        this.HiddenFieldControl.Value = this.SelectedIndex.ToString();
        base.RenderControl(writer);
      }
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
      this.ComboTable.RenderControl(writer);
      this.OptionListControl.Items.Clear();
      ListItem[] items = new ListItem[this.Items.Count];
      this.Items.CopyTo((Array) items, 0);
      this.OptionListControl.Items.AddRange(items);
      this.OptionListControl.RenderControl(writer);
      this.HiddenFieldControl.RenderControl(writer);
    }

    bool IPostBackDataHandler.LoadPostData(
      string postDataKey,
      NameValueCollection postCollection)
    {
      return this.LoadPostData(postDataKey, postCollection);
    }

    void IPostBackDataHandler.RaisePostDataChangedEvent() => this.RaisePostDataChangedEvent();

    protected virtual bool LoadPostData(string postDataKey, NameValueCollection postCollection)
    {
      if (!this.Enabled)
        return false;
      int int32 = Convert.ToInt32(postCollection.GetValues(this.HiddenFieldControl.UniqueID)[0], (IFormatProvider) CultureInfo.InvariantCulture);
      this.EnsureDataBound();
      if (int32 == -2 && (this.DropDownStyle == ComboBoxStyle.Simple || this.DropDownStyle == ComboBoxStyle.DropDown))
      {
        ComboBoxItemInsertEventArgs e = new ComboBoxItemInsertEventArgs(postCollection.GetValues(this.TextBoxControl.UniqueID)[0], this.ItemInsertLocation);
        this.OnItemInserting(e);
        if (!e.Cancel)
          this.InsertItem(e);
        else
          this.TextBoxControl.Text = this.SelectedIndex < 0 ? string.Empty : this.SelectedItem.Text;
      }
      else if (int32 != this.SelectedIndex)
      {
        this.SelectedIndex = int32;
        return true;
      }
      return false;
    }

    public virtual void RaisePostDataChangedEvent() => this.OnSelectedIndexChanged(EventArgs.Empty);

    public event EventHandler<ComboBoxItemInsertEventArgs> ItemInserting
    {
      add => this.Events.AddHandler(ComboBox.EventItemInserting, (Delegate) value);
      remove => this.Events.RemoveHandler(ComboBox.EventItemInserting, (Delegate) value);
    }

    public event EventHandler<ComboBoxItemInsertEventArgs> ItemInserted
    {
      add => this.Events.AddHandler(ComboBox.EventItemInserted, (Delegate) value);
      remove => this.Events.RemoveHandler(ComboBox.EventItemInserted, (Delegate) value);
    }

    protected virtual void OnItemInserting(ComboBoxItemInsertEventArgs e)
    {
      EventHandler<ComboBoxItemInsertEventArgs> eventHandler = (EventHandler<ComboBoxItemInsertEventArgs>) this.Events[ComboBox.EventItemInserting];
      if (eventHandler == null)
        return;
      eventHandler((object) this, e);
    }

    protected virtual void OnItemInserted(ComboBoxItemInsertEventArgs e)
    {
      EventHandler<ComboBoxItemInsertEventArgs> eventHandler = (EventHandler<ComboBoxItemInsertEventArgs>) this.Events[ComboBox.EventItemInserted];
      if (eventHandler == null)
        return;
      eventHandler((object) this, e);
    }

    protected virtual void InsertItem(ComboBoxItemInsertEventArgs e)
    {
      if (e.Cancel)
        return;
      int index = -1;
      if (e.InsertLocation == ComboBoxItemInsertLocation.Prepend)
        index = 0;
      else if (e.InsertLocation == ComboBoxItemInsertLocation.Append)
        index = this.Items.Count;
      else if (e.InsertLocation == ComboBoxItemInsertLocation.OrdinalText)
      {
        index = 0;
        foreach (ListItem listItem in this.Items)
        {
          if (string.Compare(e.Item.Text, listItem.Text, StringComparison.Ordinal) > 0)
            ++index;
          else
            break;
        }
      }
      else if (e.InsertLocation == ComboBoxItemInsertLocation.OrdinalValue)
      {
        index = 0;
        foreach (ListItem listItem in this.Items)
        {
          if (string.Compare(e.Item.Value, listItem.Value, StringComparison.Ordinal) > 0)
            ++index;
          else
            break;
        }
      }
      if (index >= this.Items.Count)
      {
        this.Items.Add(e.Item);
        this.SelectedIndex = this.Items.Count - 1;
      }
      else
      {
        this.Items.Insert(index, e.Item);
        this.SelectedIndex = index;
      }
      this.OnItemInserted(e);
    }

    private string GetInlineDisplayStyle()
    {
      string inlineDisplayStyle = "inline";
      if (!this.DesignMode && (this.Page.Request.Browser.Browser.ToLower().Contains("safari") || this.Page.Request.Browser.Browser.ToLower().Contains("firefox")))
        inlineDisplayStyle += "-block";
      return inlineDisplayStyle;
    }
  }
}
