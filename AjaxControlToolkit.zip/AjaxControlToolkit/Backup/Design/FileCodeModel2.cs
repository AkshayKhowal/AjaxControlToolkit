﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.FileCodeModel2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class FileCodeModel2
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (FileCodeModel2._referencedType == null)
        {
          FileCodeModel2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.FileCodeModel2");
          if (FileCodeModel2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.FileCodeModel2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return FileCodeModel2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public FileCodeModel2()
      : this((object) null)
    {
    }

    public FileCodeModel2(object reference) => this._reference = FileCodeModel2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public CodeElements CodeElements
    {
      get
      {
        object reference = FileCodeModel2.ReferencedType.GetProperty(nameof (CodeElements)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }
  }
}
