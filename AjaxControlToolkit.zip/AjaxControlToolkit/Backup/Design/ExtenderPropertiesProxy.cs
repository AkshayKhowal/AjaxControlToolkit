﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.ExtenderPropertiesProxy
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI;

namespace AjaxControlToolkit.Design
{
  internal class ExtenderPropertiesProxy : ICustomTypeDescriptor
  {
    private object _target;
    private string[] _propsToHide;

    private object Target => this._target;

    public ExtenderPropertiesProxy(object target, params string[] propsToHide)
    {
      this._target = target;
      this._propsToHide = propsToHide;
    }

    PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties(
      Attribute[] attributes)
    {
      PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(this.Target);
      if (this._propsToHide != null && this._propsToHide.Length > 0)
      {
        List<PropertyDescriptor> propertyDescriptorList = new List<PropertyDescriptor>();
        for (int index = 0; index < properties.Count; ++index)
        {
          PropertyDescriptor prop = properties[index];
          if ((ExtenderControlPropertyAttribute) prop.Attributes[typeof (ExtenderControlPropertyAttribute)] != null)
          {
            ExtenderVisiblePropertyAttribute attribute1 = (ExtenderVisiblePropertyAttribute) prop.Attributes[typeof (ExtenderVisiblePropertyAttribute)];
            if (attribute1 != null && attribute1.Value && Array.FindIndex<string>(this._propsToHide, (Predicate<string>) (s => s == prop.Name)) == -1)
            {
              IDReferencePropertyAttribute attribute2 = (IDReferencePropertyAttribute) prop.Attributes[typeof (IDReferencePropertyAttribute)];
              Attribute attribute3 = prop.Attributes[typeof (TypeConverterAttribute)];
              if (attribute2 != null && !attribute2.IsDefaultAttribute())
                attribute3 = (Attribute) new TypeConverterAttribute(typeof (TypedControlIDConverter<Control>).GetGenericTypeDefinition().MakeGenericType(attribute2.ReferencedControlType));
              prop = TypeDescriptor.CreateProperty(prop.ComponentType, prop, (Attribute) BrowsableAttribute.Yes, attribute3);
              propertyDescriptorList.Add(prop);
            }
          }
        }
        properties = new PropertyDescriptorCollection(propertyDescriptorList.ToArray());
      }
      return properties;
    }

    System.ComponentModel.AttributeCollection ICustomTypeDescriptor.GetAttributes() => TypeDescriptor.GetAttributes(this.Target);

    string ICustomTypeDescriptor.GetClassName() => TypeDescriptor.GetClassName(this.Target);

    string ICustomTypeDescriptor.GetComponentName() => TypeDescriptor.GetComponentName(this.Target);

    TypeConverter ICustomTypeDescriptor.GetConverter() => TypeDescriptor.GetConverter(this.Target);

    EventDescriptor ICustomTypeDescriptor.GetDefaultEvent() => TypeDescriptor.GetDefaultEvent(this.Target);

    PropertyDescriptor ICustomTypeDescriptor.GetDefaultProperty() => TypeDescriptor.GetDefaultProperty(this.Target);

    object ICustomTypeDescriptor.GetEditor(Type editorBaseType) => TypeDescriptor.GetEditor(this.Target, editorBaseType);

    EventDescriptorCollection ICustomTypeDescriptor.GetEvents(
      Attribute[] attributes)
    {
      return TypeDescriptor.GetEvents(this.Target, attributes);
    }

    EventDescriptorCollection ICustomTypeDescriptor.GetEvents() => TypeDescriptor.GetEvents(this.Target);

    PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties() => TypeDescriptor.GetProperties(this.Target);

    object ICustomTypeDescriptor.GetPropertyOwner(PropertyDescriptor pd) => this.Target;
  }
}
