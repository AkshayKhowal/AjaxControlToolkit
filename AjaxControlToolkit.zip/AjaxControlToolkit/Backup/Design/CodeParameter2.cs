﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeParameter2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class CodeParameter2
  {
    private static System.Type _referencedType;
    private object _reference;

    public static System.Type ReferencedType
    {
      get
      {
        if (CodeParameter2._referencedType == null)
        {
          CodeParameter2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.CodeParameter2");
          if (CodeParameter2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.CodeParameter2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeParameter2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeParameter2()
      : this((object) null)
    {
    }

    public CodeParameter2(object reference) => this._reference = CodeParameter2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public string Name
    {
      get => (string) CodeParameter2.ReferencedType.GetProperty(nameof (Name)).GetValue(this._reference, new object[0]);
      set => CodeParameter2.ReferencedType.GetProperty(nameof (Name)).SetValue(this._reference, (object) value, new object[0]);
    }

    public CodeTypeRef Type
    {
      get
      {
        object reference = CodeParameter2.ReferencedType.GetProperty(nameof (Type)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeTypeRef) null : new CodeTypeRef(reference);
      }
      set => CodeParameter2.ReferencedType.GetProperty(nameof (Type)).SetValue(this._reference, value?.Reference, new object[0]);
    }
  }
}
