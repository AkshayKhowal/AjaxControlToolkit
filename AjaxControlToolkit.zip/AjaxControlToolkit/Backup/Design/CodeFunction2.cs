﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeFunction2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class CodeFunction2
  {
    private static System.Type _referencedType;
    private object _reference;

    public static System.Type ReferencedType
    {
      get
      {
        if (CodeFunction2._referencedType == null)
        {
          CodeFunction2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.CodeFunction2");
          if (CodeFunction2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.CodeFunction2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeFunction2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeFunction2()
      : this((object) null)
    {
    }

    public CodeFunction2(object reference) => this._reference = CodeFunction2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public CodeElements Children
    {
      get
      {
        object reference = CodeFunction2.ReferencedType.GetProperty(nameof (Children)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }

    public CodeTypeRef Type
    {
      get
      {
        object reference = CodeFunction2.ReferencedType.GetProperty(nameof (Type)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeTypeRef) null : new CodeTypeRef(reference);
      }
      set => CodeFunction2.ReferencedType.GetProperty(nameof (Type)).SetValue(this._reference, value?.Reference, new object[0]);
    }

    public CodeElements Parameters
    {
      get
      {
        object reference = CodeFunction2.ReferencedType.GetProperty(nameof (Parameters)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }

    public vsCMAccess Access
    {
      get
      {
        object reference = CodeFunction2.ReferencedType.GetProperty(nameof (Access)).GetValue(this._reference, new object[0]);
        return reference == null ? (vsCMAccess) null : new vsCMAccess(reference);
      }
      set => CodeFunction2.ReferencedType.GetProperty(nameof (Access)).SetValue(this._reference, value != (vsCMAccess) null ? value.Reference : (object) null, new object[0]);
    }

    public bool IsShared
    {
      get => (bool) CodeFunction2.ReferencedType.GetProperty(nameof (IsShared)).GetValue(this._reference, new object[0]);
      set => CodeFunction2.ReferencedType.GetProperty(nameof (IsShared)).SetValue(this._reference, (object) value, new object[0]);
    }

    public CodeElements Attributes
    {
      get
      {
        object reference = CodeFunction2.ReferencedType.GetProperty(nameof (Attributes)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }

    public CodeParameter2 AddParameter(string Name, object Type, object Position)
    {
      object reference = CodeFunction2.ReferencedType.GetMethod(nameof (AddParameter)).Invoke(this._reference, new object[3]
      {
        (object) Name,
        Type,
        Position
      });
      return reference == null ? (CodeParameter2) null : new CodeParameter2(reference);
    }

    public CodeAttribute2 AddAttribute(string Name, string Value, object Position)
    {
      object reference = CodeFunction2.ReferencedType.GetMethod(nameof (AddAttribute)).Invoke(this._reference, new object[3]
      {
        (object) Name,
        (object) Value,
        Position
      });
      return reference == null ? (CodeAttribute2) null : new CodeAttribute2(reference);
    }
  }
}
