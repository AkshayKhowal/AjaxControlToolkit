﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.ExtenderControlBaseDesigner`1
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Globalization;
using System.Reflection;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.Design;
using System.Windows.Forms;

namespace AjaxControlToolkit.Design
{
  public class ExtenderControlBaseDesigner<T> : ExtenderControlDesigner, IExtenderProvider
    where T : ExtenderControlBase
  {
    private const int DisableDesignerFeaturesUnknown = 0;
    private const int DisableDesignerFeaturesYes = 1;
    private const int DisableDesignerFeaturesNo = 2;
    private const string ExtenderControlDictionaryKey = "ExtenderControlFeaturesPresent";
    private DesignerActionListCollection _actionLists;
    private ExtenderControlBaseDesigner<T>.ExtenderPropertyRenameDescProv _renameProvider;
    private int _disableDesignerFeatures;

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        if (this._actionLists == null)
        {
          this._actionLists = new DesignerActionListCollection();
          this._actionLists.AddRange(base.ActionLists);
          foreach (System.Type nestedType in this.GetType().GetNestedTypes(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic))
          {
            if (nestedType.IsSubclassOf(typeof (Delegate)) && System.Attribute.GetCustomAttribute((MemberInfo) nestedType, typeof (PageMethodSignatureAttribute)) is PageMethodSignatureAttribute customAttribute)
            {
              MethodInfo method = nestedType.GetMethod("Invoke");
              if (method != null)
                this._actionLists.Add((DesignerActionList) new ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList(this.Component, method, customAttribute));
            }
          }
        }
        return this._actionLists;
      }
    }

    static ExtenderControlBaseDesigner() => TypeDescriptor.AddAttributes(typeof (ExtenderControlBaseDesigner<T>), new System.Attribute[1]
    {
      (System.Attribute) new ProvidePropertyAttribute("Extender", typeof (System.Web.UI.Control))
    });

    protected bool DesignerFeaturesEnabled
    {
      get
      {
        if (this._disableDesignerFeatures == 0)
        {
          this._disableDesignerFeatures = 2;
          IDesignerHost service1 = (IDesignerHost) this.GetService(typeof (IDesignerHost));
          if (service1 != null)
          {
            IComponent rootComponent = service1.RootComponent;
            if (rootComponent != null && rootComponent.Site != null)
            {
              IDictionaryService service2 = (IDictionaryService) rootComponent.Site.GetService(typeof (IDictionaryService));
              if (service2 != null && service2.GetValue((object) "ExtenderControlFeaturesPresent") != null)
                this._disableDesignerFeatures = 1;
            }
          }
        }
        return this._disableDesignerFeatures == 2;
      }
    }

    protected T ExtenderControl => this.Component as T;

    protected virtual string ExtenderPropertyName => string.Format((IFormatProvider) CultureInfo.InvariantCulture, "{0} ({1})", (object) TypeDescriptor.GetComponentName((object) this.Component), (object) this.ExtenderControl.GetType().Name);

    public bool CanExtend(object extendee)
    {
      System.Web.UI.Control control = extendee as System.Web.UI.Control;
      bool flag = false;
      if (this.DesignerFeaturesEnabled && control != null)
      {
        flag = control.ID == this.ExtenderControl.TargetControlID;
        if (flag && this._renameProvider == null)
        {
          this._renameProvider = new ExtenderControlBaseDesigner<T>.ExtenderPropertyRenameDescProv(this, (IComponent) control);
          TypeDescriptor.AddProvider((TypeDescriptionProvider) this._renameProvider, (object) control);
        }
      }
      return flag;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this._renameProvider != null)
      {
        TypeDescriptor.RemoveProvider((TypeDescriptionProvider) this._renameProvider, (object) this.Component);
        this._renameProvider.Dispose();
        this._renameProvider = (ExtenderControlBaseDesigner<T>.ExtenderPropertyRenameDescProv) null;
      }
      base.Dispose(disposing);
    }

    [Category("Extenders")]
    [Browsable(true)]
    [TypeConverter(typeof (ExtenderPropertiesTypeDescriptor))]
    public object GetExtender(object control)
    {
      System.Web.UI.Control control1 = control as System.Web.UI.Control;
      if (!this.DesignerFeaturesEnabled || control1 == null)
        return (object) null;
      return (object) new ExtenderPropertiesProxy((object) this.ExtenderControl, new string[1]
      {
        "TargetControlID"
      });
    }

    public override void Initialize(IComponent component) => base.Initialize(component);

    protected override void PreFilterAttributes(IDictionary attributes)
    {
      base.PreFilterAttributes(attributes);
      if (!this.DesignerFeaturesEnabled)
        return;
      TargetControlTypeAttribute attribute = (TargetControlTypeAttribute) TypeDescriptor.GetAttributes((object) this)[typeof (TargetControlTypeAttribute)];
      if (attribute == null || attribute.IsDefaultAttribute())
        return;
      attributes[(object) typeof (TargetControlTypeAttribute)] = (object) attribute;
    }

    protected override void PreFilterProperties(IDictionary properties)
    {
      base.PreFilterProperties(properties);
      if (!this.DesignerFeaturesEnabled)
        return;
      string[] strArray = new string[properties.Keys.Count];
      properties.Keys.CopyTo((Array) strArray, 0);
      foreach (string key in strArray)
      {
        PropertyDescriptor property = (PropertyDescriptor) properties[(object) key];
        if (key == "TargetControlID")
        {
          TargetControlTypeAttribute attribute = (TargetControlTypeAttribute) TypeDescriptor.GetAttributes((object) this.ExtenderControl)[typeof (TargetControlTypeAttribute)];
          if (attribute != null && !attribute.IsDefaultAttribute())
          {
            System.Type type = typeof (TypedControlIDConverter<>).MakeGenericType(attribute.TargetControlType);
            properties[(object) key] = (object) TypeDescriptor.CreateProperty(property.ComponentType, property, (System.Attribute) new TypeConverterAttribute(type));
          }
        }
        ExtenderControlPropertyAttribute attribute1 = (ExtenderControlPropertyAttribute) property.Attributes[typeof (ExtenderControlPropertyAttribute)];
        if (attribute1 != null && attribute1.IsScriptProperty && ((BrowsableAttribute) property.Attributes[typeof (BrowsableAttribute)]).Browsable == BrowsableAttribute.Yes.Browsable)
          properties[(object) key] = (object) TypeDescriptor.CreateProperty(property.ComponentType, property, (System.Attribute) BrowsableAttribute.No, (System.Attribute) ExtenderVisiblePropertyAttribute.Yes);
      }
    }

    private class PageMethodDesignerActionList : DesignerActionList
    {
      private MethodInfo _signature;
      private PageMethodSignatureAttribute _attribute;

      public PageMethodDesignerActionList(
        IComponent component,
        MethodInfo signature,
        PageMethodSignatureAttribute attribute)
        : base(component)
      {
        this._signature = signature;
        this._attribute = attribute;
      }

      public override DesignerActionItemCollection GetSortedActionItems()
      {
        DesignerActionItemCollection sortedActionItems = new DesignerActionItemCollection();
        PropertyDescriptor property = TypeDescriptor.GetProperties((object) this.Component)[this._attribute.ServicePathProperty];
        if ((property == null || property != null && string.IsNullOrEmpty(property.GetValue((object) this.Component) as string)) && this.GetService(typeof (IEventBindingService)) != null)
        {
          string str = string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Add {0} page method", (object) this._attribute.FriendlyName);
          sortedActionItems.Add((DesignerActionItem) new DesignerActionMethodItem((DesignerActionList) this, "AddPageMethod", str, "Page Methods", str, true));
        }
        return sortedActionItems;
      }

      private void AddPageMethod()
      {
        try
        {
          string name = this._signature.DeclaringType.Name;
          PropertyDescriptor property1 = TypeDescriptor.GetProperties((object) this.Component)[this._attribute.ServicePathProperty];
          if (property1 != null)
          {
            string str = property1.GetValue((object) this.Component) as string;
            if (!string.IsNullOrEmpty(str))
            {
              int num = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Cannot create page method \"{0}\" because the extender is using web service \"{1}\" instead!", (object) name, (object) str));
              return;
            }
          }
          if (this._attribute.IncludeContextParameter)
            TypeDescriptor.GetProperties((object) this.Component)[this._attribute.UseContextKeyProperty]?.SetValue((object) this.Component, (object) true);
          IEventBindingService service1;
          if (!this.EnsureService<IEventBindingService>(out service1))
            return;
          service1.ShowCode();
          object service2 = this.GetService(ReferencedAssemblies.EnvDTE.GetType("EnvDTE._DTE"));
          if (service2 == null)
          {
            int num1 = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Cannot create page method \"{0}\" because {1} could not be acquired!", (object) this._signature.DeclaringType.Name, (object) "EnvDTE._DTE"));
          }
          else
          {
            DTE2 dtE2 = new DTE2(service2);
            try
            {
              FileCodeModel2 model = ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.LoadFileCodeModel(dtE2.ActiveDocument.ProjectItem);
              if (model == null || model.Reference == null)
              {
                int num2 = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Cannot create page method \"{0}\" because no CodeBehind or CodeFile file was found!", (object) name));
              }
              else
              {
                IDesignerHost service3;
                if (!this.EnsureService<IDesignerHost>(out service3))
                  return;
                CodeClass2 classModel = ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.FindClass(model, service3.RootComponentClassName);
                if (classModel == null || classModel.Reference == null)
                {
                  int num3 = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Cannot create page method \"{0}\" because no CodeBehind or CodeFile file was found!", (object) name));
                }
                else
                {
                  PropertyDescriptor property2 = TypeDescriptor.GetProperties((object) this.Component)[this._attribute.ServiceMethodProperty];
                  if (property2 != null)
                  {
                    string str1 = property2.GetValue((object) this.Component) as string;
                    if (!string.IsNullOrEmpty(str1))
                    {
                      name = str1;
                    }
                    else
                    {
                      string str2 = name;
                      int num4 = 2;
                      while (ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.FindMethod(classModel, name, this._signature) != null)
                        name = str2 + (object) num4++;
                      property2.SetValue((object) this.Component, (object) name);
                    }
                  }
                  UndoContext undoContext = dtE2.UndoContext;
                  if (undoContext != null)
                  {
                    if (undoContext.Reference != null)
                    {
                      if (undoContext.IsOpen)
                        undoContext = (UndoContext) null;
                    }
                  }
                  try
                  {
                    CodeFunction2 method = ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.FindMethod(classModel, name, this._signature);
                    if (method != null && method.Reference != null)
                    {
                      if (!this.PageMethodNeedsRepair(method))
                        return;
                      if (ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Would you like to repair the existing page method \"{0}\"?", (object) name), MessageBoxButtons.YesNo) != DialogResult.Yes)
                        return;
                      undoContext?.Open(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Repair \"{0}\" page method", (object) name), false);
                      this.RepairPageMethod(method);
                    }
                    else
                    {
                      undoContext?.Open(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Add \"{0}\" page method", (object) name), false);
                      this.CreatePageMethod(classModel, name);
                    }
                  }
                  finally
                  {
                    if (undoContext != null && undoContext.IsOpen)
                      undoContext.Close();
                  }
                }
              }
            }
            finally
            {
              ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.UnloadWebProjectItem(dtE2.ActiveDocument.ProjectItem);
            }
          }
        }
        catch (Exception ex)
        {
          int num = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Unexpected error ({0}): {1}{2}{3}", (object) ex.GetType().Name, (object) ex.Message, (object) Environment.NewLine, (object) ex.StackTrace));
        }
      }

      private bool EnsureService<S>(out S service) where S : class
      {
        service = this.GetService(typeof (S)) as S;
        if ((object) service != null)
          return true;
        int num = (int) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "Cannot create page method \"{0}\" because {1} could not be acquired!", (object) this._signature.DeclaringType.Name, (object) typeof (S).Name));
        return false;
      }

      private static DialogResult ShowMessage(string message) => ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.ShowMessage(message, MessageBoxButtons.OK);

      private static DialogResult ShowMessage(string message, MessageBoxButtons buttons) => MessageBox.Show(message, "Ajax Control Toolkit", buttons);

      private static CodeClass2 FindClass(FileCodeModel2 model, string name)
      {
        Queue<CodeElement2> codeElement2Queue = new Queue<CodeElement2>();
        foreach (object codeElement in model.CodeElements)
          codeElement2Queue.Enqueue(new CodeElement2(codeElement));
        while (codeElement2Queue.Count > 0)
        {
          CodeElement2 codeElement2 = codeElement2Queue.Dequeue();
          if (codeElement2 != null && codeElement2.Reference != null && (codeElement2.IsCodeType || !(codeElement2.Kind != vsCMElement.vsCMElementNamespace)))
          {
            if (codeElement2.Kind == vsCMElement.vsCMElementClass && string.CompareOrdinal(codeElement2.FullName, name) == 0)
              return new CodeClass2(codeElement2.Reference);
            if (codeElement2.Children != null)
            {
              foreach (object child in codeElement2.Children)
                codeElement2Queue.Enqueue(new CodeElement2(child));
            }
          }
        }
        return (CodeClass2) null;
      }

      private static CodeFunction2[] FindMethods(CodeClass2 classModel, string name)
      {
        List<CodeFunction2> codeFunction2List = new List<CodeFunction2>();
        foreach (object child in classModel.Children)
        {
          CodeElement2 codeElement2 = new CodeElement2(child);
          if (codeElement2.Reference != null && !(codeElement2.Kind != vsCMElement.vsCMElementFunction) && string.CompareOrdinal(codeElement2.Name, name) == 0)
            codeFunction2List.Add(new CodeFunction2(child));
        }
        return codeFunction2List.ToArray();
      }

      private static CodeFunction2 FindMethod(
        CodeClass2 classModel,
        string name,
        MethodInfo signature)
      {
        ParameterInfo[] parameters = signature.GetParameters();
        foreach (CodeFunction2 method in ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.FindMethods(classModel, name))
        {
          if (method != null && method.Reference != null && ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.AreSameType(method.Type, signature.ReturnType) && method.Parameters.Count == parameters.Length)
          {
            bool flag = false;
            int num = 0;
            foreach (object parameter in method.Parameters)
            {
              CodeParameter2 codeParameter2 = new CodeParameter2(parameter);
              if (codeParameter2.Reference == null || !ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.AreSameType(codeParameter2.Type, parameters[num++].ParameterType))
              {
                flag = true;
                break;
              }
            }
            if (!flag)
              return method;
          }
        }
        return (CodeFunction2) null;
      }

      private static string CreateCodeTypeRefName(System.Type t) => t.FullName.Replace('+', '.');

      private static bool AreSameType(CodeTypeRef modelType, System.Type type)
      {
        if (modelType == null || modelType.Reference == null)
          return type == null;
        if (modelType.TypeKind == vsCMTypeRef.vsCMTypeRefArray)
          return type.IsArray && modelType.Rank == type.GetArrayRank() && ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.AreSameType(modelType.ElementType, type.GetElementType());
        if (!(modelType.TypeKind == vsCMTypeRef.vsCMTypeRefPointer))
          return string.CompareOrdinal(modelType.AsFullName, ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.CreateCodeTypeRefName(type)) == 0;
        return type.IsPointer && ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.AreSameType(modelType.ElementType, type.GetElementType());
      }

      private void CreatePageMethod(CodeClass2 classModel, string name)
      {
        ParameterInfo[] parameters = this._signature.GetParameters();
        CodeFunction2 codeFunction2 = classModel.AddFunction(name, vsCMFunction.vsCMFunctionFunction, (object) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.CreateCodeTypeRefName(this._signature.ReturnType), (object) -1, vsCMAccess.vsCMAccessPublic, (object) null);
        codeFunction2.IsShared = true;
        foreach (ParameterInfo parameterInfo in parameters)
          codeFunction2.AddParameter(parameterInfo.Name, (object) ExtenderControlBaseDesigner<T>.PageMethodDesignerActionList.CreateCodeTypeRefName(parameterInfo.ParameterType), (object) -1);
        codeFunction2.AddAttribute(typeof (WebMethodAttribute).FullName, "", (object) -1);
        codeFunction2.AddAttribute(typeof (ScriptMethodAttribute).FullName, "", (object) -1);
      }

      private bool PageMethodNeedsRepair(CodeFunction2 method)
      {
        if (method == null || method.Reference == null)
          return false;
        ParameterInfo[] parameters = this._signature.GetParameters();
        if (!method.IsShared || method.Access != vsCMAccess.vsCMAccessPublic)
          return true;
        int num = 0;
        foreach (object parameter in method.Parameters)
        {
          CodeParameter2 codeParameter2 = new CodeParameter2(parameter);
          if (codeParameter2.Reference == null || string.Compare(codeParameter2.Name, parameters[num++].Name, StringComparison.Ordinal) != 0)
            return true;
        }
        bool flag1 = false;
        bool flag2 = false;
        foreach (object attribute in method.Attributes)
        {
          CodeAttribute2 codeAttribute2 = new CodeAttribute2(attribute);
          if (codeAttribute2.Reference != null)
          {
            flag1 = ((flag1 ? 1 : 0) | (string.IsNullOrEmpty(codeAttribute2.Name) ? 0 : (codeAttribute2.Name.Contains("WebMethod") ? 1 : 0))) != 0;
            flag2 = ((flag2 ? 1 : 0) | (string.IsNullOrEmpty(codeAttribute2.Name) ? 0 : (codeAttribute2.Name.Contains("ScriptMethod") ? 1 : 0))) != 0;
            if (flag1)
            {
              if (flag2)
                break;
            }
          }
        }
        return !flag1 || !flag2;
      }

      private void RepairPageMethod(CodeFunction2 method)
      {
        if (method == null || method.Reference == null)
          return;
        method.IsShared = true;
        method.Access = vsCMAccess.vsCMAccessPublic;
        int num = 0;
        ParameterInfo[] parameters = this._signature.GetParameters();
        foreach (object parameter in method.Parameters)
        {
          CodeParameter2 codeParameter2 = new CodeParameter2(parameter);
          if (codeParameter2.Reference != null)
            codeParameter2.Name = parameters[num++].Name;
        }
        bool flag1 = false;
        bool flag2 = false;
        foreach (object attribute in method.Attributes)
        {
          CodeAttribute2 codeAttribute2 = new CodeAttribute2(attribute);
          if (codeAttribute2.Reference != null)
          {
            flag1 = ((flag1 ? 1 : 0) | (string.IsNullOrEmpty(codeAttribute2.Name) ? 0 : (codeAttribute2.Name.Contains("WebMethod") ? 1 : 0))) != 0;
            flag2 = ((flag2 ? 1 : 0) | (string.IsNullOrEmpty(codeAttribute2.Name) ? 0 : (codeAttribute2.Name.Contains("ScriptMethod") ? 1 : 0))) != 0;
            if (flag1)
            {
              if (flag2)
                break;
            }
          }
        }
        if (!flag1)
          method.AddAttribute(typeof (WebMethodAttribute).FullName, "", (object) -1);
        if (flag2)
          return;
        method.AddAttribute(typeof (ScriptMethodAttribute).FullName, "", (object) -1);
      }

      private static FileCodeModel2 LoadFileCodeModel(ProjectItem projectItem)
      {
        VSWebProjectItem vsWebProjectItem = projectItem != null && projectItem.Reference != null ? new VSWebProjectItem(projectItem.Object) : throw new ArgumentNullException(nameof (projectItem), "projectItem cannot be null");
        if (vsWebProjectItem.Reference == null)
          return projectItem.FileCodeModel;
        vsWebProjectItem.Load();
        return vsWebProjectItem.ProjectItem.FileCodeModel;
      }

      private static void UnloadWebProjectItem(ProjectItem projectItem)
      {
        VSWebProjectItem vsWebProjectItem = new VSWebProjectItem(projectItem.Object);
        if (vsWebProjectItem.Reference == null)
          return;
        vsWebProjectItem.Unload();
      }
    }

    private class ExtenderPropertyRenameDescProv : FilterTypeDescriptionProvider<IComponent>
    {
      private ExtenderControlBaseDesigner<T> _owner;

      public ExtenderPropertyRenameDescProv(ExtenderControlBaseDesigner<T> owner, IComponent target)
        : base(target)
      {
        this._owner = owner;
        this.FilterExtendedProperties = true;
      }

      protected override PropertyDescriptor ProcessProperty(
        PropertyDescriptor baseProp)
      {
        if (!(baseProp.Name == "Extender") || baseProp.ComponentType != this._owner.GetType() || this._owner.ExtenderPropertyName == null)
          return base.ProcessProperty(baseProp);
        return TypeDescriptor.CreateProperty(baseProp.ComponentType, baseProp, (System.Attribute) new DisplayNameAttribute(this._owner.ExtenderPropertyName));
      }
    }
  }
}
