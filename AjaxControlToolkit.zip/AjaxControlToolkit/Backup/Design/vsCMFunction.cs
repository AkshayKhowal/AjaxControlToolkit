﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.vsCMFunction
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class vsCMFunction
  {
    private static Type _referencedType;
    private object _reference;
    public static readonly vsCMFunction vsCMFunctionFunction = new vsCMFunction((object) 128);

    public static Type ReferencedType
    {
      get
      {
        if (vsCMFunction._referencedType == null)
        {
          vsCMFunction._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.vsCMFunction");
          if (vsCMFunction._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.vsCMFunction' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return vsCMFunction._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public vsCMFunction()
      : this((object) null)
    {
    }

    public vsCMFunction(object reference) => this._reference = vsCMFunction.ReferencedType.IsInstanceOfType(reference) || reference is int ? reference : (object) null;

    public int Value => (int) this._reference;

    public override bool Equals(object obj)
    {
      vsCMFunction vsCmFunction = obj as vsCMFunction;
      if (vsCmFunction == (vsCMFunction) null)
        return false;
      if (this._reference == null)
        return vsCmFunction._reference == null;
      return vsCmFunction._reference != null && this.Value == vsCmFunction.Value;
    }

    public override int GetHashCode() => this._reference != null ? this.Value.GetHashCode() : 0;

    public static bool operator ==(vsCMFunction left, vsCMFunction right) => object.ReferenceEquals((object) left, (object) null) ? object.ReferenceEquals((object) right, (object) null) : left.Equals((object) right);

    public static bool operator !=(vsCMFunction left, vsCMFunction right) => !(left == right);
  }
}
