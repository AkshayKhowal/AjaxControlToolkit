﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.vsCMAccess
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class vsCMAccess
  {
    private static Type _referencedType;
    private object _reference;
    public static readonly vsCMAccess vsCMAccessPublic = new vsCMAccess((object) 1);

    public static Type ReferencedType
    {
      get
      {
        if (vsCMAccess._referencedType == null)
        {
          vsCMAccess._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.vsCMAccess");
          if (vsCMAccess._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.vsCMAccess' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return vsCMAccess._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public vsCMAccess()
      : this((object) null)
    {
    }

    public vsCMAccess(object reference) => this._reference = vsCMAccess.ReferencedType.IsInstanceOfType(reference) || reference is int ? reference : (object) null;

    public int Value => (int) this._reference;

    public override bool Equals(object obj)
    {
      vsCMAccess vsCmAccess = obj as vsCMAccess;
      if (vsCmAccess == (vsCMAccess) null)
        return false;
      if (this._reference == null)
        return vsCmAccess._reference == null;
      return vsCmAccess._reference != null && this.Value == vsCmAccess.Value;
    }

    public override int GetHashCode() => this._reference != null ? this.Value.GetHashCode() : 0;

    public static bool operator ==(vsCMAccess left, vsCMAccess right) => object.ReferenceEquals((object) left, (object) null) ? object.ReferenceEquals((object) right, (object) null) : left.Equals((object) right);

    public static bool operator !=(vsCMAccess left, vsCMAccess right) => !(left == right);
  }
}
