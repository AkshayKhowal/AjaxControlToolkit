﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeElements
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections;

namespace AjaxControlToolkit.Design
{
  internal class CodeElements
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (CodeElements._referencedType == null)
        {
          CodeElements._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.CodeElements");
          if (CodeElements._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.CodeElements' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeElements._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeElements()
      : this((object) null)
    {
    }

    public CodeElements(object reference) => this._reference = CodeElements.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public int Count => (int) CodeElements.ReferencedType.GetProperty(nameof (Count)).GetValue(this._reference, new object[0]);

    public IEnumerator GetEnumerator() => (IEnumerator) CodeElements.ReferencedType.GetMethod(nameof (GetEnumerator)).Invoke(this._reference, new object[0]);
  }
}
