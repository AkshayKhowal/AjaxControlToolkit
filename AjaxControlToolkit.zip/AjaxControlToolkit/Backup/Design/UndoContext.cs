﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.UndoContext
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class UndoContext
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (UndoContext._referencedType == null)
        {
          UndoContext._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.UndoContext");
          if (UndoContext._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.UndoContext' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return UndoContext._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public UndoContext()
      : this((object) null)
    {
    }

    public UndoContext(object reference) => this._reference = UndoContext.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public bool IsOpen => (bool) UndoContext.ReferencedType.GetProperty(nameof (IsOpen)).GetValue(this._reference, new object[0]);

    public void Open(string Name, bool Strict) => UndoContext.ReferencedType.GetMethod(nameof (Open)).Invoke(this._reference, new object[2]
    {
      (object) Name,
      (object) Strict
    });

    public void Close() => UndoContext.ReferencedType.GetMethod(nameof (Close)).Invoke(this._reference, new object[0]);
  }
}
