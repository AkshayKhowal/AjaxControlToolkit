﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.vsCMTypeRef
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class vsCMTypeRef
  {
    private static Type _referencedType;
    private object _reference;
    public static readonly vsCMTypeRef vsCMTypeRefArray = new vsCMTypeRef((object) 2);
    public static readonly vsCMTypeRef vsCMTypeRefPointer = new vsCMTypeRef((object) 4);

    public static Type ReferencedType
    {
      get
      {
        if (vsCMTypeRef._referencedType == null)
        {
          vsCMTypeRef._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.vsCMTypeRef");
          if (vsCMTypeRef._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.vsCMTypeRef' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return vsCMTypeRef._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public vsCMTypeRef()
      : this((object) null)
    {
    }

    public vsCMTypeRef(object reference) => this._reference = vsCMTypeRef.ReferencedType.IsInstanceOfType(reference) || reference is int ? reference : (object) null;

    public int Value => (int) this._reference;

    public override bool Equals(object obj)
    {
      vsCMTypeRef vsCmTypeRef = obj as vsCMTypeRef;
      if (vsCmTypeRef == (vsCMTypeRef) null)
        return false;
      if (this._reference == null)
        return vsCmTypeRef._reference == null;
      return vsCmTypeRef._reference != null && this.Value == vsCmTypeRef.Value;
    }

    public override int GetHashCode() => this._reference != null ? this.Value.GetHashCode() : 0;

    public static bool operator ==(vsCMTypeRef left, vsCMTypeRef right) => object.ReferenceEquals((object) left, (object) null) ? object.ReferenceEquals((object) right, (object) null) : left.Equals((object) right);

    public static bool operator !=(vsCMTypeRef left, vsCMTypeRef right) => !(left == right);
  }
}
