﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeClass2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class CodeClass2
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (CodeClass2._referencedType == null)
        {
          CodeClass2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.CodeClass2");
          if (CodeClass2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.CodeClass2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeClass2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeClass2()
      : this((object) null)
    {
    }

    public CodeClass2(object reference) => this._reference = CodeClass2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public CodeElements Children
    {
      get
      {
        object reference = CodeClass2.ReferencedType.GetProperty(nameof (Children)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }

    public CodeFunction2 AddFunction(
      string Name,
      vsCMFunction Kind,
      object Type,
      object Position,
      vsCMAccess Access,
      object Location)
    {
      object reference = CodeClass2.ReferencedType.GetMethod(nameof (AddFunction)).Invoke(this._reference, new object[6]
      {
        (object) Name,
        Kind != (vsCMFunction) null ? Kind.Reference : (object) null,
        Type,
        Position,
        Access != (vsCMAccess) null ? Access.Reference : (object) null,
        Location
      });
      return reference == null ? (CodeFunction2) null : new CodeFunction2(reference);
    }
  }
}
