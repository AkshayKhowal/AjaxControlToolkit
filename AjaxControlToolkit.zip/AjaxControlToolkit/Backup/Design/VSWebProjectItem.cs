﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.VSWebProjectItem
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class VSWebProjectItem
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (VSWebProjectItem._referencedType == null)
        {
          VSWebProjectItem._referencedType = ReferencedAssemblies.VsWebSite.GetType("VsWebSite.VSWebProjectItem");
          if (VSWebProjectItem._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'VsWebSite.VSWebProjectItem' from assembly 'VsWebSite.Interop, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return VSWebProjectItem._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public VSWebProjectItem()
      : this((object) null)
    {
    }

    public VSWebProjectItem(object reference) => this._reference = VSWebProjectItem.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public ProjectItem ProjectItem
    {
      get
      {
        object reference = VSWebProjectItem.ReferencedType.GetProperty(nameof (ProjectItem)).GetValue(this._reference, new object[0]);
        return reference == null ? (ProjectItem) null : new ProjectItem(reference);
      }
    }

    public void Load() => VSWebProjectItem.ReferencedType.GetMethod(nameof (Load)).Invoke(this._reference, new object[0]);

    public void Unload() => VSWebProjectItem.ReferencedType.GetMethod(nameof (Unload)).Invoke(this._reference, new object[0]);
  }
}
