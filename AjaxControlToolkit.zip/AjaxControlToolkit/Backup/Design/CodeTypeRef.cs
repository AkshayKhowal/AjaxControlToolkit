﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeTypeRef
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class CodeTypeRef
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (CodeTypeRef._referencedType == null)
        {
          CodeTypeRef._referencedType = ReferencedAssemblies.EnvDTE.GetType("EnvDTE.CodeTypeRef");
          if (CodeTypeRef._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE.CodeTypeRef' from assembly 'EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeTypeRef._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeTypeRef()
      : this((object) null)
    {
    }

    public CodeTypeRef(object reference) => this._reference = CodeTypeRef.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public vsCMTypeRef TypeKind
    {
      get
      {
        object reference = CodeTypeRef.ReferencedType.GetProperty(nameof (TypeKind)).GetValue(this._reference, new object[0]);
        return reference == null ? (vsCMTypeRef) null : new vsCMTypeRef(reference);
      }
    }

    public CodeTypeRef ElementType
    {
      get
      {
        object reference = CodeTypeRef.ReferencedType.GetProperty(nameof (ElementType)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeTypeRef) null : new CodeTypeRef(reference);
      }
      set => CodeTypeRef.ReferencedType.GetProperty(nameof (ElementType)).SetValue(this._reference, value?.Reference, new object[0]);
    }

    public string AsFullName => (string) CodeTypeRef.ReferencedType.GetProperty(nameof (AsFullName)).GetValue(this._reference, new object[0]);

    public int Rank
    {
      get => (int) CodeTypeRef.ReferencedType.GetProperty(nameof (Rank)).GetValue(this._reference, new object[0]);
      set => CodeTypeRef.ReferencedType.GetProperty(nameof (Rank)).SetValue(this._reference, (object) value, new object[0]);
    }
  }
}
