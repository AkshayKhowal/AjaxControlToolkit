﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.DTE2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class DTE2
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (DTE2._referencedType == null)
        {
          DTE2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.DTE2");
          if (DTE2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.DTE2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return DTE2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public DTE2()
      : this((object) null)
    {
    }

    public DTE2(object reference) => this._reference = DTE2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public Document ActiveDocument
    {
      get
      {
        object reference = DTE2.ReferencedType.GetProperty(nameof (ActiveDocument)).GetValue(this._reference, new object[0]);
        return reference == null ? (Document) null : new Document(reference);
      }
    }

    public UndoContext UndoContext
    {
      get
      {
        object reference = DTE2.ReferencedType.GetProperty(nameof (UndoContext)).GetValue(this._reference, new object[0]);
        return reference == null ? (UndoContext) null : new UndoContext(reference);
      }
    }
  }
}
