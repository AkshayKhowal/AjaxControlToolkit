﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.FilterTypeDescriptionProvider`1
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;

namespace AjaxControlToolkit.Design
{
  internal class FilterTypeDescriptionProvider<T> : TypeDescriptionProvider, ICustomTypeDescriptor
  {
    private T _target;
    private ICustomTypeDescriptor _baseDescriptor;
    private TypeDescriptionProvider _baseProvider;
    private bool _extended;

    public FilterTypeDescriptionProvider(T target)
      : base(TypeDescriptor.GetProvider((object) target))
    {
      this._target = target;
      this._baseProvider = TypeDescriptor.GetProvider((object) target);
    }

    protected T Target => this._target;

    private ICustomTypeDescriptor BaseDescriptor
    {
      get
      {
        if (this._baseDescriptor == null)
          this._baseDescriptor = !this.FilterExtendedProperties ? this._baseProvider.GetTypeDescriptor((object) this.Target) : this._baseProvider.GetExtendedTypeDescriptor((object) this.Target);
        return this._baseDescriptor;
      }
    }

    protected bool FilterExtendedProperties
    {
      get => this._extended;
      set => this._extended = value;
    }

    public override ICustomTypeDescriptor GetTypeDescriptor(
      Type objectType,
      object instance)
    {
      return this.FilterExtendedProperties || instance != (object) this.Target ? this._baseProvider.GetTypeDescriptor(objectType, instance) : (ICustomTypeDescriptor) this;
    }

    public override ICustomTypeDescriptor GetExtendedTypeDescriptor(
      object instance)
    {
      return this.FilterExtendedProperties && instance == (object) this.Target ? (ICustomTypeDescriptor) this : this._baseProvider.GetExtendedTypeDescriptor(instance);
    }

    protected virtual PropertyDescriptor ProcessProperty(
      PropertyDescriptor baseProp)
    {
      return baseProp;
    }

    public void Dispose()
    {
      this._target = default (T);
      this._baseDescriptor = (ICustomTypeDescriptor) null;
      this._baseProvider = (TypeDescriptionProvider) null;
    }

    PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties() => this.FilterProperties(this.BaseDescriptor.GetProperties());

    PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties(
      Attribute[] attributes)
    {
      return this.FilterProperties(this.BaseDescriptor.GetProperties(attributes));
    }

    private PropertyDescriptorCollection FilterProperties(
      PropertyDescriptorCollection props)
    {
      PropertyDescriptor[] properties = new PropertyDescriptor[props.Count];
      props.CopyTo((Array) properties, 0);
      bool flag = false;
      for (int index = 0; index < properties.Length; ++index)
      {
        PropertyDescriptor propertyDescriptor = this.ProcessProperty(properties[index]);
        if (propertyDescriptor != properties[index])
        {
          flag = true;
          properties[index] = propertyDescriptor;
        }
      }
      if (flag)
        props = new PropertyDescriptorCollection(properties);
      return props;
    }

    AttributeCollection ICustomTypeDescriptor.GetAttributes() => this.BaseDescriptor.GetAttributes();

    string ICustomTypeDescriptor.GetClassName() => this.BaseDescriptor.GetClassName();

    string ICustomTypeDescriptor.GetComponentName() => this.BaseDescriptor.GetComponentName();

    TypeConverter ICustomTypeDescriptor.GetConverter() => this.BaseDescriptor.GetConverter();

    EventDescriptor ICustomTypeDescriptor.GetDefaultEvent() => this.BaseDescriptor.GetDefaultEvent();

    PropertyDescriptor ICustomTypeDescriptor.GetDefaultProperty() => this.BaseDescriptor.GetDefaultProperty();

    object ICustomTypeDescriptor.GetEditor(Type editorBaseType) => this.BaseDescriptor.GetEditor(editorBaseType);

    EventDescriptorCollection ICustomTypeDescriptor.GetEvents(
      Attribute[] attributes)
    {
      return this.BaseDescriptor.GetEvents(attributes);
    }

    EventDescriptorCollection ICustomTypeDescriptor.GetEvents() => this.BaseDescriptor.GetEvents();

    object ICustomTypeDescriptor.GetPropertyOwner(PropertyDescriptor pd) => this.BaseDescriptor.GetPropertyOwner(pd);
  }
}
