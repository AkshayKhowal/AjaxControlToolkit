﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.CodeElement2
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  internal class CodeElement2
  {
    private static Type _referencedType;
    private object _reference;

    public static Type ReferencedType
    {
      get
      {
        if (CodeElement2._referencedType == null)
        {
          CodeElement2._referencedType = ReferencedAssemblies.EnvDTE80.GetType("EnvDTE80.CodeElement2");
          if (CodeElement2._referencedType == null)
            throw new InvalidOperationException("Failed to load type 'EnvDTE80.CodeElement2' from assembly 'EnvDTE80, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'.");
        }
        return CodeElement2._referencedType;
      }
    }

    public object Reference
    {
      get => this._reference;
      set => this._reference = value;
    }

    public CodeElement2()
      : this((object) null)
    {
    }

    public CodeElement2(object reference) => this._reference = CodeElement2.ReferencedType.IsInstanceOfType(reference) ? reference : (object) null;

    public string Name
    {
      get => (string) CodeElement2.ReferencedType.GetProperty(nameof (Name)).GetValue(this._reference, new object[0]);
      set => CodeElement2.ReferencedType.GetProperty(nameof (Name)).SetValue(this._reference, (object) value, new object[0]);
    }

    public string FullName => (string) CodeElement2.ReferencedType.GetProperty(nameof (FullName)).GetValue(this._reference, new object[0]);

    public vsCMElement Kind
    {
      get
      {
        object reference = CodeElement2.ReferencedType.GetProperty(nameof (Kind)).GetValue(this._reference, new object[0]);
        return reference == null ? (vsCMElement) null : new vsCMElement(reference);
      }
    }

    public bool IsCodeType => (bool) CodeElement2.ReferencedType.GetProperty(nameof (IsCodeType)).GetValue(this._reference, new object[0]);

    public CodeElements Children
    {
      get
      {
        object reference = CodeElement2.ReferencedType.GetProperty(nameof (Children)).GetValue(this._reference, new object[0]);
        return reference == null ? (CodeElements) null : new CodeElements(reference);
      }
    }
  }
}
