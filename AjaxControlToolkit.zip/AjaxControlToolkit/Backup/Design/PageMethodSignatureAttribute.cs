﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.Design.PageMethodSignatureAttribute
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit.Design
{
  [AttributeUsage(AttributeTargets.Delegate, AllowMultiple = false, Inherited = true)]
  public sealed class PageMethodSignatureAttribute : Attribute
  {
    private string _friendlyName;
    private string _servicePathProperty;
    private string _serviceMethodProperty;
    private string _useContextKeyProperty;

    public string FriendlyName => this._friendlyName;

    public string ServicePathProperty => this._servicePathProperty;

    public string ServiceMethodProperty => this._serviceMethodProperty;

    public string UseContextKeyProperty => this._useContextKeyProperty;

    public bool IncludeContextParameter => !string.IsNullOrEmpty(this._useContextKeyProperty);

    public PageMethodSignatureAttribute(
      string friendlyName,
      string servicePathProperty,
      string serviceMethodProperty)
      : this(friendlyName, servicePathProperty, serviceMethodProperty, (string) null)
    {
    }

    public PageMethodSignatureAttribute(
      string friendlyName,
      string servicePathProperty,
      string serviceMethodProperty,
      string useContextKeyProperty)
    {
      this._friendlyName = friendlyName;
      this._servicePathProperty = servicePathProperty;
      this._serviceMethodProperty = serviceMethodProperty;
      this._useContextKeyProperty = useContextKeyProperty;
    }
  }
}
