﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AsyncFileUploadEventArgs
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;

namespace AjaxControlToolkit
{
  public class AsyncFileUploadEventArgs : EventArgs
  {
    public string statusMessage = string.Empty;
    public string filename = string.Empty;
    public string filesize = string.Empty;
    public AsyncFileUploadState state = AsyncFileUploadState.Unknown;

    public AsyncFileUploadEventArgs(
      AsyncFileUploadState state,
      string statusMessage,
      string filename,
      string filesize)
    {
      this.statusMessage = statusMessage;
      this.filename = filename;
      this.filesize = filesize;
      this.state = state;
    }
  }
}
