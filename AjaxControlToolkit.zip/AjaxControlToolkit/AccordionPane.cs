﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AccordionPane
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AjaxControlToolkit
{
  [ToolboxBitmap(typeof (AccordionPane), "Accordion.Accordion.ico")]
  [ParseChildren(true)]
  [ToolboxData("<{0}:AccordionPane runat=\"server\"></{0}:AccordionPane>")]
  [PersistChildren(false)]
  public class AccordionPane : WebControl
  {
    private AccordionContentPanel _header;
    private ITemplate _headerTemplate;
    private AccordionContentPanel _content;
    private ITemplate _contentTemplate;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public AccordionContentPanel HeaderContainer
    {
      get
      {
        this.EnsureChildControls();
        return this._header;
      }
    }

    [Browsable(true)]
    [Description("CSS class for Accordion Pane Header")]
    [Category("Appearance")]
    public string HeaderCssClass
    {
      get
      {
        this.EnsureChildControls();
        return this._header.CssClass;
      }
      set
      {
        this.EnsureChildControls();
        this._header.CssClass = value;
      }
    }

    [Description("Accordion Pane Header")]
    [TemplateContainer(typeof (AccordionContentPanel))]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    [DefaultValue(null)]
    [Browsable(false)]
    [TemplateInstance(TemplateInstance.Single)]
    public virtual ITemplate Header
    {
      get => this._headerTemplate;
      set => this._headerTemplate = value;
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public AccordionContentPanel ContentContainer
    {
      get
      {
        this.EnsureChildControls();
        return this._content;
      }
    }

    [Description("CSS class for Accordion Pane Content")]
    [Category("Appearance")]
    [Browsable(true)]
    public string ContentCssClass
    {
      get
      {
        this.EnsureChildControls();
        return this._content.CssClass;
      }
      set
      {
        this.EnsureChildControls();
        this._content.CssClass = value;
      }
    }

    [Browsable(false)]
    [DefaultValue(null)]
    [Description("Accordion Pane Content")]
    [TemplateInstance(TemplateInstance.Single)]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    [TemplateContainer(typeof (AccordionContentPanel))]
    public virtual ITemplate Content
    {
      get => this._contentTemplate;
      set => this._contentTemplate = value;
    }

    public override ControlCollection Controls
    {
      get
      {
        this.EnsureChildControls();
        return base.Controls;
      }
    }

    protected override void CreateChildControls()
    {
      this.Controls.Clear();
      this._header = new AccordionContentPanel((object) null, -1, AccordionItemType.Header);
      this._header.ID = string.Format((IFormatProvider) CultureInfo.InvariantCulture, "{0}_header", (object) this.ID);
      this.Controls.Add((Control) this._header);
      this._content = new AccordionContentPanel((object) null, -1, AccordionItemType.Content);
      this._content.ID = string.Format((IFormatProvider) CultureInfo.InvariantCulture, "{0}_content", (object) this.ID);
      this.Controls.Add((Control) this._content);
      this._content.Collapsed = true;
      if (this._headerTemplate != null)
        this._headerTemplate.InstantiateIn((Control) this._header);
      if (this._contentTemplate == null)
        return;
      this._contentTemplate.InstantiateIn((Control) this._content);
    }

    public override Control FindControl(string id)
    {
      this.EnsureChildControls();
      return base.FindControl(id) ?? this._header.FindControl(id) ?? this._content.FindControl(id);
    }

    public override void RenderBeginTag(HtmlTextWriter writer)
    {
    }

    public override void RenderEndTag(HtmlTextWriter writer)
    {
    }
  }
}
