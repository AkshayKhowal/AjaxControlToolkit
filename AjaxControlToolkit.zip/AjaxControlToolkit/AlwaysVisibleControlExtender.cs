﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AlwaysVisibleControlExtender
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Web.UI;

namespace AjaxControlToolkit
{
  [TargetControlType(typeof (Control))]
  [ClientScriptResource("AjaxControlToolkit.AlwaysVisibleControlBehavior", "AjaxControlToolkit.AlwaysVisibleControl.AlwaysVisibleControlBehavior.js")]
  [RequiredScript(typeof (AnimationScripts))]
  [DefaultProperty("VerticalOffset")]
  [ToolboxBitmap(typeof (AlwaysVisibleControlExtender), "AlwaysVisibleControl.AlwaysVisible.ico")]
  [Designer("AjaxControlToolkit.AlwaysVisibleControlDesigner, AjaxControlToolkit")]
  public class AlwaysVisibleControlExtender : ExtenderControlBase
  {
    [DefaultValue(0)]
    [ExtenderControlProperty]
    public int HorizontalOffset
    {
      get => this.GetPropertyValue<int>(nameof (HorizontalOffset), 0);
      set => this.SetPropertyValue<int>(nameof (HorizontalOffset), value);
    }

    [DefaultValue(HorizontalSide.Left)]
    [ExtenderControlProperty]
    public HorizontalSide HorizontalSide
    {
      get => this.GetPropertyValue<HorizontalSide>(nameof (HorizontalSide), HorizontalSide.Left);
      set => this.SetPropertyValue<HorizontalSide>(nameof (HorizontalSide), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0)]
    public int VerticalOffset
    {
      get => this.GetPropertyValue<int>(nameof (VerticalOffset), 0);
      set => this.SetPropertyValue<int>(nameof (VerticalOffset), value);
    }

    [DefaultValue(VerticalSide.Top)]
    [ExtenderControlProperty]
    public VerticalSide VerticalSide
    {
      get => this.GetPropertyValue<VerticalSide>(nameof (VerticalSide), VerticalSide.Top);
      set => this.SetPropertyValue<VerticalSide>(nameof (VerticalSide), value);
    }

    [ExtenderControlProperty]
    [DefaultValue(0.1f)]
    public float ScrollEffectDuration
    {
      get => this.GetPropertyValue<float>(nameof (ScrollEffectDuration), 0.1f);
      set => this.SetPropertyValue<float>(nameof (ScrollEffectDuration), value);
    }

    [DefaultValue(false)]
    [ExtenderControlProperty]
    [ClientPropertyName("useAnimation")]
    public bool UseAnimation
    {
      get => this.GetPropertyValue<bool>(nameof (UseAnimation), false);
      set => this.SetPropertyValue<bool>(nameof (UseAnimation), value);
    }

    public override void EnsureValid()
    {
      base.EnsureValid();
      if (this.VerticalOffset < 0)
        throw new ArgumentOutOfRangeException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "AlwaysVisibleControlExtender on '{0}' cannot have a negative VerticalOffset value", (object) this.TargetControlID));
      if (this.HorizontalOffset < 0)
        throw new ArgumentOutOfRangeException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "AlwaysVisibleControlExtender on '{0}' cannot have a negative HorizontalOffset value", (object) this.TargetControlID));
      if ((double) this.ScrollEffectDuration <= 0.0)
        throw new ArgumentOutOfRangeException(string.Format((IFormatProvider) CultureInfo.CurrentCulture, "AlwaysVisibleControlExtender on '{0}' must have a positive ScrollEffectDuration", (object) this.TargetControlID));
    }
  }
}
