﻿// Decompiled with JetBrains decompiler
// Type: AjaxControlToolkit.AfuPersistedStoreManager
// Assembly: AjaxControlToolkit, Version=3.0.30930.28736, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e
// MVID: B0EEFC76-0092-471B-AB62-F3DDC8240D71
// Assembly location: C:\TFS\UFD\Development\DevNet4.8\PCI\source\Pegasus.NET\Lib\AjaxControlToolkit.dll

using System;
using System.Collections.Generic;
using System.Web;

namespace AjaxControlToolkit
{
  internal sealed class AfuPersistedStoreManager
  {
    private static readonly string IdSeperator = "~!~";
    private string extendedFileUploadGUID;
    private AfuPersistedStoreManager.PersistedStoreTypeEnum persistedStorageType;

    private AfuPersistedStoreManager()
    {
    }

    public static AfuPersistedStoreManager Instance => AfuPersistedStoreManager.InstanceInitializer.instance;

    public AfuPersistedStoreManager.PersistedStoreTypeEnum PersistedStorageType
    {
      get => this.persistedStorageType;
      set => this.persistedStorageType = value;
    }

    public string ExtendedFileUploadGUID
    {
      get => this.extendedFileUploadGUID;
      set => this.extendedFileUploadGUID = value;
    }

    public string GetFullID(string controlId) => this.extendedFileUploadGUID + AfuPersistedStoreManager.IdSeperator + controlId;

    public void ClearAllFilesFromSession(string controlId)
    {
      HttpContext currentContext;
      if ((currentContext = this.GetCurrentContext()) == null)
        return;
      foreach (string key in currentContext.Session.Keys)
      {
        if (key.StartsWith(this.extendedFileUploadGUID))
          currentContext.Session.Remove(key);
      }
    }

    public void RemoveFileFromSession(string controlId, string filename)
    {
      HttpContext currentContext;
      if ((currentContext = this.GetCurrentContext()) == null)
        return;
      foreach (string key in currentContext.Session.Keys)
      {
        if (key.StartsWith(this.GetFullID(controlId)))
          currentContext.Session.Remove(key);
      }
    }

    public void AddFileToSession(string controlId, string filename, HttpPostedFile fileUpload)
    {
      if (fileUpload == null)
        throw new ArgumentNullException(nameof (fileUpload));
      if (controlId == string.Empty)
        throw new ArgumentNullException(nameof (controlId));
      HttpContext currentContext;
      if ((currentContext = this.GetCurrentContext()) == null)
        return;
      currentContext.Session.Add(this.GetFullID(controlId), (object) fileUpload);
    }

    public bool FileExists(string controlId)
    {
      if (controlId == null)
        throw new ArgumentNullException(nameof (controlId));
      HttpContext currentContext;
      return (currentContext = this.GetCurrentContext()) != null && currentContext.Session[this.GetFullID(controlId)] != null && currentContext.Session[this.GetFullID(controlId)] is HttpPostedFile;
    }

    public string GetFileName(string controlId)
    {
      if (controlId == null)
        throw new ArgumentNullException(nameof (controlId));
      HttpContext currentContext;
      return (currentContext = this.GetCurrentContext()) != null && currentContext.Session[this.GetFullID(controlId)] is HttpPostedFile httpPostedFile ? httpPostedFile.FileName : string.Empty;
    }

    public string GetContentType(string controlId)
    {
      if (controlId == null)
        throw new ArgumentNullException(nameof (controlId));
      HttpContext currentContext;
      return (currentContext = this.GetCurrentContext()) != null && currentContext.Session[this.GetFullID(controlId)] is HttpPostedFile httpPostedFile ? httpPostedFile.ContentType : string.Empty;
    }

    public HttpPostedFile GetFileFromSession(string controlId)
    {
      if (controlId == null)
        throw new ArgumentNullException(nameof (controlId));
      HttpContext currentContext;
      if ((currentContext = this.GetCurrentContext()) == null)
        return (HttpPostedFile) null;
      if (currentContext.Session[this.GetFullID(controlId)] == null)
        return (HttpPostedFile) null;
      if (currentContext.Session[this.GetFullID(controlId)] is HttpPostedFile fileFromSession)
        return fileFromSession;
      throw new InvalidCastException("postedFile");
    }

    public List<HttpPostedFile> GetAllFilesFromSession(string controlId)
    {
      List<HttpPostedFile> filesFromSession = new List<HttpPostedFile>();
      HttpContext currentContext;
      if ((currentContext = this.GetCurrentContext()) != null)
      {
        foreach (string key in currentContext.Session.Keys)
        {
          if (key.StartsWith(this.extendedFileUploadGUID) && HttpContext.Current.Session[key] != null && HttpContext.Current.Session[key] is HttpPostedFile httpPostedFile)
            filesFromSession.Add(httpPostedFile);
        }
      }
      return filesFromSession;
    }

    private HttpContext GetCurrentContext() => HttpContext.Current != null && HttpContext.Current.Session != null ? HttpContext.Current : (HttpContext) null;

    private class InstanceInitializer
    {
      internal static readonly AfuPersistedStoreManager instance = new AfuPersistedStoreManager();
    }

    public enum PersistedStoreTypeEnum
    {
      Session,
    }
  }
}
